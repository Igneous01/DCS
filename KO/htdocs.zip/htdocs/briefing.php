<?php
//include('source/Helper.php');
//$helper = new TAW_Source_Helper();
//$data = $helper->getAllData();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<link rel="shortcut icon" type="image/ico" href="assets/images/tkosignet.ico" />
		<title>The Kaukasus Offensive - Briefing</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/css/briefing.css" rel="stylesheet" type="text/css">
	<link href="assets/tablesorter/css/theme.dark.css" rel="stylesheet" type="text/css">
	<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.js"></script> 	
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.widgets.js"></script>
	
	<body>
		<header>
			<div><?php include("navbar.php"); ?></div>
			
		</header>
		
		<div id="briefing">
			<section class="textBlock" id="Introduction">
				<div id="briefingNavBar">
					<div><?php include("briefingnavbar.php"); ?></div>
				</div>
				<div class="textBlockWrapper">
					<h1>Introduction</h1>
					<p>This mission intends to provide you a place to fly where you get meaningful things to do with moderate flying distances and balance in mind, and to make things better, this website should help you get an overview over the current situation in the battlefield with its livemap and scoreboard. </p>
					<p><b>Everything you do is being saved, the Kaukasus Offensive forgets nothing. </b></p>
					<p>Objectives can be <strong>occupied</strong> or <strong>neutral</strong>. Whenever a side has units at an objective, the objective changes from white to the coalitions color, once all units are destroyed it turns neutral again. In order to occupy an objective you have to send a helicopter to deploy vehicles of your choice. </p>
					<p>FARPS and Airodromes can also be <strong>open</strong> or <strong>closed</strong>, FARPS can also be closed while being occupied. In order to open a FARP you need to bring a complete set of groundcrew units to the FARP (ATC, Fuel and Ammo). You can also do this by buying a groundcrew <a href="#Convoys">Convoy</a></p>
					<p>Helicopters can also <strong>deploy airdefenses</strong> and other ground units in the field, however the amount of wild-SAMs you can place depends on how many antennas your team manages to occupy. They will self destruct after 48 hours.</p>
					<p>If a Pilot <strong>ejects</strong>, your ejected Pilot will stay patiently in place, until a Helicopter comes and picks him up! <strong><a href="#CSAR">CSAR Missions</a></strong> are not only fun, because you never know where the Pilos come down, they also reward you with Points which you can use to send Convoys to friendly objectives! Capturing an enemy Pilot will bring twice the points!</p>
					<p>Most of the things you can do will earn you <strong>money</strong>. If you hit a target, if you drop cargo, if you rescue piltos, you will even receive 100$ per flight-minute, but only if you manage to land safely. You can use your cash to call for convoys to reinforce your objectives or attack enemy objectives. You can only call convoys if you are at the Objective you want to call the convoy to. </p>
					<p>Absolutely everything you do will get you a <strong>score</strong>. Emergencylandings, weapon usage, Pilots rescued, kills of course! You will even be rewarded a kill if a SAM you deployed killed an enemy player! </p>
					<p>As a Striker you don't need to be worried to face a dozen 4th-gen fighterjets, every category (Fighter/Attack/Transport) is limited to only 4 slots per side. This should help finding small teams and working together efficiently. </p>
					<p>In order to make everythign easier, <strong>we enforce the use</strong> of Ciribobs fantastic <a>Simple Radio</a> to communicate! Battle space is 251 Mhz, everyone should at least listen to this radio channel! You can also use any secondary frequency to communicate with your wingman. If you're having trouble setting it up please check <a href="https://github.com/ciribob/DCS-SimpleRadioStandalone/wiki">this space</a>.</p>
				</div>
			</section>
			<section class="textBlock" id="GettingStarted">
				<div id="briefingNavBar">
					<div><?php include("briefingnavbar.php"); ?></div>
				</div>
				<div class="textBlockWrapper">
					<h1>Getting Started (read this if you are new!)</h1>
					
					<p>Welcome to The Kaukasus Offensive!</p>
					<p>To get started, you will first need to choose a slot. You likely already realized that some slots are blocked, and sometimes you cannot get a slot at all. Let us explain how to get an easy overview of what's available. </p>

					
					<h2>"How do I find a slot I can spawn in?"</h2>
					<p>First of all check the Map to see which Objectives are owned by your coalition. That's the straightforward part. FARPs are a little bit more complicated than airfields, because the can be open or closed, even if they are occupied by your coalition (occupied = at least one unit regardless of unit-type of either coalition is in the objectives zone). </p>
					<p>You can only spawn at FARPs and Airfields that are open and occupied by the coalition of your choice! To open a FARP you need to bring all 3 types of Groundcrew (ATC/Fuel/Ammo) to the FARP. It will stay open until all Groundcrew is destroyed. </p>

					<p>One last thing about slots. In order to prevent a 15vs15 Fighters-Scenario, which you are likely already used to, we introduced quite strict slot-balancing. This means, you only have 4 Fighters, 4 Strikers and 4 Helicopters per side available. This is to make sure if you decide to fly A10 or UH-1, that you are not facing 10 F15s or Flankers on the enemy side. Teams are kept balance, to make it easier to work together. This way, a Team of 2 fighters and 2 strikers that work well as a team can be a lot more effective than 4 fighters who do not care about what each other is doing.</p> 

					<p>To find out how many slots of your category of choice are available, have a look at the Slotlist below the map!</p>

					<h2>"Alright, got I got a slot, what's next?"</h2>
					<p>The most important thing you should know about the Kaukasus-Offensive is ground-units do not respawn! Once you kill a SAM it is gone forever! All units are either brought to their location by a Helicopter, or they were deployed with a convoy by a helicopter Pilot who collected enough points by either delivering crates or rescuing pilots. </p>

					<h2>"Gotcha, I'm a Fighter Pilot, whats my task?"</h2>
					<p>Your job is to gain and hold airsuperiority wherever it is needed. Communicate with your Team to find out where they are operating. If you are the only one, check which objectives belong to your coalition, and make sure there is no striker coming in to destroy them. If you have a bunch of strikers, as them what they are attacking, and make sure they are not being intercepted by enemy CAP. Just set off a radio-call on 251.00 AM on SRS, every Striker-Pilot is happy to be escorted by a Fighterjet ;) Also don't forget about helicopters, most of them don't have an RWR, they will also be happy to know you protect them. </p>

					<h2>"I'd like to destroy stuff, CAS, SEAD or sneaky missions in Attack-Choppers!"</h2>
					<p>Welcome Striker! Your job is the opposite of Choppers, you move the enemy frontline back to where it came from. Choose your targets wisely! It does not make sense to do a deepstrike to the airfields, if the enemy owns all FARPs! In order to move along, the FARPs are vital to get choppers going effectively. Make sure you takeout the antennas as well, if the enemy has deployed SAMs in the Wild, and you destroy their antennas, the oldest deployed SAM will be destroyed, assuming the Enemy has used all available SAM-Systems. </p>

					<p>If you fly SEAD, be extra extra cautious to make sure the radar-emitter you are attacking is Enemy! Your team will not like it if you destroy their sams. If you are in doubt, set off a Radio-Call and ask for help identifying your target! If you are lucky you will even have GCI that can easily identify friend or foe for you!</p>


					<h2>"I'm a rotorhead by heart. What can I do in here?"</h2>
					<p>We got you covered, as I'm sure you gathered, helicopters are the heart of the Kaukasus Offensive. Without you, nothing is going to happen, and your Team is guaranteed to loose! You can select from a multitude of tasks:</p>
					<ul>
						<li>Capture Neutral Objectives</li>
						<li>Open FARPs</li>
						<li>Supply and reinforce Objectives</li>
						<li>Rescue Ejected Pilots</li>
						<li>Set up JTACs to get a buddy-laser for F5s and M2000s</li>
						<li>Set up EWR for better overview of your GCIs</li>
					</ul>
					<p>All those tasks will earn you points, which you can trade for Convoys to your current location (not all Objectives have convoys available)</p>

					<p>We would suggest you to focus on getting and keeping FARPs! Once you fortified the FARP of your choice to not loose it quickly, you can focus on other objectives. If your team looses all FARPs, the game is pretty much over for your team. Also holding multiple FARPs greatly reduces flying-distances!</p>

					<h2>"I'm getting kicked for not having SRS, what is this?"</h2>
					<p>SRS is a fantastic piece of Software, that connects to DCS and provides Voice-Radio functionality for your Aircraft! While in FC3 Aircraft, you can use an external radio-overlay, for all other Aircraft SRS adds this functionality to your radio! All you need to do is download SRS, install it, do a quick check of the Audiofunctions and bind at least the "Common PTT" button to talk. Next, open DCS and connect to the Server (SRS should connect automatically, if not just enter the IP you find in the briefing), switch on your Radio, make sure you are tuned on 251MHz AM, and you're good to go!</p>
				</div>
			</section>
			<section class="textBlock" id="Shortbrief">
				<div id="briefingNavBar">
					<div><?php include("briefingnavbar.php"); ?></div>
				</div>
				<div class="textBlockWrapper">
					<h1><center>Shortbrief</center></h1>
					<p><strong>FIGHTERS</strong><br />
						Communicate with your Strikers and Choppers to find out where they need Support. Your task is then to gain and maintain air-superiority in the agreed target area. Fight off any incoming threats or intercept enemy Strikers and Helicopters. </p>
					<p><b>STRIKERS</b><br />
					You have plenty of ground targets to attack. Make sure you also team up with a chopper to capture the objective after you are finished! Also communicating with friendly fighters will help you staying out of enemy ambushes!				</p>
					<p><b>HELICOPTERS</b><br />
					You may choose from a wealth of tasks. You can either build mobile SAM-Units by transporting crates. Perform SAR tasks for ejected Pilots to save their lives. And your most important task is to capture enemy assets once the strikers have cleared the air defenses. Without your efforts the mission will not progress.</p>
				</div>
			</section>
			<section class="textBlock" id="Helicopters">
				<div id="briefingNavBar">
					<div><?php include("briefingnavbar.php"); ?></div>
				</div>
				<div class="textBlockWrapper">
					<h1>Helicopters</h1>
					<p>Transport/Building Objectives and Air-Defenses</p>

					<p>Helicopters are the key unit for The Kaukasus Offensive! Without you fellow rotor head, nothing is going to happen. </p>

					<p>Your most important task is to occupy and supply Objectives. Every Objective has a zone around it. Depending on what is inside the zone, the Objective is either red or blue, strong or weak, or if there are no Units within its Zone, it is neutral. Once a base is neutral it can be occupied. Occupy a base by dropping units via simulated sling loading into the zone (once the MP-Sling Load bug is fixed, you will be able to sling load units with a real sling!). </p>

					<h2>How to do simulated sling loading:</h2>
					<p>After you spawn in a Helicopter (All Helicopters can carry loads!) open the Radio Menu and press F10 for the user-menu. Select F1: "Transport (CTLD)"</p>

					<p>You will be presented with a menu.</p>
					<ul>
						<li>F1-F4 are different Types of groundunits you may place.</li>
						<li>F5 is to drop and unpack crates. You can check if you got crates loaded and find nearby crates</li>
						<li>F6 and F7 Lets you drop smoke markers and radio beacons</li>
					</ul>
					<p>First of all you need a crate in front of you (don't be surprised, it's camouflaged as an offroad car), you will get a message telling you which crate you have spawned. To pick it up you only need to hover above it for 4 seconds. Messages will guide you and let you know that you picked it up! Now bring it to your planned destinations. </p>


					<p>Once you arrived at your planned destination open your radio menu and press F10 to enter the missions menu, F1 for Transport, F5 "CTLD Commands" and F2 to drop the crate. Once you have the crate in front of you and you have landed open the menu agaion (F10-F1-F5) and press F1 to unpack the crate. If everything goes well you should have the selected unit in front of you. If there is a problem, you will get a message stating why the crate could not be unpacked. </p>

					<p>Your main task is to supply Objectives, choose them strategically to improve your tactical position! FARPs are very valuable targets worth reinforcing or occupying if they are neutral.</p>

					<h2>Supplying Objectives</h2>


					<h3>Aerodromes:</h3>
					<p>Aerodromes are very simple Objectives, all they need to operate is at least one friendly unit, it does not matter which one, the Airport only needs to be occupied to be open.</p>


					<h3>FARPs:</h3>
					<p>FARPS are the most complicated Objectives. They can be occupied and open/closed. A FARP will only open if you bring all 3 types of Groundcrew (ATC, Fuel and Ammo) in order to open. It will close again if all Groundcrew units are destroyed (it will stay open even if only one groundcrew unit is left). Make sure to always have groundcrew at the FARP to prevent it from closing!</p>


					<p>Important! Do not place any groundcrew far away from the pads. If the Groundcrew is further away than 200m from a player on the pad, that player will not be able to rearm refuel! Place them close enough to the pads so all players can rearm/refuel!</p>


					<h3>Antennas:</h3>
					<p>While antennas are simple as well, they also server a secondary purpose. The amount of Antennas your team holds defines the amount of SAM systems you can place in the wild (all types of units except MANPADs, EWR and JTACs, which can be placed infinitely). </p>
					<p>Keep in mind, all units placed in the wild only last for 24 hours!</p>

					<h3>Bunkers:</h3>
					<p>If Bunkers are occupied you will be able to spawn crates from them! </p>


					<h3>Main Targets:</h3>
					<p>The Russion Factory and Inguri Dam Fortification spawn crates as well! The dam itself does not.</p>

					<h2>In the Wild</h2>
					<p>You can unpack any crate anywhere, as long as you have antennas! If you only have one antenna, you can only place one unit in the wild. If you however place another one, the oldest unit will be destroyed! If you own all 6 Antennas, you may place 6 Units in the Wild, if you place another one, the oldest will be destroyed. If you loose an Antenna, the oldest Unit placed in the wild will be destroyed as well!</p>

					<p>There are exeptions to the Antenna-rule! You can place as many MANPADs, JTACs and EWRs. </p>


					<p>EWRs will support your GCI with information about enemy activity. They have quite some range but are also easy to detect and destroy, make sure you also bring defenses if you deploy them!</p>


					<p>JTACs are probably the most valuable units you can deploy in the Wild. If placed within 10km LOS to targets, the JTAC will lase the target with code 1688. This laser-spot can bet used to accurately target laserguided Bombs (GBU-12 for example) with A10, F5 and Mirage 2000! Especially the latter are effective means to hit a target with high speed!</p>
				</div>
			</section>
			<section class="textBlock" id="CSAR">
				<div id="briefingNavBar">
					<div><?php include("briefingnavbar.php"); ?></div>
				</div>
				<div class="textBlockWrapper">
					<h1>CSAR</h1>
					<p>Any Pilot who ejects is being saved on the Map. Rescuing them does not only give them a live back, you will also be rewarded points which can be used to send convoys. Capturing an enemy pilot will yield twice the points, but they won't pop smoke or fire signal flares when you're near! You will receive a message though, directing you to the pilot.</p>

					<p>After you spawn in a Transport Helicopter (Mi-8, UH-1) open the Radio Menu and press F10 for the user-menu. </p>


					<p>Select F3: "CSAR" to get into the "Combat Search And Rescue Menu". </p>
					<p>Select F1: "List downed Pilots" to get a list of Pilots. This list consists of real Pilots, who had to eject in combat. If the list is empty, no Pilot has ejected yet. Follow the given heading for the given distance to find the pilot. You can request this anytime. </p>
					<p>Select F2: "Check Onboard": Will give you information on how many pilots you are carrying. You can pick up up to 6 Pilots at once (subject to adjust to actual chopper capabilities)</p>
					<p>Select F3: "Request Signal Flare": If you are within 5 km this will trigger a signal flare to be shot at the pilot's location, you will also be notified about the pilots "o'clock position" relative to you.</p>

					<p>To rescue a pilot you first need to pick him up, by hovering above him, or if possible land within 60m. You can pick up up to 6 pilots in one flight! To actually rescue them, you need to bring them to an Objective and land. Only picking them up will not rescue the pilots!</p>

					<p>Enemy ejected Pilots will not pop smoke or shoot flares!</p>
				</div>
			</section>
			<section class="textBlock" id="Convoys">
				<div id="briefingNavBar">
					<div><?php include("briefingnavbar.php"); ?></div>
				</div>
				<div class="textBlockWrapper">
					<h1>Convoys</h1>
					<p>User your money to call in a convoy you need to be at the location where you want the convoy to go. Use the F10-Radiomenu an press F5 to enter the Convoy menu. With F1 you can see how much money you currently own. The rest is a pricelist of possible convoys.</p>
					<p>Remember: to send a convoy you need to be at the location you want to send a convoy to. <strong>You cannot send convoys to remote locations!</strong></p>
					</ul>
				</div>
			</section>
		</div>
		<section class="textBlock" id="CodeOfEthics">
				<div id="briefingNavBar">
					<div><?php include("briefingnavbar.php"); ?></div>
				</div>
				<div class="textBlockWrapper">
					<h1><center>Code of Ethics</center></h1>
					<p>In order to keep things fun and fair on this server we created this little Code of Ethics. A violation against these terms will be considered an offense, repeated violations will result in a permanent ban.</p>
					<h2>Do not switch to enemy forward observer slots</h2>
					<p>This is an easy one. If you switch to the enemy forward observer to see where units are you are creating an unfair advantage for yourself. Don't even try to think noone will notice, we see everything!</p>
					<h2>Do not place Airdefenses in forests</h2>
					<p>Also a rather easy one. First of all, Helicopters cannot land in forests, just because the Caucasus Map is lacking tree collision detecting does not mean you should do it. Second of all, manpads hidden in forests are not only hard to detect, they are more or less impossible to defeat. Whatever you may think, we think placing defenses in forests is exploiting flaws of DCS and does not improve gameplay at all. It is also very easy to detect a violation against this Point, expect strict enforcement.</p>
					<h2>Take off on the left side of the runway!</h2>
					<p>This has proven to minimize the risk of collisions during takeoff/landing. If you're on radio it is smart to announce your landing or takeoff intentions. "Inbound", "on final", "taxi", "entering/vacating runway" calls improve not only immersion but also keep your team updated on where everyone is.</p>
					<h2>Do not Teamkill</h2>
					<p>For the obvious. Intentional Teamkills will not be tolerated. If you teamkill by accident be fair and apologize with little delay.</p>
				</div>
			</section>
		<div style="height: 200px">&nbsp;</div>
		<?php //print_r($data); ?>
    </body>
</html>
