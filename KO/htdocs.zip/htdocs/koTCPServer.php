<?php
error_reporting(E_ALL);
	
include('source\Helper.php');


class koTCPServer {
    private $address = '0.0.0.0';   // 0.0.0.0 means all available interfaces
	//private $address = '127.0.0.1';   
    private $port = 52525;          // the TCP port that should be used
    private $maxClients = 10;
	private $helper;
 
    private $clients;
    private $socket;
	
	private $receivedScoreIDs;
	
	private $dataBuffer = "";
	
	private $numPacketsReceived = 0;
	
	private $timeLastAliveSent = 0;
 
    public function __construct() {
        // Set time limit to indefinite execution
		$this->log("constructing Socket");
        set_time_limit(0);
        error_reporting(E_ALL ^ E_NOTICE);
		$this->helper = new TAW_Source_Helper();
		$this->receivedScoreIDs = array();
    }
 
    public function start() {
		$this->log("Starting Socket ...");
        // Create a TCP Stream socket
        $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        // Bind the socket to an address/port
        socket_set_option($this->socket, SOL_SOCKET, SO_REUSEADDR, 1);
        socket_bind($this->socket, $this->address, $this->port);
        // Start listening for connections
        socket_listen($this->socket, $this->maxClients);
		
		$timeLastAliveSent = time();
 		$sendAlive = false;
 
        $this->clients = array('0' => array('socket' => $this->socket));
		
		$this->log("socket started, looking for connection ...");
 
        while (true) {
            // Setup clients listen socket for reading
			$read = array();
            $read[0] = $this->socket;
			
            for($i=1; $i < $this->maxClients+1; $i++) {
                if($this->clients[$i] != NULL) {
                    $read[$i+1] = $this->clients[$i]['socket'];
                }
            }
			
			$write = NULL;
			//$write = $read;
			$except = NULL;
 
            // Set up a blocking call to socket_select()
			$ready = socket_select($read, $write, $except, $tv_sec = NULL);
			
			if (false === §ready) {
				echo "socket_select() failed, reason: " . socket_strerror(socket_last_error()) . "\n";
			}
            
            /* if a new connection is being made add it to the client array */
            if(in_array($this->socket, $read)) {
				$this->message("new connection");
				
				$newSocket = socket_accept($this->socket);
				socket_getpeername($newSocket, $ip);
				
                for($i=1; $i < $this->maxClients+1; $i++) {
					if(!isset($this->clients[$i])) {
						
						$this->clients[$i]['socket'] = $newSocket;
                        $this->clients[$i]['ipaddress'] = $ip;
						$this->clients[$i]['txbuf'] = '';
						$this->clients[$i]['rxbuf'] = '';
 						
						//socket_write($this->clients[$i]['socket'], 'Welcome to my Custom Socket Server'."\r\n");
                        //socket_write($this->clients[$i]['socket'], 'There are '.(count($this->clients) - 1).' client(s) connected to this server.'."\r\n");
 
                        $this->log("New client #$i connected, ip: " . $this->clients[$i]['ipaddress'] . " maxclients = " . $this->maxClients);
                        break;
						
                    } elseif($this->clients[$i]['ipaddress'] == $ip) {
						$this->clients[$i]['socket'] = $newSocket;
						
						$this->log("client #".$i.", ip: ".$ip." reconnected");
						
						$oldRXBuf = $this->clients[$i]['rxbuf'];
						$this->log("- old rxbuf: '$oldRXBuf'");
						break;
						
					} elseif($i == $this->maxClients) {
                        $this->message('Too many Clients connected!');
                    }
 
                    if($ready < 1) {
                        continue;
                    }
                }
            }
			
			$sendAlive = false;
			$timeSinceLastAliveSent = time() - $this->timeLastAliveSent;
			if($timeSinceLastAliveSent > 5) {	// send alive packet every 5 seconds
				$sendAlive = true;
				$this->timeLastAliveSent = time();
				
				foreach($this->clients as $i => $client) {
					if ($i > 0) {
						$this->message(" - sending alive packet to client #$i '".$client['ipaddress']."'");
						$this->clients[$i]['txbuf'] .= '{"type":"alive"}\n';
					}
				}
			}
			
			/*$timeSinceLastAliveReceived = $this->timeLastAliveReceived - time();
			if($timeSinceLastAliveSent > 10) {	// send alive packet every 5 seconds
				$this->log("no alive received in 10 seconds, maybe unresponsive?");
			}*/
 
            // If a client is trying to write - handle it now
            for($i=1; $i < $this->maxClients+1; $i++) {
				// if theres something to read from the client
                if(in_array($this->clients[$i]['socket'], $read)) {
					$data = @socket_read($this->clients[$i]['socket'], 1024000, PHP_NORMAL_READ);
 
                    if($data == null) {
						$this->log('Client #'.$i.', '.$this->clients[$i]['ipaddress'].' disconnected!');
						
						//update server status
						if($this->clients[$i]['status'] != "restarting") 
							$this->helper->setServerStatus($this->clients[$i]['serverID'], "disconnected");
						
                        unset($this->clients[$i]);
                        
                        continue;
                    }
 
                    // Data received!
                    if(!empty($data)) {
						$this->numPacketsReceived++;
						$this->message($this->numPacketsReceived.": We have data!: '".strval($data)."'");
						
						// check if data is complete
						$dataBuffer =& $this->clients[$i]['rxbuf'];
						$dataBuffer .= $data;
						
						$endIdx = strpos($dataBuffer, "\n");
						//if($endIdx === false) $this->log("data incomplete ..."); else $this->message("data complete!");

						while($endIdx !== FALSE) {
							//$this->message(" - complete data received - ");
							
							// this should be a valid json string, always
							$jsonString = substr($dataBuffer, 0, $endIdx);
							
							// check if json decoded valid
							$newObject = json_decode($jsonString);
							if(isset($newObject) and gettype($newObject) == "object") {
								if(!isset($newObject->serverName) && $newObject->type != "dummy") {
									$this->message("----------------\nFATAL ERROR - no serverName supplied\n----------------");
									return;
								}
								
								$serverID = $this->helper->getServerID($newObject->serverName);
								
								$this->clients[$i]['serverID'] = $serverID;
								
								$this->message("Data received and valid, serverName = '".$newObject->serverName."', serverID = ".$serverID.", type = ".$newObject->type);
								
								if($serverID) {
									// now check where data should go:
									switch ($newObject->type) {
										case 'Savegame':
											$this->helper->processSavegame($newObject->data, $serverID);
											continue;
										case 'Score':
											// debug filehandling
											/*$logfile = 'receivedScores.txt';
											$file_handle = fopen($logfile, 'a') or die('Cannot open file:  '.$logfile); //open file for writing
											fwrite($file_handle, $newObject->data->scoreID."\n");
											fclose($file_handle);*/
											//var_dump($newObject->data);
											
											$skip = false;
											foreach($newObject->data as $ucid => $score) {
												if(isset($this->receivedScoreIDs[strval($score->scoreID)])) {
													$this->message('score id '.$score->scoreID.'/"'.$score->achievment.'" has already been received! skipping');
													$this->clients[$i]['txbuf'] .= '{"type":"scoreReceived","scoreID":"'.$score->scoreID.'"}\n';
													$skip = true;
													continue;
												} else
													$this->receivedScoreIDs[strval($score->scoreID)] = true;
												   
												$this->message('score "'.$score->achievment.'" received. Returning scoreID '.$score->scoreID.' to server');
												$this->clients[$i]['txbuf'] .= '{"type":"scoreReceived","scoreID":"'.$score->scoreID.'"}\n';
											}
											
											if($skip == false)
												$this->helper->processScore($newObject->data, $serverID);
											
											continue;
										case 'PlayerList':
											$this->helper->processPlayerList($newObject->data, $serverID);
											continue;
										case 'srsPlayerData':
											$this->helper->processRadio($newObject->data, $serverID);
											continue; 
										case 'alive':
											//$this->message("ALIVE PACKET RETURNED!");
											$this->helper->setServerStatus($this->clients[$i]['serverID'], "online");
											$this->clients[$i]['timeLastAliveReceived'] = time();
											continue;
										case 'restart':
											$this->log("client $i (ip: ".$this->clients[$i]['ipaddress'].") is restarting ...");
											$this->clients[$i]['status'] = "restarting";
											$this->helper->setServerStatus($this->clients[$i]['serverID'], "restarting");
									 }
								} elseif ($newObject->type == 'Savegame') {
									$this->log("Savegame without serverID received!");
									$this->helper->processSavegame($newObject->data, -1);
								} else
									$this->message("Datahandling failed - no serverID!");
							} else {
								$this->log("FATAL ERROR: data received but Invalid!");
								$this->log("json_last_error: ".json_last_error());
								$this->log("jsonString: '$jsonString");
								$this->log("dataBuffer: '$dataBuffer'");
								$this->log("dataBuffer after trim: '".substr($dataBuffer, $endIdx+2, strlen($dataBuffer))."'");
								
								$file = 'failedstring.txt';
								$file_handle = fopen($file, 'a') or die('Cannot open file:  '.$file); //open file for writing
								fwrite($file_handle, $dataBuffer);
								fclose($file_handle);
							}
								
							// remove json string from $dataBuffer
							$dataBuffer = substr($dataBuffer, $endIdx+1, strlen($dataBuffer));
							
							$this->message("datahandling end");
							
							$endIdx = strpos($dataBuffer, PHP_EOL);
						}
                    }
                } // end if client read
				
				
				// now send stuff
				if(isset($this->clients[$i])) {
				//if(in_array($this->clients[$i]['socket'], $write)) {
					
					// if theres something so send to the client, send it
					if(strlen($this->clients[$i]['txbuf']) > 0) {
						$this->message("sending to '".$this->clients[$i]['ipaddress']."' ...");
						
						$length = strlen($this->clients[$i]['txbuf']);
						$result = socket_write($this->clients[$i]['socket'], $this->clients[$i]['txbuf'], $length);

						if($result === false) {
							$this->message("send failed");
						} else {
							$this->clients[$i]['txbuf'] = substr($this->clients[$i]['txbuf'], $result);
							$this->message("txbuf post-send for client $i = '".$this->clients[$i]['txbuf']."'");
							$this->message("$result Bytes have been sucessfully sent to '".$this->clients[$i]['ipaddress']."'");
						}
					}


					// check if client has responded to alive packets
					$timeSinceLastAlive = time() - $this->clients[$i]['timeLastAliveReceived'];
					if($timeSinceLastAlive > 10) {
						if($timeSinceLastAlive > 60)
							$this->helper->setServerStatus($this->clients[$i]['serverID'], "offline");
						elseif(!$this->clients[$i]['status'] != "restarting") 
							$this->helper->setServerStatus($this->clients[$i]['serverID'], "unresponsive");
					}
				}
            } // end for clients
        } // end while
    }
	
	private function message($msg) {
        // instead of echoing to console we could write this to a database or a textfile
        echo "[".date('Y-m-d H:i:s')."] " . $msg . "\r\n";
	}
 
    private function log($msg) {
        // instead of echoing to console we could write this to a database or a textfile
        echo "[".date('Y-m-d H:i:s')."] " . $msg . "\r\n";
		$logFile = 'tcpserver.log';
		$file_handle = fopen($logFile, 'a') or die('Cannot open file:  '.$logFile); //open file for writing
		//fwrite($file_handle, "scoreID: ".$score->scoreID." received, count(container) =".count($scoreContainer)."\n");
		fwrite($file_handle, "[".date('Y-m-d H:i:s')."] ".$msg."\n");
		fclose($file_handle);
    }
}

$TCPServer = new koTCPServer();
$TCPServer->start();

// debug filehandling
/*$this->log("Writing to file...");
$my_file = 'file'.$this->numPacketsReceived.'.txt';
$file_handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file); //open file for writing
fwrite($file_handle, $data);
fclose($file_handle);*/

?>