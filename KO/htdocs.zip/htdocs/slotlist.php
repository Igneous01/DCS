<?php if(!isset($helper)): 
	$standaloneSlotlist = true;
	echo "new helper<br>".PHP_EOL;
	include('source/Helper.php');
	$helper = new TAW_Source_Helper(); 
	
	$data = $helper->getMainData(4);

	$coaColors = array(
		0 => "#FFFFFF",
		1 => "#e20000",
		2 => "#1564e1",
	);
?>

<html>
	<head>
		<link rel="shortcut icon" type="image/ico" href="assets/images/tkosignet.ico" />
		<title>The Kaukasus Offensive</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/css/slotlist.css" rel="stylesheet" type="text/css">
	<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
	<body>
		<section style="width: 100%;">
	<?php endif; ?>
			<div id="SlotListWrapper">
				<div class="SlotListCoalition" id="SlotListRed">
					<h2 class="CoalitionHeader"><font color="#e20000">RED SLOTS:</font></h2>
					<div class="SlotListCoalitionWrapper"><?php 
							foreach($data['balanced'][1] as $catname => $catTable):?>
							<div class="SlotListCat">
								<div class="SlotListCatHeader">
									<b><?php echo strtoupper($catname); ?></b>
								</div><?php
								foreach($catTable as $pilot):?>  
								<div class="SlotEntry">
									<img class="SlotImage" alt="<?php echo $pilot['type'] ?>" title="<?php echo $pilot['type'] ?>" src="assets/images/airframes/<?php echo $pilot['type'] ?>.png">
									<?php if(isset($pilot['pid'])) echo '<a href="pilot.php?pid='.$pilot['pid'].'">' ?><font color="<?php echo $coaColors[$pilot['coalition']]?>"><?php echo $pilot['name']; ?></font><?php if(isset($pilot['pid'])) echo "</a> "; 
									
									//var_dump($pilot);
									if(isset($pilot['radios'])) {
										//echo "has radios!";

										foreach ($pilot['radios'] as $radio) {
											if($radio['selected'] == 1)
												echo '<font color="#444444">'.($radio['frequency']/1000000).' MHz</font>';
										}
									}
									?>
								</div>		
					<?php 	endforeach; ?></div>
						<?php	endforeach; ?>
					</div>
				</div>
				<div class="SlotListCoalition" id="SlotListBlue"> 
					<h2 class="CoalitionHeader"><font color="#1564e1">BLUE SLOTS:</font></h2>
					<div class="SlotListCoalitionWrapper"><?php foreach($data['balanced'][2] as $catname => $catTable):?>
							<div class="SlotListCat">
								<div class="SlotListCatHeader">
									<b><?php echo strtoupper($catname); ?></b>
								</div><?php
								foreach($catTable as $pilot):?>  
								<div class="SlotEntry">
									<img class="SlotImage"alt="<?php echo $pilot['type'] ?>" title="<?php echo $pilot['type'] ?>" src="assets/images/airframes/<?php echo $pilot['type'] ?>.png">
									<?php if(isset($pilot['pid'])) echo '<a href="pilot.php?pid='.$pilot['pid'].'">' ?><font color="<?php echo $coaColors[$pilot['coalition']]?>"><?php echo $pilot['name']; ?></font><?php if(isset($pilot['pid'])) echo "</a> "; ?><?php 
										//var_dump($pilot);
										if(isset($pilot['radios'])) {
											//echo "has radios!";
											
											foreach ($pilot['radios'] as $radio) {
												if($radio['selected'] == 1)
													echo '<font color="#555555">'.($radio['frequency']/1000000).' MHz</font>';
											}
											
										}
									?>
								</div>
					<?php 	endforeach; ?></div>							
						<?php	endforeach; ?>
					</div>
				</div>
			</div>
		<?php if (isset($standaloneSlotlist)): ?>
		</section>
    </body>
</html>
<?php endif; ?>