			<button onclick="location.href='http://tawdcs.org';" >TAW-DCS</button>
			<button onclick="location.href='index.php';" >Introduction</button>
			<button onclick="location.href='index.php#map';">Web-Map</button>
			<button onclick="location.href='index.php#PlayerList';">Online Players</button>
			<button onclick="location.href='briefing.php';">Briefing</button>
			<button onclick="location.href='./statistics.php';" value="Go to Google" >Statistics</button>