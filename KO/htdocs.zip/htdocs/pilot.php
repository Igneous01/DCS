<?php
include('source/Helper.php');
$helper = new TAW_Source_Helper();
$pid = htmlspecialchars($_GET["pid"]);

$_weapons = $helper->getWeaponsUsed();
$data = $helper->getScoreForPilot($pid);

//var_dump($data);

//var_export($weapons);
?>
<html>
	<head>
		<link rel="shortcut icon" type="image/ico" href="assets/images/tkosignet.ico" />
		<title>The Kaukasus Offensive - STATISICS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/css/pilotStats.css" rel="stylesheet" type="text/css">
	<link href="assets/tablesorter/css/theme.dark.css" rel="stylesheet" type="text/css">
	<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.js"></script> 	
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.widgets.js"></script>

	<script>

	</script>
	
	<body>
		<?php include_once('analyticstracking.php'); ?>
		<header>
			<?php include("navbar.php"); ?>
		</header>
		<div id="PilotStats">
			<div id="PilotStatsWrapper">
					<div id="PilotStatsHeader">
						<div style="font-size: 18px;">Pilot Statistics for</div>
						<div style="font-size: 48px; color: <?php echo $coaColors[$data['side']]?>;font-weight: bold; margin-top: -5px; font-family: 'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; margin-bottom: 0px;"><?php echo $data['playerName'] ?></div>
						<div style="font-size: 16px; color: #999999;"><?php echo $data['airtime']['favAircraftCat']; ?></div>
					</div>
					<div style="height: 100px;"></div>
					<section class="PilotStatsBlock" id="PilotStatsAirtime">
						<div class="PilotStatsBlockHeader">
							Pilots Experience
						</div>
						<div style="height: 15px;">&nbsp;</div>
						<div class="PilotStatsContainer">
							<table class="statsTable">
								<tbody>
								<tr>
									<td align="right" class="leftTab">Favorite Aircraft</td>
									<td width="10">&nbsp;</td>
									<td class="rightTab"><?php echo $data['airtime']['favoriteType']; ?></td>
								</tr>
								<tr>
									<td class="leftTab"></td>
									<td width="10">&nbsp;</td><?php
									$favAircraftTime = "0h 0min";
									if(isset($data['airtime']['types'][$data['airtime']['favoriteType']]))
										$favAircraftTime = $data['airtime']['types'][$data['airtime']['favoriteType']];
										
									?><td class="rightTab"><?php echo $favAircraftTime; ?></td>
								</tr>
								<tr>
									<td colspan="5">&nbsp;</td>
								</tr>
								<tr>
									<td align="right" class="leftTab"><b>Total Airtime:</b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['airtime']['total']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab"><b>Sorties flown:</b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['achievments']['sortie']; ?></td>
								</tr>
								<tr>
									<td colspan="5">&nbsp;</td>
								</tr>
								<tr>
									<td align="right" class="leftTab"><b>Hours Fixed Wing:</b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['airtime']['AIRPLANE']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab"><b>Hours Helicopters:</b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['airtime']['HELICOPTER']; ?></td>
								</tr>
								<tr>
									<td colspan="5">&nbsp;</td>
								</tr>
								<tr>
									<td align="right" class="leftTab"><b>In Fighter-Jets:</b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['airtime']['FIGHTER']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab"><b>Ground Attack Mode:</b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['airtime']['ATTACKER']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab"><b>Slingload Expertise:</b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['airtime']['TRANSPORT']; ?></td>
								</tr>
								<tr>
									<td colspan="5">&nbsp;</td>
								</tr>
								<tr>
									<td align="right" class="leftTab"><b>Hours for red:</b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['airtime']['red']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab"><b>Hours for blue:</b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['airtime']['blue']; ?></td>
								</tr>
								<tr>
									<td colspan="5">&nbsp;</td>
								</tr>
								<?php foreach($data['airtime']['types'] as $type => $airtime): ?>
								<tr>
									<td align="right" class="leftTab"><b><?php echo $type ?></b></td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $airtime ?></td>
								</tr>	
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</section>
					<section class="PilotStatsBlock" id="PilotStatsReliability">
						<div class="PilotStatsBlockHeader">
							Reliability
						</div>
						<div style="height: 15px;">&nbsp;</div>
						<div class="PilotStatsContainer">
							<table class="statsTable">
								<tbody>
									<tr>
										<td align="right" class="leftTab">Takeoff</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $data['achievments']['takeoff']; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">Landings</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $data['achievments']['landing']; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">Landings per Takeoff:</td>
										<td width="10">&nbsp;</td>
										<?php
											$landingsPerTakeoff = "0/0";
											if($data['achievments']['takeoff'] != 0)
												$landingsPerTakeoff = round($data['achievments']['landing']/$data['achievments']['takeoff']*10, 1)."/10";
												
										?><td class="rightTab"><?php echo $landingsPerTakeoff; ?></td>
									</tr>
									<tr>
										<td colspan="5">&nbsp;</td>
									</tr>
									<tr>
										<td align="right" class="leftTab">Deaths</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $data['achievments']['died']; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">Crashes</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $data['achievments']['crashed']; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">Ejected</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $data['achievments']['ejected']; ?></td>
									</tr>
									<tr>
										<td colspan="5">&nbsp;</td>
									</tr>
									<tr>
										<td align="right" class="leftTab">A2A Kill/Death Ratio:</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php 
											if($data['achievments']['died'] > 0)
												echo round($data['victories']['A2A']/$data['achievments']['died'],1);
											else
												echo $data['victories']['A2A']; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">A2A Kill/Eject Ratio:</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php 
											if($data['achievments']['ejected'] > 0)
												echo round($data['victories']['A2A']/$data['achievments']['ejected'],1);
											else
												echo $data['victories']['A2A']; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">A2G Kill/Death Ratio:</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php  
											if($data['achievments']['died'] > 0)
												echo round($data['victories']['A2G']/$data['achievments']['died'],1);
											else
												echo $data['victories']['A2G']; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">A2G Kill/Crash Ratio:</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php   
											if($data['achievments']['crashed'] > 0)
												echo round($data['victories']['A2G']/$data['achievments']['crashed'],1);
											else
												echo $data['victories']['A2G']; ?></td>
									</tr>
									<tr>
										<td colspan="5">&nbsp;</td>
									</tr>
									<tr><?php $hours = $data['airtime']['totalSecs'] / 3600; ?>
										<td align="right" class="leftTab">Kills per Hour:</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php   
											if($data['achievments']['kill'] > 0 and $hours > 0)
												echo round($data['achievments']['kill']/$hours,1);
											else
												echo "0"; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">Deaths per Hour:</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php   
											if($data['achievments']['died'] > 0 and $hours > 0)
												echo round($data['achievments']['died']/$hours,1);
											else
												echo "0"; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">Crashes per Hour:</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php   
											if($data['achievments']['crashed'] > 0 and $hours > 0)
												echo round($data['achievments']['crashed']/$hours,1); ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">Ejection per Hour:</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php   
											if($data['achievments']['ejected'] > 0 and $hours > 0)
												echo round($data['achievments']['ejected']/$hours,1);
											else
												echo "0"; ?></td>
									</tr>
									<tr><?php $numCrates = $data['achievments']['crate_deployed']+$data['achievments']['neutral_base_occupied']+$data['achievments']['cargo_unpacked_in_zone']; ?>
										<td align="right" class="leftTab">Crates delivered per Hour:</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php   
											if($data['achievments']['died'] > 0 and $hours > 0)
												echo round($numCrates/$hours,1);
											else
												echo "0"; ?></td>
									</tr>
								</tbody>
							</table>
						</div>
					</section>
					<section class="PilotStatsBlock" id="PilotStatsVictories">
						<div class="PilotStatsBlockHeader">
							Victories
						</div>
						<div style="height: 15px;">&nbsp;</div>
						<div class="PilotStatsContainer">
							<table class="statsTable">
								<tbody>
								<tr>
									<td align="right" class="leftTab">Air 2 Air</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['victories']['A2A']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab">Air 2 Ground</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['victories']['A2G']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab">Ground 2 Air</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['victories']['G2A']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab">Ground 2 Ground</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['victories']['G2G']; ?></td>
								</tr>
								<tr>
									<td colspan="5">&nbsp;</td>
								</tr>
								<tr>
									<td align="right" class="leftTab">Bases Occupied</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['achievments']['neutral_base_occupied']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab">Bases Supplied</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['achievments']['cargo_unpacked_in_zone']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab">SAMS deployed in the Wild</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['achievments']['crate_deployed']; ?></td>
								</tr>
								<tr>
									<td colspan="5">&nbsp;</td>
								</tr>
								<tr>
									<td align="right" class="leftTab">Pilots Rescued</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['achievments']['pilot_rescued']; ?></td>
								</tr>
								<tr>
									<td align="right" class="leftTab">Pilots Captured</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['achievments']['pilot_captured']; ?></td>
								</tr>
								<tr>
									<td colspan="5">&nbsp;</td>
								</tr>
								<tr>
									<td align="right" class="leftTab">Convoys Deployed</td>
									<td width="10">&nbsp;</td>
									<td align="left" class="rightTab"><?php echo $data['achievments']['convoy_deployed']; ?></td>
								</tr>
								</tbody>
							</table>
						</div>
					</section>
					<section class="PilotStatsBlock" id="PilotStatsWeapons">
						<div class="PilotStatsBlockHeader">
							Weapon Usage
						</div>
						<div style="height: 15px;">&nbsp;</div>
						<div class="PilotStatsContainer">
							<table class="statsTable">
								<tbody>
									<?php foreach($data['weapons'] as $weaponCat => $weapons): ?>
									<tr>
										<td class="tabHeader" colspan="3"><?php echo strtoupper($weaponCat)."s" ?></td>
									</tr>
									
									<?php foreach($weapons as $weaponName => $weapon): ?>
									<tr>
										<td >&nbsp;</td>
										<td width="10">&nbsp;</td>
										<td class="leftTab"><b><?php echo $weaponName ?></b></td>
									</tr>
									<?php 
										if (!isset($weapon['hit']))
											$weapon['hit'] = 0;
										if (!isset($weapon['shot']))
											$weapon['shot'] = 0;
										if (!isset($weapon['kill']))
											$weapon['kill'] = 0; 
											
										$pk = "0%";
										if($weapon['kill'] != 0 and $weapon['shot'] != 0)
											$pk = round(($weapon['kill']*100)/$weapon['shot'], 1)."%";
										$ph = "0%";
										if($weapon['hit'] != 0 and $weapon['shot'] != 0)
											$ph = round(($weapon['hit']*100)/$weapon['shot'], 1)."%";
									?><tr>
										<td align="right" class="leftTab">Shots</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $weapon['shot']; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">PK %</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $pk; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">PH %</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $ph; ?></td>
									</tr>
									<tr>
										<td align="right" class="leftTab">Hits</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $weapon['hit']; ?></td>
									</tr>
									
									<tr>
										<td align="right" class="leftTab">Kills</td>
										<td width="10">&nbsp;</td>
										<td class="rightTab"><?php echo $weapon['kill']; ?></td>
									</tr>
									<?php endforeach; ?>
									<tr>
										<td class="tdSpacer" colspan="3">&nbsp;</td>
									</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</section>
					
				</div>
			</div>
		</div>
		
		<?php
		//print_r($data);
		?>
    </body>
</html>