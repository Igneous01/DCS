<?php 
	if(!isset($helper)):
		setcookie("serverSelected");
		include('source/Helper.php');
		$helper = new TAW_Source_Helper(); 

		$serverName = "TAW EU 3";
		$serverID = $helper->getServerID($serverName);

		// load cookie
		if(isset($_COOKIE["serverSelected"])) 
			$serverID = $_COOKIE["serverSelected"];

		//echo $serverID.PHP_EOL;

		$map = $helper->getMap($serverID);

?>

<html>
	<head>
		<link rel="shortcut icon" type="image/ico" href="assets/images/tkosignet.ico" />
		<title>The Kaukasus Offensive</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/css/map.css" rel="stylesheet" type="text/css">
	<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
	<script>
		setInterval("refreshContent();", 10000);
		
		//var webroot = "https://164.132.233.62/ko";
		var webroot = "";
		function refreshContent() {
			console.log("map.php: refreshContent()")
			$("#map").load(webroot+" #mapWrapper", function() {
				handleResize();
				
				for (i = 0; i < infoBoxSetups.length; i++) {
					var data = infoBoxSetups[i];
					infoBoxSetup(data.symID, data.boxID, true);
				}
				
				if($turnedOn) {
					$($turnedOn).removeClass("hidden");
					//$($turnedOn).css("z-index", "100");
				}
				
				console.log("map was refreshed (map.php orig!)");
			});
		}
	</script>

	
	<?php 
	
	endif; 
	// ENDIF
	//---------------------
	
	
	
	$serverDescriptionPath = "Servers/Server$serverID.php";
	include($serverDescriptionPath);
	?>
	
		<script src="map.js"></script>
		<section id="map">
			<div id="mapWrapper">
				<!--<div id="serverSelector" class="dropdown">
					<button onclick="openDropdown()" class="dropbtn">Select Server</button>
					  <div id="serverSelectorDropdown" class="dropdown-content">
						<a href="#map" onClick="selectServer(4)">TAW EU3 - The Kaukasus Offensive</a>
						<a href="#map" onClick="selectServer(5)">DEADBEEFS LAIR - TKO Vietnam</a>
					  </div>
				</div>-->
				<div id="mapContainer">
					<img id="mapImage" src=<?php echo $mapImageFile; ?> />
					<img id="mapLogo" src="assets/images/map/livemaplogo.png" />
					<div id="mapImages">
	
					<?php 
							//echo "loading map";
							//print_r($map);
							foreach($map as $objective):
								//echo "happening";
								//print_r($objective);
								$properties = $mapPositions[$objective['name']];
								$posX = 0;
								$posY = 0;

								if($properties['edge'] == 'tr') {
									$posX = $properties['x'] - $symbolSize; 
									$posY = $properties['y']; 
								} elseif($properties['edge'] == 'br') {
									$posX = $properties['x'] - $symbolSize; 
									$posY = $properties['y'] - $symbolSize; 
								} elseif($properties['edge'] == 'bl') {
									$posX = $properties['x']; 
									$posY = $properties['y'] - $symbolSize;
								} else {
									$posX = $properties['x'] - $symbolSize / 2; 
									$posY = $properties['y'] - $symbolSize / 2; 
								}

								$coaColor = '#505050';
								if($objective['coalition'] == "red") {
									$coaColor = '#e20000';
								} elseif ($objective['coalition'] == "blue") {
									$coaColor = '#1564e1';
								}
								
								// start the objective division
								echo '	<div id="objective_'.str_replace(' ','',$objective["name"]).'" style="position: absolute; top: '.$posY .'px; left: '.$posX.'px;">';
								
								// save the original position of the objective: 
								
						
						
								if($properties['edge'] != 'none') {
									echo '
							<img class="mapSymbol" src="assets/images/map/circle_corner_'.$properties["edge"].'.png" style="position: absolute; top: 0px; left: 0px"/>';
								}
								echo '
							<a href="#'.str_replace(' ','',$objective["name"]).'" id="'.str_replace(' ','',$objective["name"]).'Symbol"><img class="mapSymbol" src="assets/images/map/'.$properties["symbol"].'_'.$objective['coalition'].'.png"  />
							';
							if($objective['underAttack']) {
								echo '<img class="mapAttack" src="assets/images/map/explosion.png" /></a>
							';
							} else {
								echo '</a>
							';
							}
							echo '<div class="mapInfoBox hidden" id="infoBox_'.str_replace(' ','',$objective["name"]).'">
								<h1 class="mapInfoBox" style="color:'.$coaColor.'">'.$objective["name"].'</h1>
								<p class="mapInfoBox">
									'.$properties["mgrs"].'<br/><br/>
									Coalition: <b>'.$objective['coalition'].'</b><br />
									';
										if($objective['category'] == 'Aerodrome' or $objective['category'] == 'FARP') {
											echo 'Status: <b>';
											echo $objective['status'].'</b><br/>
									';
										}
										if($objective['numUnits'] > 0) {
											echo 'Number of Units: <b>'.$objective['numUnits'].'</b><br/>
									';
										}
										if($objective['underAttack']) {
											echo '<br /><b>Under Attack!</b><br/>
								';
										}
								echo '</p>
							</div>
						</div>
						<script type="text/javascript" charset="utf-8">
							infoBoxSetup("#'.str_replace(' ','',$objective["name"]).'Symbol", "#infoBox_'.str_replace(' ','',$objective["name"]).'");
						</script> 
					';

							endforeach;
				?>
	</div>
					<div id="objectiveList">
	<?php 

							foreach($map as $objective):
								$properties = $mapPositions[$objective['name']];
								echo '					<div class="objectiveListItem" id='.str_replace(" ","",$objective['name']).'>
							<img class="objectiveListImage" src="assets/images/map/'.$properties["symbol"].'_'.$objective['coalition'].'.png" /> '.$objective['name'].'
						</div>'.PHP_EOL;
								echo '
						<script type="text/javascript" charset="utf-8">
							infoBoxSetup("#'.str_replace(' ','',$objective["name"]).'", "#infoBox_'.str_replace(' ','',$objective["name"]).'");
						</script>'.PHP_EOL;
						endforeach;?>
					</div>
					<div id="MapTawLogo"><img id="MapTawLogoImg" src="assets/logos/tawsealsourcev150pixels.png" /></div>
					<?php //include("balanceOverview.php");	?>
					<font color="#555555" size="1.5px">last updated at: <?php echo $map[0]['updated_at']; ?> GMT+1</font>
				</div>
			</div>
		</section>