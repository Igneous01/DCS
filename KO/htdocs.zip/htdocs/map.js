// JavaScript Document


function is_touch_device() {
	"use strict";
 	return 'ontouchstart' in window || navigator.maxTouchPoints;       
}

var mapImagePositions = [];

$(document).ready(function() { 
	"use strict";
	
	// remember all original positiosn
	$('#mapImages > div').each(function () {
		var pos = {	id: $(this).context.id,	top: $(this).css('top'), left: $(this).css('left') };
		mapImagePositions.push(pos);
	});
	
	handleResize();
}); 


function handleResize(newMapImagePos) {
	"use strict";
	
	console.log("handleResize()");
	if(typeof newMapImagePos !== 'undefined') {
		mapImagePositions = newMapImagePos;
	}
	
	var mapWidth = $(window).width();
	if(mapWidth >= 1600) {
		mapWidth = 1600;
	}
	var scale = mapWidth/1600;

	$('#mapImages > div').each(function () {
		var origSize = getOrigWidth($(this).context.id);
		var newTop = parseInt(origSize.top) * scale;
		var newLeft = parseInt(origSize.left) * scale;
		$(this).css('top', newTop+'px');
		$(this).css('left', newLeft+'px');
		$('.mapSymbol').css('height', 40*scale+'px');
		$('img.mapAttack').css('width', 40*scale+'px');
		$('img.mapAttack').css('left', -15*scale+'px');
		$('img.mapAttack').css('top', -15*scale+'px');
	});

	$('#introduction').css('background-size', 1600*scale+'px');
	$('#mapLogo').css('top', 20*scale+'px');
	$('#mapLogo').css('left', 20*scale+'px');
	$('#mapLogo').css('width', 856*scale+'px');
	$('#objectiveList').css('top', 350*scale+'px');
	$('#objectiveList').css('left', 1111*scale+'px');
	$('#objectiveList').css('width', 467*scale+'px');
	$('.objectiveListItem').css('font-size', 17*scale+'px');
	$('.objectiveListItem').css('padding-bottom', 15*scale+'px');
	$('.objectiveListImage').css('width', 25*scale+'px');
	$('.objectiveListImage').css('top', 5*scale+'px');
	$('.mapInfoBox').css('left', 50*scale+'px');
	$('.mapInfoBox').css('width', 300*scale+'px');
	$('.mapInfoBox').css('padding-top', 10*scale+'px');
	$('.mapInfoBox').css('padding-right', 10*scale+'px');
	$('.mapInfoBox').css('padding-left', 17*scale+'px');
	$('h1.mapInfoBox').css('font-size', 20*scale+'px');
	$('h1.mapInfoBox').css('margin-left', -50*scale+'px');
	$('h1.mapInfoBox').css('padding-bottom', 15*scale+'px');
	$('p.mapInfoBox').css('top', 25*scale+'px');
	$('p.mapInfoBox').css('font-size', 14*scale+'px');
	$('p.mapInfoBox').css('margin-left', -50*scale+'px');
	$('p.mapInfoBox').css('padding-bottom', 15*scale+'px');
	$('#MapTawLogoImg').css('width', 150*scale+'px');
	$('#MapTawLogo').css('top', 10*scale+'px');
	$('#MapTawLogo').css('right', 10*scale+'px');
}

$(window).resize(function() {
	"use strict";
	handleResize();
});

function getOrigWidth(obj) {
	"use strict";
	
	for (var i = 0; i < mapImagePositions.length; i++) {
		if (mapImagePositions[i].id === obj) {
			return mapImagePositions[i];
		}
	}
	console.log("getOrigWidth(obj = '"+obj+"'): obj not found!");
	return 0;
}

var infoBoxSetups = [];

// infoboxes
var $lastToggle;
var $turnedOn = false;
var $hoverOn = false;

var $zIndex = 0;
function infoBoxSetup(symbolID, infoBoxID, initialized) {
	//console.log("infobox setup");
	
	"use strict";

	// keep track for after reload
	if(!initialized) {
		var newSetup = { symID: symbolID, boxID: infoBoxID };
		infoBoxSetups.push(newSetup);			
	}
	var $infoBox = $(infoBoxID);
	var $infoTrigger = $(symbolID);

	$infoTrigger.hover(function() {
		if (is_touch_device()) {
			return;
		}

		if($infoBox.hasClass("hidden")) {
			$infoBox.removeClass("hidden");
			$zIndex = $infoBox.css("z-index");
			$infoBox.css("z-index", "1000");
			console.log("zIndex = "+$infoBox.css("z-index"));
			$turnedOn = false;
			$hoverOn = $infoBox;
		} else {
			$turnedOn = $infoBox;
		}

	},function() {
		if (is_touch_device()) {
			return;
		}
		
		// hide if it is visible and has not been turned On
		if(!$infoBox.hasClass("hidden") && !$turnedOn) {
			$infoBox.addClass("hidden");
			$infoBox.css("z-index", "100");
			$hoverOn = false;
		}
	});

	$infoTrigger.on("click", function(e) {
		e.preventDefault();
		//$(".mapInfoBox").addClass("hidden");

		// find the box to switch on, unless its already on
		var $newToggle = infoBoxID;
		console.log("last toggle = "+$lastToggle);
		if($newToggle === $lastToggle) {
			console.log("same toggle");
			if($turnedOn) {
				$turnedOn = false;
				console.log("- was turned on");
			}


			if($($newToggle).hasClass("hidden")) {
				// show
				$($newToggle).removeClass("hidden");
				$($newToggle).css("z-index", "100");
				$lastToggle = $newToggle;
				console.log("- show! update last toggle");
			} else {
				// hide
				$($newToggle).addClass("hidden");
				$lastToggle = false;
				console.log("- hide, lastToggle=false");
			}

		} else {
			console.log("different toggle");
			// hide last toggle
			if($lastToggle) {
				console.log("- last toggle was true, hiding and falsing it");
				$($lastToggle).addClass("hidden");	// hide
				$lastToggle = false;
			}

			// hotfix check: if hover is not active (on mobile) check if 
			// turnedOn = true and the infoBox is hidden, then set turnedOn = false
			// cause box cannot be hidden if turnedOn = true
			if($turnedOn && $($newToggle).hasClass("hidden")) {
				$turnedOn = false;
			}

			//window.alert("not same");
			if(!$turnedOn) {
				$($newToggle).removeClass("hidden");	// unhide the new one
				$turnedOn = $newToggle;
				console.log("- not turned on, now true and visible, updated lasttoggle");
				$lastToggle = $newToggle;
			}
		}
	});
}

function selectServer(serverID) {
	"use strict";
	console.log("selectServer: Server "+serverID+" was selected");
	var d = new Date();
	d.setTime(d.getTime() + (7*24*60*60*1000));
	var expires = "expires="+ d.toUTCString();
	document.cookie = "serverSelected=" + serverID + "; " + expires + ";path=/";
	
	//refreshContent();

	$("#map").load(webroot+" #mapWrapper", function() {
		console.log("map was reloaded, orig mapImagePositions: ");
		
		var mapImagePositions = [];
		console.log("new Objectives:");
		$('#mapImages > div').each(function () {
			var pos = {	id: $(this).context.id,	top: $(this).css('top'), left: $(this).css('left') };
			mapImagePositions.push(pos);
			console.log($(this).context.id);
		});
		
		handleResize(mapImagePositions);

		for (var i = 0; i < infoBoxSetups.length; i++) {
			var data = infoBoxSetups[i];
			infoBoxSetup(data.symID, data.boxID, true);
		}

		if($turnedOn) {
			$($turnedOn).removeClass("hidden");
			//$($turnedOn).css("z-index", "100");
		}

		console.log("page was refreshed");
	});
}

// dropdown
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function openDropdown() {
	"use strict";
	document.getElementById("serverSelectorDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
	"use strict";
	
  	if (!event.target.matches('.dropbtn')) {
	  
		var dropdowns = document.getElementsByClassName("dropdown-content");
		var i;
		for (i = 0; i < dropdowns.length; i++) {
			  var openDropdown = dropdowns[i];
			  if (openDropdown.classList.contains('show')) {
				openDropdown.classList.remove('show');
			  }
		}
  	}
}
;