<?php

include('source\Helper.php');
echo 'Executing TAW - Kaukasus Offensive Score Test.<br/>' . PHP_EOL;
$helper = new TAW_Source_Helper();
//echo 'Downloading Updates..' . PHP_EOL;

try {
    $helper->mysql_statistics->scoresTest();
    
    echo 'Finished database update.' . PHP_EOL;
}
catch (Exception $e) {
    die($e->getMessage());
}

echo 'End.' . PHP_EOL;