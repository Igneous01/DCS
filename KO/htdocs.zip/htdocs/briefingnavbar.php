			<button onclick="location.href='briefing.php';" >Introduction</button>
			<button onclick="location.href='briefing.php#GettingStarted';" >Getting Started</button>
			<button onclick="location.href='briefing.php';" >Short Brief</button>
			<button onclick="location.href='briefing.php#Helicopters';">Transportation</button>
			<button onclick="location.href='briefing.php#CSAR';">Combat Search and Rescue (CSAR)</button>
			<button onclick="location.href='briefing.php#Convoys';">Convoys</button>
			<button onclick="location.href='briefing.php#CodeOfEthics';" >Code of Ethics</button>