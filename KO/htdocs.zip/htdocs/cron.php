<?php

include('source\Helper.php');
echo 'Executing TAW - Kaukasus Offensive Cron Job.<br/>' . PHP_EOL;
$helper = new TAW_Source_Helper();
//echo 'Downloading Updates..' . PHP_EOL;

try {
    $baseDir = str_replace('shell', '', getcwd());
	echo 'baseDir :' .$baseDir."<br/>".PHP_EOL;
    // Download latest lua files from server.
    //$helper->_ftp->download($baseDir);
    echo 'Done, executing MySQL update.<br/>' . PHP_EOL;
    $lua = $helper->_lua;
    $luaData = $lua->getData($baseDir);
	
	// obsolete code sind moved to single-file scores
	/*if (count($luaData[2]) != 0) {
		echo 'backing up score file!'.PHP_EOL;
		
		//$baseDir = 'C:/Users/root/Saved Games/DCS/Missions/The Kaukasus Offensive';
		$baseDir = 'C:/DCSWorldMissions/DCS_1.5/Missions/The Kaukasus Offensive';
		//$baseDir = 'C:\Users\taw_deadbeef\Saved Games\DCS.openbeta\Missions\The Kaukasus Offensive';
		$scoreFile = $baseDir . '/ko_Scores.lua';
		$backupFile = $baseDir . '/scoreBackup/ko_Scores_'.date('Ymd_His').'.lua';
		copy($scoreFile, $backupFile);	// backup the file

		// delete imported scores:
		echo 'cleaning up scores container.' . PHP_EOL;
		$f = @fopen($scoreFile, "r+");
		if ($f !== false) {
			echo "deleting file";
			ftruncate($f, 0);
			fwrite($f, "local t = {	
} 
return t");
			fclose($f);
		}
	} else {
		echo "data is empty, no need to delete file".PHP_EOL;
	}*/
	
	$helper->mysql_process->processMap($luaData);
    $helper->mysql_process->processPlayerDB($luaData);
    $helper->mysql_process->processScores($luaData);
	$helper->mysql_process->closeDb();
	
    echo 'Finished database update.' . PHP_EOL;
}
catch (Exception $e) {
    die($e->getMessage());
}

echo 'End.' . PHP_EOL;