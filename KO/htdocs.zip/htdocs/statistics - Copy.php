<?php
include('source/Helper.php');
$helper = new TAW_Source_Helper();
$data = $helper->getAllData(4);
$skip = array('player_id_actual', 'id', 'player_id', 'shot', 'hit', 'collided');
?>
<html>
	<head>
		<link rel="shortcut icon" type="image/ico" href="assets/images/tkosignet.ico" />
		<title>The Kaukasus Offensive - STATISICS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/tablesorter/css/theme.dark.css" rel="stylesheet" type="text/css">
	<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.js"></script> 	
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.widgets.js"></script>

	<script>
		function is_touch_device() {
		  return 'ontouchstart' in window        // works on most browsers 
			  || navigator.maxTouchPoints;       // works on IE10/11 and Surface
		};

		// tablesorter
		$("table").tablesorter({   
			theme: 'dark',
			widgets: ['saveSort', "zebra"]
		});
		
		var mapImageSizes = new Array();
		
		$(document).ready(function() { 
			$("#PlayerListTable").tablesorter({   
				theme: 'dark',
				widgets: ['saveSort', "zebra"]
			}); 
			$("#StatisticTable").tablesorter({   
				theme: 'dark',
				widgets: ['saveSort', "zebra"]
			});
			
			handleResize();
		}); 
		
		
		//setInterval("refreshContent();", 60000);
		
		//var webroot = "http://164.132.233.62/ko";
		var webroot = "";
		function refreshContent() {
			$("#PlayerListWrapper").load(webroot+"/statistics.php #PlayerListTable", function() { 
				$("#PlayerListTable").tablesorter({   
					theme: 'dark',
					widgets: ['saveSort', "zebra"]
				}); 
				$("#PlayerListTable").trigger("update"); 
				//$("#PlayerListTable").trigger("appendCache");
			});
			$("#StatisticWrapper").load(webroot+"/statistics.php #StatisticTable", function() { 
				$("#StatisticTable").tablesorter({   
					theme: 'dark',
					widgets: ['saveSort', "zebra"]
				}); 
				$("#StatisticTable").trigger("update"); 
				//$("#StatisticTable").trigger("appendCache");
			});
		}
	</script>
	
	<body>
		<?php include_once('analyticstracking.php'); ?>
		<header>
			<?php include("navbar.php"); ?>
		</header>
			
		
		
		<?php
		// print_r($data['total_scores']); 
		$scoreFields = array(
			"playerName",
			"side",
			"kill",
			"A2A",
			"A2G",
			"G2A",
			"washit",
			"teamkill",
			"ejected",
			"crashed",
			"died",
			"takeoff",
			"landing",
			"emergencylanding",
			"shot",
			"hit",
			"pilot_rescued",
			"pilot_captured",				
			"neutral_base_occupied",
			"cargo_unpacked_in_zone",
			"crate_deployed",
			"convoy_deployed",
			"sortie",
			"airtime",
			//"onlinetime",
		);
		?>

		<section class="textBlock" id="Statistics">
		<h2>STATISTICS</h2>
			<div id="StatisticWrapper" style="background: url('assets/images/headerimage.jpg') top no-repeat;">
				<table  id="StatisticTable" class="tablesorter tablesorter-dark">
					<thead  id="StatisticContent">
						<tr>
<?php	 				
						$statWidthTable = array ( 0  => "400px", 1  => "25px", 2  => "25px", 3 => "25px", 4 => "25px", 5 => "25px", 6 => "25px", 7 => "25px", 8 => "25px", 9 => "25px", 10 => "25px"  );
						foreach($scoreFields as $i => $scoreName): 
						
						if 	($scoreName == "playerName")					$scoreName = "Callsign";
						elseif 	($scoreName == "ejected") 					$scoreName = "Ejected";
						elseif 	($scoreName == "died") 						$scoreName = "Died";
						elseif 	($scoreName == "crashed") 					$scoreName = "Crashed";
						elseif 	($scoreName == "shot") 						$scoreName = "Shots fired";
						elseif 	($scoreName == "hit")						$scoreName = "Hits";
						elseif 	($scoreName == "kill") 						$scoreName = "Victories";
						elseif 	($scoreName == "teamkill") 					$scoreName = "Teamkill";
						elseif 	($scoreName == "takeoff") 					$scoreName = "Takeoff";
						elseif 	($scoreName == "landing") 					$scoreName = "Landed";
						elseif 	($scoreName == "emergencylanding") 			$scoreName = "Emergency Landed";
						elseif	($scoreName == "cargo_unpacked_in_zone") 	$scoreName = "BASEs supplied";
						elseif	($scoreName == "neutral_base_occupied") 	$scoreName = "BASEs occupied";
						elseif 	($scoreName == "crate_deployed") 			$scoreName = "SAMs deployed";
						elseif 	($scoreName == "troops_dropped") 			$scoreName = "Soldiers inserted";
						elseif 	($scoreName == "sam_deployed") 				$scoreName = "SAMs deployed";
						elseif 	($scoreName == "pilot_rescued") 			$scoreName = "Pilots rescued";
						elseif 	($scoreName == "pilot_captured") 			$scoreName = "Pilots captured";
						elseif  ($scoreName == "washit") 					$scoreName = "Hits taken";
						elseif  ($scoreName == "convoy_deployed") 					$scoreName = "Convoys Deployed";
							
						$width = "25px";
						if (count($statWidthTable) > $i)
							$width = $statWidthTable[$i];
						else
							$width = "25px"; ?>
							<th <?php echo "width=".$width; if($i!=0) echo " align=center"; ?>><?php echo $scoreName; ?></th>
<?php					endforeach; ?>
						</tr>
					</thead>
				<tbody id="StatisticContent">
<?php 				foreach($data['total_scores'] as $player): ?>
					<tr id="StatisticRows">
<?php 					//print_r($player);
						foreach($scoreFields as $j => $scoreName): ?>
						<td <?php if($j!=0) echo " align=center"; ?>><?php 
							if($j == 0) echo '<a href="pilot.php?pid='.$player['pid'].'"><font color='.$coaColors[$player["side"]].'>';
							if($scoreName == "airtime" and isset($player[$scoreName])) 
								echo $player[$scoreName]['total'];
							elseif(isset($player['victories'][$scoreName]))
								echo $player['victories'][$scoreName];
							elseif(isset($player['achievments'][$scoreName]))
								echo $player['achievments'][$scoreName];
							elseif(isset($player[$scoreName]))
								echo $player[$scoreName];
							else
								echo "0"; 
						if($j == 0) echo '</font></a>';?> </td>
<?php 					endforeach; ?>
					</tr>
<?php				endforeach; ?>
				</tbody>
				</table>
			</div>
		</section>
		<?php //print_r($data); ?>
    </body>
</html>
