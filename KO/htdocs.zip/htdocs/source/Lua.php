<?php

class TAW_Source_Lua {
    /**
     * @return array
     * Processes savegame and player data and returns it.
     */
    public function getData($baseDir = null)
    {
		echo "TAW_Source_Lua->getData()</br>".PHP_EOL;
		
		//$baseDir = 'C:/Users/root/Saved Games/DCS/Missions/The Kaukasus Offensive'; // server 3
		$baseDir = 'C:\Users\Root\Saved Games\DCS\Missions\The Kaukasus Offensive';
		$scoreBaseDir = $baseDir . "/scores/";
		$scoreBackupDir = $baseDir . "/scoresBackup/";
        $data = array();
       
		$filesToLoad = array(
			"PlayerData" => $baseDir . '/ko_PlayerData.lua',
			"SaveGame" => $baseDir . '/ko_Savegame.lua',
			"Scores" => array(),
			"OnlinePlayers" => $baseDir . '/ko_PlayersOnline.lua'
		);
		
		foreach($filesToLoad as $cat => $dir) {
			echo "<br>Processing '".$cat."'<br>".PHP_EOL;
			if($cat == "Scores") {
				$directory = $baseDir . '/scores';
				$scanned_directory = array_diff(scandir($directory), array('..', '.'));
				$data[$cat]["baseDir"] = $scoreBaseDir;
				$data[$cat]["backupDir"] = $scoreBackupDir;
				$data[$cat]["scoreFiles"] = array();
				foreach($scanned_directory as $file) {
					echo $file."<br/>".PHP_EOL;
					$data[$cat]["scoreFiles"][] = $file;
				}
			} else {
				$fp = file_get_contents($dir);
				$parse = new TAW_Source_Parser($fp);
				$data[$cat] = current($parse->toArray());
			}
        }
        unset($fp);
        // Keys are all over the place for Player Data, sort them numerically to reset the key index positions.
        return $data;
    }

    public function getLastModified()
    {
        //$fp = file_get_contents("/assets/ko_Savegame.lua");
        if(file_exists('/ko_Savegame.lua')) {
            $modified = filemtime('/ko_Savegame.lua');
        }
        else {
            $ftp = new TAW_Source_Ftp();
            $ftp->download();
        }
    }
}