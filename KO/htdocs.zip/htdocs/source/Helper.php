<?php
include('Config.php');
include('Lua.php');
include('Ftp.php');
include('Parser.php');
include('mysql/Mysqli.php');
include('mysql/Process.php');
include('mysql/Statistics.php');


$coaColors = array(
	"neutral" => "#FFFFFF",
	"red" => "#e20000",
	"blue" => "#1564e1",
);

/**
 * @property array _luaData
 */
class TAW_Source_Helper {

    /**
     * TAW_Source_Helper constructor.
     */
    public function __construct()
    {
        $this->_config = new TAW_Source_Config();
        $this->_lua = new TAW_Source_Lua();
        $this->mysql_process = new TAW_Source_Mysql_Process();
		$this->mysql_statistics = new TAW_Source_Mysql_Statistics();
        $this->_mysqli = new TAW_Source_Mysql_Mysqli();
        $this->_ftp = new TAW_Source_Ftp();
        // Attempt install on instantiation.
        // $this->_mysql_process->install();
    }
	
	public function setServerStatus($serverID, $status)
	{
		$this->mysql_process->setServerStatus($serverID, $status);
	}
	
	public function getServerID($serverName)
	{
		return 1; //$this->mysql_process->getServerID($serverName);
	}
 
    /**
     * @return array
     * Processes and returns lua data.
     */
    public function getLuaData()
    {
        $data = $this->_lua->getData();
        $this->_luaData = $data;
        return $data;
    }

    /**
     * @return array
     * Gets all relevant data for frontend.
	 *
	 * should not be used! (irrelevant for most uses)
	 *
     */
    public function getAllData($serverID)
    {
        $online = $this->getOnlinePlayers($serverID);
		$balanced = $this->getBalancedPlayers($serverID);
        $total = $this->getTotalScores($serverID);
        $map = $this->getMap($serverID);
		$missionStatus = $this->getMissionStatus($serverID);
        $this->mysql_statistics->closeDb();
        return array('online' => $online, 'total_scores' => $total, 'map' => $map, 'balanced' => $balanced, 'missionStatus' => $missionStatus);
    }
	
	
	/**
     * @return array
     * Gets all relevant data for index.php
     */
    public function getMainData($serverID)
    {
        $online = $this->getOnlinePlayers($serverID);
		$balanced = $this->getBalancedPlayers($serverID);
        $map = $this->getMap($serverID);
		$missionStatus = $this->getMissionStatus($serverID);
        $this->mysql_statistics->closeDb();
        return array('online' => $online, 'map' => $map, 'balanced' => $balanced, 'missionStatus' => $missionStatus);
    }
	

    /**
     * @return mixed
     * Helper call for online players list.
     */
    public function getOnlinePlayers($serverID)
    {
        return $this->mysql_statistics->getOnlinePlayerData($serverID);
    }
	
	/**
     * @return mixed
     * Helper call for mission status.
     */
    public function getMissionStatus($serverID)
    {
        return $this->mysql_statistics->getMissionStatus($serverID);
    }
	
	/**
     * @return mixed
     * Helper call for online players list.
     */
    public function getBalancedPlayers($serverID)
    {
        return $this->mysql_statistics->getBalancedPlayerData($serverID);
    }
	
	/**
     * @return mixed
     * Helper call for online players list.
     */
    public function getScoreForUnitCategory($category, $serverID)
    {
        return $this->mysql_statistics->getScoreForUnitCategory($category);
    }

    /**
     * @return array
     * Helper call to get all player score data.
     */
    public function getTotalScores($serverID)
    {
        return $this->mysql_statistics->getTotalScoreData($serverID);
    }

    /**
     * @return mixed
     */
    public function getMap($serverID)
    {
        return $this->mysql_statistics->getMapData($serverID);
    }
	
	public function getScoreForPilot($pid)
	{
		return $this->mysql_statistics->getScoreForPilot($pid);
	}
	
	public function getWeaponsUsed() {
		return $this->mysql_statistics->getWeaponsUsed();
	}
	
	public function processScore($score, $serverID) {
		return $this->mysql_process->processScore($score, $serverID);
	}
	
	public function processSavegame($savegame, $serverID) {
		return $this->mysql_process->processMap($savegame, $serverID);
	}
	
	public function processPlayerList($playerList, $serverID) {
		return $this->mysql_process->processPlayerList($playerList, $serverID);
	}	
	
	public function processRadio($radioData, $serverID) {
		return $this->mysql_process->processRadio($radioData, $serverID);
	}
	
	public function getHrsFromSeconds($seconds)
	{
		// calculate airtime in readable format
		$hours = floor($seconds / 3600);
		$mins = floor($seconds / 60 % 60);
		return ($hours."h ".$mins."min");
	}

}