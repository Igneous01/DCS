Array
(
    [online] => Array
        (
        )

    [total_scores] => Array
        (
            [0] => Array
                (
                    [player_id_actual] => 394c17120108a79fa28853d183b2db1b
                    [player_name] => TAWmatko
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [1] => Array
                (
                    [player_id_actual] => 32e86c2165433aff64959768bee9b754
                    [player_name] => TAWHunterFalkner
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [2] => Array
                (
                    [player_id_actual] => f3d52bdab76f210bfbcfd23e42c21547
                    [player_name] => Hell
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [3] => Array
                (
                    [player_id_actual] => fd92a4c8b10538709c4aa3afb5f8096c
                    [player_name] => hawk
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [4] => Array
                (
                    [player_id_actual] => a4749f4bea30ec98b98d764667b767b8
                    [player_name] => Dean
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [5] => Array
                (
                    [player_id_actual] => cd58b2b8cda5d32bd114c4b311d36ed1
                    [player_name] => TAWSeraphimGray
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [6] => Array
                (
                    [player_id_actual] => 4dab703e1a499e6ddd8cd26c5c577c4f
                    [player_name] => TAWredcoreSix
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [7] => Array
                (
                    [player_id_actual] => 28dd48ca7df7ec9bbf79f50849ffbf39
                    [player_name] => TAWMTM2ndAGG
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [8] => Array
                (
                    [player_id_actual] => eb26e5088d7cf858067b615fef567ef7
                    [player_name] => TAWPhantum
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [9] => Array
                (
                    [player_id_actual] => ad0f628a02408c9f5b716cf8d36e4e11
                    [player_name] => VoRteX
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [10] => Array
                (
                    [player_id_actual] => b6340ffdb1196053b2f62739b7f97758
                    [player_name] => TAWSTRYK3R
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [11] => Array
                (
                    [player_id_actual] => fb94884435fb9c162c544aa286b1c7dc
                    [player_name] => TAWInterceptor
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [12] => Array
                (
                    [player_id_actual] => 21db51378372b7c510ab8cd0c1b5b8d5
                    [player_name] => TAW0xDEADBEEF2ndAGG
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [13] => Array
                (
                    [player_id_actual] => 9d5bd899c2108f4426aae2f9013e8798
                    [player_name] => TAWCarrollhead
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [14] => Array
                (
                    [player_id_actual] => 1af05b6ae7f34f5838814220ab136e3c
                    [player_name] => Leumi
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [15] => Array
                (
                    [player_id_actual] => 23b53e135c3da772642af5b8a05610fe
                    [player_name] => TAWJag
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [16] => Array
                (
                    [player_id_actual] => 690fd1a8c006d77562cdd801cdc0930d
                    [player_name] => TAWDutchBaron2ndAGG
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [17] => Array
                (
                    [player_id_actual] => 24d3d45e431ff6a302273f2d3e72bfc2
                    [player_name] => TAWBodyOrgan
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [18] => Array
                (
                    [player_id_actual] => 2fbea6ede735f97ae9ba0a922c8a1f33
                    [player_name] => AXEM460
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [19] => Array
                (
                    [player_id_actual] => e45c2ea44a9cef5fef626ad9c9429c8c
                    [player_name] => TAWDimsum
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [20] => Array
                (
                    [player_id_actual] => 9dc324131919606dff4e34f421a5671a
                    [player_name] => Martijn
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [21] => Array
                (
                    [player_id_actual] => 5ab513c0fac767cf1edbf730aff57888
                    [player_name] => TAWSkyCap
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

            [22] => Array
                (
                    [player_id_actual] => f7955f8e5f2a3ff48ceaf7c1aa117463
                    [player_name] => TAWDugo
                    [id] => 
                    [player_id] => 
                    [kills] => 
                    [shot] => 
                    [hit] => 
                    [takeoff] => 
                    [ejected] => 
                    [landing] => 
                    [crashed] => 
                    [died] => 
                    [troops_dropped] => 
                    [troops_loaded] => 
                    [collided] => 
                    [cargo_unpacked] => 
                )

        )

    [map] => Array
        (
            [0] => Array
                (
                    [objective_id_actual] => 1
                    [status] => closed
                    [coalition] => neutral
                    [underAttack] => 0
                    [posX] => -164469.71875
                    [posY] => 462238
                    [name] => Sochi-Adler
                    [category] => Aerodrome
                    [objective_id] => 1
                    [priority] => strategic
                    [updated_at] => 2016-07-15 11:15:01
                )

            [1] => Array
                (
                    [objective_id_actual] => 2
                    [status] => open
                    [coalition] => blue
                    [underAttack] => 0
                    [posX] => -196971.140625
                    [posY] => 516291
                    [name] => Gudauta
                    [category] => Aerodrome
                    [objective_id] => 2
                    [priority] => strategic
                    [updated_at] => 2016-07-15 11:15:01
                )

            [2] => Array
                (
                    [objective_id_actual] => 3
                    [status] => open
                    [coalition] => red
                    [underAttack] => 0
                    [posX] => -124898.2890625
                    [posY] => 760441
                    [name] => Nalchik
                    [category] => Aerodrome
                    [objective_id] => 3
                    [priority] => strategic
                    [updated_at] => 2016-07-15 11:15:01
                )

            [3] => Array
                (
                    [objective_id_actual] => 4
                    [status] => open
                    [coalition] => red
                    [underAttack] => 0
                    [posX] => -51228.28515625
                    [posY] => 705723
                    [name] => Mineralnye Vody
                    [category] => Aerodrome
                    [objective_id] => 4
                    [priority] => strategic
                    [updated_at] => 2016-07-15 11:15:01
                )

            [4] => Array
                (
                    [objective_id_actual] => 5
                    [status] => open
                    [coalition] => blue
                    [underAttack] => 0
                    [posX] => -317954.5625
                    [posY] => 635638
                    [name] => Kobuleti
                    [category] => Aerodrome
                    [objective_id] => 5
                    [priority] => strategic
                    [updated_at] => 2016-07-15 11:15:01
                )

            [5] => Array
                (
                    [objective_id_actual] => 6
                    [status] => open
                    [coalition] => blue
                    [underAttack] => 0
                    [posX] => -281719.71875
                    [posY] => 647374
                    [name] => Senaki-Kolkhi
                    [category] => Aerodrome
                    [objective_id] => 6
                    [priority] => strategic
                    [updated_at] => 2016-07-15 11:15:01
                )

            [6] => Array
                (
                    [objective_id_actual] => 7
                    [status] => open
                    [coalition] => red
                    [underAttack] => 0
                    [posX] => -164592.109375
                    [posY] => 672675
                    [name] => FARP Elbrus
                    [category] => FARP
                    [objective_id] => 7
                    [priority] => strategic
                    [updated_at] => 2016-07-15 11:15:01
                )

            [7] => Array
                (
                    [objective_id_actual] => 8
                    [status] => open
                    [coalition] => blue
                    [underAttack] => 0
                    [posX] => -216260.28125
                    [posY] => 606835
                    [name] => FARP Tkvarcheli
                    [category] => FARP
                    [objective_id] => 8
                    [priority] => strategic
                    [updated_at] => 2016-07-15 11:15:01
                )

            [8] => Array
                (
                    [objective_id_actual] => 9
                    [status] => open
                    [coalition] => red
                    [underAttack] => 0
                    [posX] => -201043.140625
                    [posY] => 650557
                    [name] => FARP Inguri Valley
                    [category] => FARP
                    [objective_id] => 9
                    [priority] => strategic
                    [updated_at] => 2016-07-15 11:15:01
                )

            [9] => Array
                (
                    [objective_id_actual] => 10
                    [status] => closed
                    [coalition] => neutral
                    [underAttack] => 0
                    [posX] => -224298.578125
                    [posY] => 639723
                    [name] => Russian Factory
                    [category] => Main Targets
                    [objective_id] => 10
                    [priority] => primary
                    [updated_at] => 2016-07-15 11:15:01
                )

            [10] => Array
                (
                    [objective_id_actual] => 11
                    [status] => closed
                    [coalition] => blue
                    [underAttack] => 0
                    [posX] => -224298.578125
                    [posY] => 639723
                    [name] => Inguri-Dam
                    [category] => Main Targets
                    [objective_id] => 11
                    [priority] => primary
                    [updated_at] => 2016-07-15 11:15:01
                )

            [11] => Array
                (
                    [objective_id_actual] => 12
                    [status] => closed
                    [coalition] => neutral
                    [underAttack] => 0
                    [posX] => -220942.859375
                    [posY] => 641068
                    [name] => Inguri-Dam Fortification
                    [category] => Main Targets
                    [objective_id] => 12
                    [priority] => primary
                    [updated_at] => 2016-07-15 11:15:01
                )

            [12] => Array
                (
                    [objective_id_actual] => 13
                    [status] => closed
                    [coalition] => red
                    [underAttack] => 0
                    [posX] => -168523.71875
                    [posY] => 600163
                    [name] => West Bunker
                    [category] => Bunker
                    [objective_id] => 13
                    [priority] => secondary
                    [updated_at] => 2016-07-15 11:15:01
                )

            [13] => Array
                (
                    [objective_id_actual] => 14
                    [status] => closed
                    [coalition] => blue
                    [underAttack] => 0
                    [posX] => -212364.28125
                    [posY] => 675956
                    [name] => East Bunker
                    [category] => Bunker
                    [objective_id] => 14
                    [priority] => secondary
                    [updated_at] => 2016-07-15 11:15:01
                )

            [14] => Array
                (
                    [objective_id_actual] => 27
                    [status] => closed
                    [coalition] => red
                    [underAttack] => 0
                    [posX] => -154690
                    [posY] => 666272
                    [name] => Antenna Elbrus
                    [category] => Communication
                    [objective_id] => 27
                    [priority] => communication
                    [updated_at] => 2016-07-15 11:15:01
                )

            [15] => Array
                (
                    [objective_id_actual] => 28
                    [status] => closed
                    [coalition] => neutral
                    [underAttack] => 0
                    [posX] => -185286.859375
                    [posY] => 639470
                    [name] => Antenna Bulls
                    [category] => Communication
                    [objective_id] => 28
                    [priority] => communication
                    [updated_at] => 2016-07-15 11:15:01
                )

            [16] => Array
                (
                    [objective_id_actual] => 29
                    [status] => closed
                    [coalition] => red
                    [underAttack] => 0
                    [posX] => -173134.578125
                    [posY] => 639318
                    [name] => Antenna 2
                    [category] => Communication
                    [objective_id] => 29
                    [priority] => communication
                    [updated_at] => 2016-07-15 11:15:01
                )

            [17] => Array
                (
                    [objective_id_actual] => 30
                    [status] => closed
                    [coalition] => neutral
                    [underAttack] => 0
                    [posX] => -200561.421875
                    [posY] => 623520
                    [name] => Antenna Tkvarcheli
                    [category] => Communication
                    [objective_id] => 30
                    [priority] => communication
                    [updated_at] => 2016-07-15 11:15:01
                )

            [18] => Array
                (
                    [objective_id_actual] => 31
                    [status] => closed
                    [coalition] => neutral
                    [underAttack] => 0
                    [posX] => -174103.140625
                    [posY] => 603470
                    [name] => Antenna West Bunker
                    [category] => Communication
                    [objective_id] => 31
                    [priority] => communication
                    [updated_at] => 2016-07-15 11:15:01
                )

            [19] => Array
                (
                    [objective_id_actual] => 32
                    [status] => closed
                    [coalition] => neutral
                    [underAttack] => 0
                    [posX] => -209860
                    [posY] => 677183
                    [name] => Antenna East Bunker
                    [category] => Communication
                    [objective_id] => 32
                    [priority] => communication
                    [updated_at] => 2016-07-15 11:15:01
                )

        )

)