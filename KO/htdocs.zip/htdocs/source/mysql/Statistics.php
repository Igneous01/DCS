<?php



/**
 * @property array _scoreTypes
 */
class TAW_Source_Mysql_Statistics extends TAW_Source_Helper {

    public function __construct()
    {
		$this->acCatTable = array(
			"FIGHTER" => array("F-15C" => 0, "F-5E-3" => 1, "M-2000C" => 2, "Mig-21Bis" => 3, "Mig-29S" => 4, "Mig-29A" => 5, "Su-27" => 6, "Su-33" => 7),
			"ATTACKER" => array("Ka-50" => 0, "A-10C" => 1, "Su-25T" => 2, "Su-25" => 3, "SA342M" => 0, "A-10A" => 5),
			"TRANSPORT" => array("Mi-8MT" => 0, "UH-1H" => 1),
		);
		
        if(class_exists('TAW_Source_Mysql_Mysqli')) {
            $this->_resource = new TAW_Source_Mysql_Mysqli;
            $this->_db = $this->_resource->connect();
        }
        else {
            include('../Helper.php');
            $this->_resource = new TAW_Source_Mysql_Mysqli;
            $this->_db = $this->_resource->connect();
        }
        $this->_scoreTypes = array('crashed', 'shot', 'hit', 'kill', 'landing', 'takeoff', 'ejected', 'troops_loaded',
                                   'collided', 'cargo_unpacked', 'died', 'troops_dropped');
	}
	
	
	public function getMissionStatus($serverID)
	{
		$query =	"SELECT * FROM `ko_missionstatus` WHERE `serverID` = '".$serverID."';";
		$db = $this->_db->query($query) ;
		if($db) {
			if ($row = $db->fetch_assoc()) {
				return $row;
			}
		}
	}	
	

    /**
     * @return array
     * Gets balanced players from database.
     */
    public function getBalancedPlayerData($serverID)
    {
		$slotLimit = 24;
		$catSize = 3;		// maximum allowed slot per category (+1)
		
		$redPlayersOnline = 0;
		$bluePlayersOnline = 0;
		
		$data = array (
			1 => array (
				"Fighter" => array(),
				"Striker" => array(),
				"Helicopter" => array(),
				"GCI" => array(),
			),
			2 => array (
				"Fighter" => array(),
				"Striker" => array(),
				"Helicopter" => array(),
				"GCI" => array(),
			)
		);
		
		foreach($data as $coalition => $categories) {
			foreach($categories as $catName => $slots) {
				//----------
				// GCI
				if($catName == "GCI") {
					$query =	"SELECT `name`, `ucid`, `clientID` 
								FROM `ko_onlineplayers`
								WHERE `serverID` = ".$serverID." AND `slot` = -1 AND `side` = '".$coalition."';";
					$db = $this->_db->query($query) ;
					if($db) {
						for ($num = 0; $num <= $catSize; $num++) {
							if ($row = $db->fetch_assoc()) {
								$data[$coalition][$catName][$num] = $row; 
								$data[$coalition][$catName][$num]['slotID'] = -1;
								$data[$coalition][$catName][$num]['coalition'] = $coalition;
								$data[$coalition][$catName][$num]['type'] = 'GCI';
								
								if(!isset($data[$coalition][$catName][$num]['name'])) { $data[$coalition][$catName][$num]['name'] = "- error in name"; }
								if(!isset($data[$coalition][$catName][$num]['coalition'])) { $data[$coalition][$catName][$num]['coalition'] = "error in coalition"; }
								if(!isset($data[$coalition][$catName][$num]['slotID'])) { $data[$coalition][$catName][$num]['slotID'] = 0; }
								
								$query2 = "SELECT `id` AS `pid` FROM `ko_players` WHERE `ucid`='".$row['ucid']."';";		
								if($db2 = $this->_db->query($query2)) {
									while ($row2 = $db2->fetch_assoc()) {
										$data[$coalition][$catName][$num]['pid'] = $row2['pid'];
									}
									$db2->free();
								}
								
								// add radio info
								$query3 = "SELECT * FROM `ko_radios` WHERE `serverID` = ".$serverID." AND `pid` = ".$data[$coalition][$catName][$num]['pid'].";";
								if($db3 = $this->_db->query($query3)) {
									if(mysqli_num_rows($db3) > 0) {
										$data[$coalition][$catName][$num]['radios'] = array();
										while ($row3 = $db3->fetch_assoc()) {
											$data[$coalition][$catName][$num]['radios'][] = array(	"frequency" => $row3['frequency'],
																									"modulation" => $row3['modulation'],
																									"radioName" => $row3['radioname'],
																									"selected" => $row3['selected']);
										}
									}
									$db3->free();
								}
							} else {
								$data[$coalition][$catName][$num] = array(
									"clientID" => 0,
									"name" => "- free slot -",
									"slotID" => 0,
									"type" => "none",
									"coalition" => "0",
								);
							}
						}
					}
				} else {
					//----------
					// NON GCI
					$query =	"SELECT `clientID`
							FROM `ko_slotlist`
							WHERE `serverID` = ".$serverID." AND `category` = '".$catName."' AND `coalition` = '".$coalition."';";
					$db = $this->_db->query($query) ;
					
					//echo $coalition.PHP_EOL;
					for ($num = 0; $num <= $catSize; $num++) {
						if($db) {
							if ($row = $db->fetch_assoc()) {
								$data[$coalition][$catName][$num] = $row; 
	
								// get the name, side and slot from ko_onlineplayers table
								$query =	"SELECT `name`, `slot`, `ucid` 
											FROM `ko_onlineplayers`
											WHERE `serverID` = ".$serverID." AND `clientID` = '".$row['clientID']."';";
								$db2 = $this->_db->query($query) ;
								while ($row2 = $db2->fetch_assoc()) {
									if($row2['name'] == "")
										$row2['name'] = "error in name";
									$data[$coalition][$catName][$num]['name'] = $row2['name'];
									$data[$coalition][$catName][$num]['slotID'] = $row2['slot'];
									$data[$coalition][$catName][$num]['coalition'] = $coalition;
									
									if(!isset($data[$coalition][$catName][$num]['name'])) { $data[$coalition][$catName][$num]['name'] = "- error in name"; }
									if(!isset($data[$coalition][$catName][$num]['coalition'])) { $data[$coalition][$catName][$num]['coalition'] = "error in coalition"; }
									if(!isset($data[$coalition][$catName][$num]['slotID'])) { $data[$coalition][$catName][$num]['slotID'] = 0; }
									
									$query4 = "SELECT `id` AS `pid` FROM `ko_players` WHERE `ucid`='".$row2['ucid']."';";
									if($db4 = $this->_db->query($query4)) {
										while ($row4 = $db4->fetch_assoc()) {
											$data[$coalition][$catName][$num]['pid'] = $row4['pid'];
										}
										$db4->free();
									}
								}
								if($db2)
									$db2->free();
								
								// get the unit Type from ko_slotids
								if($data[$coalition][$catName][$num]['slotID']) {
									$query = 	"SELECT `slotType` FROM `ko_slotids` 
												WHERE 	`serverID` = ".$serverID." 
													AND `slotID`='".$data[$coalition][$catName][$num]['slotID']."';";	
									$db3 = $this->_db->query($query) ;
									while ($row3 = $db3->fetch_assoc()) {
										$data[$coalition][$catName][$num]['type'] = $row3['slotType'];
									}
									if($db3)
										$db3->free();
									
								} else {
									$data[$coalition][$catName][$num]['type'] = "unknown";
								}
								
								// add radio info
								$query3 = "SELECT * FROM `ko_radios` WHERE `serverID` = ".$serverID." AND `pid` = ".$data[$coalition][$catName][$num]['pid'].";";
								if($db3 = $this->_db->query($query3)) {
									if(mysqli_num_rows($db3) > 0) {
										$data[$coalition][$catName][$num]['radios'] = array();
										while ($row3 = $db3->fetch_assoc()) {
											$data[$coalition][$catName][$num]['radios'][] = array(	"frequency" => $row3['frequency'],
																									"modulation" => $row3['modulation'],
																									"radioName" => $row3['radioname'],
																									"selected" => $row3['selected']);
										}
									}
									$db3->free();
								}
							} else {
								$data[$coalition][$catName][$num] = array(
									"clientID" => 0,
									"name" => "- free slot -",
									"slotID" => 0,
									"type" => "none",
									"coalition" => "0",
								);
							}
						}
					}
				}
				if($db)
					$db->free();
			
			}
		}
		//print_r($data);
		return $data;
	}
    /**
     * @return array
     * Gets online players from database.
     */
    public function getOnlinePlayerData($serverID)
    {	
		$coaName = array(
			0 => "spectators",
			1 => "red",
			2 => "blue",
		);
		$data = array();
		$data['players'] = array();
		$data['redPlayers'] = 0;
		$data['bluePlayers'] = 0;
		$data['spectatorsPlayers'] = 0;
        $query = "SELECT name, ucid, ping, side, slot, id FROM ko_onlineplayers WHERE `serverID` = ".$serverID.";";
        if($db = $this->_db->query($query)) {
            while ($row = $db->fetch_assoc()) {
				//print_r($row);
                $data['players'][] = $row;
				$data[$coaName[$row['side']].'Players']++;
            }
            $db->free();
			
			$data['numPlayers'] = count($data['players']);
        }
		
		foreach($data['players'] as $key => $player) {
			// add the pid
			$query = "SELECT id AS pid FROM ko_players WHERE ucid='".$player['ucid']."';";		
			if($db = $this->_db->query($query)) {
				while ($row = $db->fetch_assoc()) {
					$player['pid'] = $row['pid'];
				}
				$db->free();
			}
			
			// count the scores
			$query = "SELECT achievment FROM ko_scores WHERE `serverID` = ".$serverID." AND ucid='".$player['ucid']."' AND `created_at` > DATE_SUB(now(), INTERVAL 1 DAY);";		
			if($db = $this->_db->query($query)) {
				while ($row = $db->fetch_assoc()) {
					if(isset($player[$row['achievment']])) {
						$player[$row['achievment']]++;
					}
					else {
						$player[$row['achievment']] = 1;
					}
				}
				$db->free();
				
				
			}
			
			//echo "looking for slot: ".$player['slot'].PHP_EOL;
			
			// get the unit Type from ko_slotids
			
			if($player['slot'] == -1) {
				$player['type'] = "GCI";
			} else {
				$query = "SELECT slotType FROM ko_slotids WHERE `serverID` = ".$serverID." AND slotID='".$player['slot']."';";		
				if($db = $this->_db->query($query)) {
					$row = $db->fetch_assoc();
					$player['type'] = $row['slotType'];
					$db->free();
				}
			}
			
			// insert category
			$query = "SELECT category FROM ko_slotlist WHERE `serverID` = ".$serverID." AND slotID='".$player['slot']."';";
			if($db = $this->_db->query($query)) {
				$row = $db->fetch_assoc();
				$player['slotCategory'] = $row['category'];
				$db->free();
			}
			
			// save the table as php is not referencing it in foreach
			$data['players'][$key] = $player;
		}
		//print_r($data);
        return $data;
    }
	
	
	public function getTotalScoreData()
    {
        $players = array();
        //$query = "SELECT player_name AS name, id AS pid, ucid AS ucid, ping, onlinetime FROM ko_players;";
		$query = "SELECT id AS pid FROM ko_players WHERE onlinetime > 0 ORDER BY onlinetime DESC LIMIT 50;";
        if($db = $this->_db->query($query)) {
            while ($row = $db->fetch_assoc()) {
				//print_r($row);
                $players[] = $row;
            }
            $db->free();
        }
		
		//print_r($players);
		
		foreach($players as $key => $player) {
			
			$players[$key] = $this->getScoreForPilot($player['pid']);
			
			// compute online time from seconds
			/*$hours = floor($player["onlinetime"] / 3600);
			$mins = floor($player["onlinetime"] / 60 % 60);
			$player["onlinetime"] = $hours."h ".$mins."min";
			$player["airtime"] = 0;
			$player['airtimered'] = 0;
			$player['airtimeblue'] = 0;
			
			// count the scores
			$query = "SELECT achievment, airtime, unitCategory, victimCategory, side FROM ko_scores WHERE ucid='".$player['ucid']."'"; //."' AND `created_at` > DATE_SUB(now(), INTERVAL 7 DAY);";
			if($db = $this->_db->query($query)) {
				while ($row = $db->fetch_assoc()) {
					if(isset($player[$row['achievment']])) 
						$player[$row['achievment']]++;
					else 
						$player[$row['achievment']] = 1;
					
					if ($row['achievment'] == 'kill') {
						if($row['unitCategory'] == "AIRPLANE" or $row['unitCategory'] == "HELICOPTER") {
							if($row['victimCategory'] == "AIRPLANE" or $row['victimCategory'] == "HELICOPTER") {
								if(isset($player["A2A"])) 
									$player["A2A"]++;
								else 
									$player["A2A"] = 1;
							} else {
								if(isset($player["A2G"])) 
									$player["A2G"]++;
								else 
									$player["A2G"] = 1;
							}
						} elseif ($row['unitCategory'] == "GROUND_UNIT" or $row['unitCategory'] == "DEPLOYED") {
							if($row['victimCategory'] == "AIRPLANE" or $row['victimCategory'] == "HELICOPTER") {
								if(isset($player["G2A"])) 
									$player["G2A"]++;
								else 
									$player["G2A"] = 1;
							} else {
								if(isset($player["G2G"])) 
									$player["G2G"]++;
								else 
									$player["G2G"] = 1;
							}
						}
					}

					if($row['achievment'] == 'sortie') {
						$player['airtime'] += $row['airtime'];
						$player['airtime'.$row['side']] += $row['airtime'];			
					}
					
				}
				$db->free();
			}
			
			// side by airtime
			if($player['airtimeblue'] > $player['airtimered'])
				$player['side'] = 'blue';
			else
				$player['side'] = 'red';
			
			// calculate airtime in readable format
			$player["airtime"] = $this->secondsToHours($player["airtime"]);
			$player["airtimered"] = $this->secondsToHours($player["airtimered"]);
			$player["airtimeblue"] = $this->secondsToHours($player["airtimeblue"]);
			
			if(isset($player['airtime']) and $player['airtime'] > 0)
				$players[$key] = $player; // save the table as php is not referencing it in foreach
			else
				unset($players[$key]);	// if no sortie flown he's not interesting for stats */

		}
		//print_r($players);
        return $players;
    }
	
	// TODO
	public function getScoreForUnitCategory($category, $serverID)
    {
        $players = array();
        $query = "SELECT player_name AS name, ucid AS ucid, onlinetime FROM ko_players;";
        if($db = $this->_db->query($query)) {
            while ($row = $db->fetch_assoc()) {
				//print_r($row);
                $players[] = $row;
            }
            $db->free();
        }
		
		foreach($players as $key => $player) {
			// compute online time from seconds
			$hasResult = false;
			$hours = floor($player["onlinetime"] / 3600);
			$mins = floor($player["onlinetime"] / 60 % 60);
			$player["onlinetime"] = $hours."h ".$mins."min";
			$player["airtime"] = 0;
			// count the scores
			$query = "SELECT achievment, airtime, unitCategory, unitType, victimCategory FROM ko_scores WHERE ucid='".$player['ucid']."' AND unitCategory='".$category."';";
			if($db = $this->_db->query($query)) {
				while ($row = $db->fetch_assoc()) {
					$hasResult = true;
					
					if(isset($player[$row['achievment']])) 
						$player[$row['achievment']]++;
					else 
						$player[$row['achievment']] = 1;
					
					if ($row['achievment'] == 'kill') {
						if($row['unitCategory'] == "AIRPLANE" or $row['unitCategory'] == "HELICOPTER") {
							if($row['victimCategory'] == "AIRPLANE" or $row['victimCategory'] == "HELICOPTER") {
								if(isset($player["A2A"])) 
									$player["A2A"]++;
								else 
									$player["A2A"] = 1;
							} else {
								if(isset($player["A2G"])) 
									$player["A2G"]++;
								else 
									$player["A2G"] = 1;
							}
						} elseif ($row['unitCategory'] == "GROUND_UNIT" or $row['unitCategory'] == "DEPLOYED") {
							if($row['victimCategory'] == "AIRPLANE" or $row['victimCategory'] == "HELICOPTER") {
								if(isset($player["G2A"])) 
									$player["G2A"]++;
								else 
									$player["G2A"] = 1;
							} else {
								if(isset($player["G2G"])) 
									$player["G2G"]++;
								else 
									$player["G2G"] = 1;
							}
						}
					}

					if($row['achievment'] == 'sortie') {
						if(isset($player['airtime']))
							$player['airtime'] = $player['airtime'] + $row['airtime'];
						else
							$player['airtime'] = $row['airtime'];
						
						if(!isset($player['airtimePerType'])) {
							$player['airtimePerType'] = array();
						} 
						
						if(isset($player['airtimePerType'][$row['unitType']]))
							$player['airtimePerType'][$row['unitType']] = $player['airtimePerType'][$row['unitType']] + $row['airtime'];
						else
							$player['airtimePerType'][$row['unitType']] = $row['airtime'];
						
						if(isset($player['airtime'.$row['unitType']]))
							$player['airtime'.$row['unitType']] = $player['airtime'.$row['unitType']] + $row['airtime'];
						else
							$player['airtime'.$row['unitType']] = $row['airtime'];
						
						if(isset($player['airtime'.$category]))
							$player['airtime'.$category] = $player['airtime'.$category] + $row['airtime'];
						else
							$player['airtime'.$category] = $row['airtime'];
					}
				}
				
				
				$db->free();
			} 
			
			// calculate airtime in readable format
			$hours = floor($player["airtime"] / 3600);
			$mins = floor($player["airtime"] / 60 % 60);
			$player["airtime"] = $hours."h ".$mins."min";
			
			// save the table as php is not referencing it in foreach
			if($hasResult == false) 
				unset($players[$key]);
			else
				$players[$key] = $player;
		}
		//print_r($players);
		$players = array_values($players);
        return $players;
    }

    public function getMapData($serverID)
    {
		$objectives = array();
		$query = "SELECT * FROM `ko_objectives` WHERE `serverID` = ".$serverID." ;";
		
        if($db = $this->_db->query($query)) {
            while ($row = $db->fetch_assoc()) {
				//echo "adding row";
                $objectives[] = $row;
            }
            $db->free();
        }
        return $objectives;
    }
	
	
	/**
     * @return array
     * Gets individual score data for Pilots page.
     */
	public function getScoreForPilot($pid)
	{
		//-------------------------
		// get the PlayerData
		//echo "pid: $pid<br>".PHP_EOL;
		
		$pilot = array();
		$query = "SELECT ucid AS ucid, player_name AS playerName, onlinetime as onlineTime, numConnects, side FROM ko_players WHERE id='".$pid."';";	
		if($db = $this->_db->query($query)) {
			while ($row = $db->fetch_assoc()) {
				$pilot = $row;
			}
			$db->free();
		}
		
		//print_r($pilot);

		$pilot['pid'] = $pid;
		
		// compute online time from seconds
		$hours = floor($pilot['onlineTime'] / 3600);
		$mins = floor($pilot['onlineTime'] / 60 % 60);
		$pilot['onlineTime'] = $hours.'h '.$mins.'min';

		//initialization
		$pilot['achievments'] = array();
		$pilot['achievments']['sortie'] = 0;	
		$pilot['airtime'] = array();
		$pilot['airtime']['types'] = array();
		$pilot['airtime']['total'] = 0;
		$pilot['airtime']['red'] = 0;
		$pilot['airtime']['blue'] = 0;
		$pilot['airtime']['HELICOPTER'] = 0;
		$pilot['airtime']['AIRPLANE'] = 0;
		
		$pilot['victories'] = array();
		$pilot['victories']['A2A'] = 0;
		$pilot['victories']['A2G'] = 0;
		$pilot['victories']['G2A'] = 0;
		$pilot['victories']['G2G'] = 0;
		
		$pilot['weapons'] = array();
		
		// loop through all scores
		$query = "SELECT achievment, airtime, unitCategory, unitType, victimCategory, side, weaponCategory, weapon FROM ko_scores WHERE ucid='".$pilot['ucid']."';"; // AND `created_at` > DATE_SUB(now(), INTERVAL 1 DAY);";	
			
		if($db = $this->_db->query($query)) {
			while ($row = $db->fetch_assoc()) {
				// count the achievment first of all
				if(isset($pilot['achievments'][$row['achievment']])) 
					$pilot['achievments'][$row['achievment']]++;
				else 
					$pilot['achievments'][$row['achievment']] = 1;
					
				//-------------------------------
				// AIRTIME	
				// find the players favorite coalition (and respective time spent on each coalition)				
				if($row['achievment'] == 'sortie') {
					$pilot['airtime']['total'] = $pilot['airtime']['total'] + $row['airtime'];
					
					$pilot['airtime'][$row['side']] = $pilot['airtime'][$row['side']] + $row['airtime'];
					
					//echo "inserting ".$row['airtime']." seconds into ".$row['unitCategory']."<br>".PHP_EOL;
					
					if(isset($pilot['airtime'][$row['unitCategory']])) 
						$pilot['airtime'][$row['unitCategory']] = $pilot['airtime'][$row['unitCategory']] + $row['airtime'];
					else 
						$pilot['airtime'][$row['unitCategory']] = $row['airtime'];
						
					if(isset($pilot['airtime']['types'][$row['unitType']])) 
						$pilot['airtime']['types'][$row['unitType']] = $pilot['airtime']['types'][$row['unitType']] + $row['airtime'];
					else 
						$pilot['airtime']['types'][$row['unitType']] = $row['airtime'];
				}
				
				//-------------------------------
				// Victories	
				// 
				if ($row['achievment'] == 'kill') {
					if($row['unitCategory'] == 'AIRPLANE' or $row['unitCategory'] == 'HELICOPTER') {
						if($row['victimCategory'] == 'AIRPLANE' or $row['victimCategory'] == 'HELICOPTER') {
							$pilot['victories']['A2A']++;
						} else {
							$pilot['victories']['A2G']++;
						}
					} elseif ($row['unitCategory'] == 'GROUND_UNIT' or $row['unitCategory'] == 'DEPLOYED') {
						if($row['victimCategory'] == 'AIRPLANE' or $row['victimCategory'] == 'HELICOPTER') {
							$pilot['victories']['G2A']++;
						} else {
							$pilot['victories']['G2G']++;
						}
					}
				}

				//-------------------------------
				// Weapon Usage	
				// 
				
				$weaponCategories = array( 0 => "SHELL", 1 => "MISSILE", 2 => "ROCKET",	3 => "BOMB");
				if (($row['unitCategory'] == 'AIRPLANE' or $row['unitCategory'] == 'HELICOPTER') and ($row['achievment'] == 'shot' or $row['achievment'] == 'hit' or $row['achievment'] == 'kill')) {
					$weapon = $row['weapon'];
					$weaponCat = $row['weaponCategory'];
					$achievment = $row['achievment'];
					
					if (!isset($pilot['weapons'][$weaponCat])) {
						$pilot['weapons'][$weaponCat] = array();
					}
					
					if (!isset($pilot['weapons'][$weaponCat][$weapon])){	
						$pilot['weapons'][$weaponCat][$weapon] = array();
					}
					if (!isset($pilot['weapons'][$weaponCat][$weapon][$achievment])){	
						$pilot['weapons'][$weaponCat][$weapon][$achievment] = 0;
					} 
					
					$pilot['weapons'][$weaponCat][$weapon][$achievment] = $pilot['weapons'][$weaponCat][$weapon][$achievment] + 1;
				}
			}
			$db->free();
		}
		
		// side by airtime
		$pilot['side'] = 'neutral';
		if($pilot['airtime']['blue'] > $pilot['airtime']['red'])
			$pilot['side'] = 'blue';
		elseif($pilot['airtime']['blue'] < $pilot['airtime']['red'])
			$pilot['side'] = 'red';
		
		// calculate additional info
		$longestTime = 0;
		$longestType = "none yet";
		$favAircraftCat = "Fixed-Wing";
		if ($pilot['airtime']['HELICOPTER']	> $pilot['airtime']['AIRPLANE'])
			$favAircraftCat = "Rotorhead";
			
		
		// Air-Time per Category
		// get airtime per unit type (Fighter, Attacker, Transport)
		$pilot['airtime']['FIGHTER'] = 0;
		$pilot['airtime']['ATTACKER'] = 0;
		$pilot['airtime']['TRANSPORT'] = 0;
		foreach($pilot['airtime']['types'] as $type => $time) {
			if(array_key_exists($type, $this->acCatTable['FIGHTER']))
				$pilot['airtime']['FIGHTER'] += $time;
			elseif(array_key_exists($type, $this->acCatTable['ATTACKER']))
				$pilot['airtime']['ATTACKER'] += $time;
			elseif(array_key_exists($type, $this->acCatTable['TRANSPORT']))
				$pilot['airtime']['TRANSPORT'] += $time;
				
			if($time > $longestTime) {
				$longestTime = $time;
				$longestType = $type;
			}			
		}		
		
		$longestCatTime = $pilot['airtime']['FIGHTER'];
		$longestCatType = "Intercept Specialist";
		if ($pilot['airtime']['ATTACKER'] > $longestCatTime) {
			$longestCatTime = $pilot['airtime']['ATTACKER'];
			$longestCatType = "Strike-Specialist";
		}
		if ($pilot['airtime']['TRANSPORT'] > $longestCatTime) {
			$longestCatTime = $pilot['airtime']['TRANSPORT'];
			$longestCatType = "Logistics-Specialist";
		}
		
		$favAircraftCat .= " - ".$longestCatType;
		
		
		// make times readable
		$airtimeSecs = $pilot['airtime']['total'];
		foreach($pilot['airtime'] as $key => $airtime) {
			if ($key != "types")
				$pilot['airtime'][$key] = $this->secondsToHours($airtime);
			else {
				foreach($airtime as $type => $typetime) {	
					$pilot['airtime']['types'][$type] = $this->secondsToHours($typetime);
				}
			}
		}
		
		$pilot['airtime']['totalSecs'] = $airtimeSecs;
		
		
		// add additional info to table
		$pilot['airtime']['favoriteType'] = $longestType;
		$pilot['airtime']['favAircraftCat'] = $favAircraftCat;
		
		if(!isset($pilot['achievments']['neutral_base_occupied']))
			$pilot['achievments']['neutral_base_occupied'] = 0;
		if(!isset($pilot['achievments']['cargo_unpacked_in_zone']))
			$pilot['achievments']['cargo_unpacked_in_zone'] = 0;
		if(!isset($pilot['achievments']['crate_deployed']))
			$pilot['achievments']['crate_deployed'] = 0;
		if(!isset($pilot['achievments']['pilot_rescued']))
			$pilot['achievments']['pilot_rescued'] = 0;
		if(!isset($pilot['achievments']['pilot_captured']))
			$pilot['achievments']['pilot_captured'] = 0;
		if(!isset($pilot['achievments']['convoy_deployed']))
			$pilot['achievments']['convoy_deployed'] = 0;
		if(!isset($pilot['achievments']['takeoff']))
			$pilot['achievments']['takeoff'] = 0;
		if(!isset($pilot['achievments']['landing']))
			$pilot['achievments']['landing'] = 0;
		if(!isset($pilot['achievments']['died']))
			$pilot['achievments']['died'] = 0;
		if(!isset($pilot['achievments']['crashed']))
			$pilot['achievments']['crashed'] = 0;
		if(!isset($pilot['achievments']['ejected']))
			$pilot['achievments']['ejected'] = 0;
		if(!isset($pilot['achievments']['kill']))
			$pilot['achievments']['kill'] = 0;

		return $pilot;
	}
	
	public function getWeaponsUsed()
	{
		//echo "getWeaponsUsed()";
		$weapons = array();
		// loop through all scores
		$query = "SELECT weapon, weaponCategory, weaponGuidance, weaponMslCategory FROM ko_scores;";	
		if($db = $this->_db->query($query)) {
			while ($row = $db->fetch_assoc()) {
				if(!isset($weapons[$row['weapon']]))
					$weapons[$row['weapon']] = 1;
				else
					$weapons[$row['weapon']] = $weapons[$row['weapon']] + 1;
			}
			
			$db->free();
		}
		
		$weaponArray = array(
		  'R-27R' => 'AAM',
		  'R-73' => 'AAM',
		  'R-73 (AA-11)' => 'AAM',
		  'R-27T' => 'AAM',
		  'MIM-23B' => 'SAM',
		  'FIM-92C' => 'SAM',
		  'MIM-23B Hawk' => 'SAM',
		  'FIM-92C Stinger' => 'SAM',
		  'R-27T (AA-10B)' => 'AAM',
		  'AIM-7M' => 'AAM',
		  '9M33' => 'SAM',
		  'MIM-72G' => 'SAM',
		  '9M39' => 'SAM',
		  'AIM-9P5' => 'AAM',
		  'AIM-9M' => 'AAM',
		  'Kh-25MPU' => 'AGM',
		  'Kh-29L' => 'AGM',
		  '3M9M' => 'SAM',
		  '9M38M1' => 'SAM',
		  'Mk-82 SnakeEye' => 'bomb',
		  'Mk-82' => 'bomb',
		  'Cannon' => 'shell',
		  'AGM-65D' => 'AGM',
		  '9M31' => 'SAM',
		  '2A7_23_HE' => 'shell',
		  '2A7_23_AP' => 'shell',
		  'GBU-12' => 'bomb',
		  'GBU-38' => 'bomb',
		  'CBU-105' => 'bomb',
		  'AGM-65H' => 'AGM',
		  'HYDRA-70 M151' => 'rocket',
		  'MATRA' => 'AAM',
		  'Vikhr M' => 'AGM',
		  'ROCKEYE' => 'bomb',
		  'S-8KOM' => 'rocket',
		  'Kh-29T' => 'AGM',
		  'CBU-97' => 'bomb',
		  'S-8OFP2' => 'rocket',
		  '7_62x51' => 'shell',
		  'M2_12_7_T' => 'shell',
		  'M61_20_HE' => 'shell',
		  'M61_20_AP' => 'shell',
		  'Kh-25ML' => 'AGM',
		  'S-25L' => 'AGM',
		  '9M333' => 'SAM',
		  'M256_120_AP' => 'shell',
		  'M242_25_HE_M792' => 'shell',
		  'M68_105_AP' => 'shell',
		  '2A46M_125_AP' => 'shell',
		  'Utes_12_7x108_T' => 'shell',
		  'BGM-71 TOW' => 'ATM',
		  '2A46M_125_HE' => 'shell',
		  'AT-11 Sniper' => 'AGM',
		  'HESH_105' => 'shell',
		  'M242_25_AP_M791' => 'shell',
		  '2A42_30_HE' => 'shell',
		  'BetAB-500ShP' => 'bomb',
		  'BetAB-500' => 'bomb',
		  'RBK-500 PTAB-10' => 'bomb',
		  'FAB-500' => 'bomb',
		  'S-5KO' => 'rocket',
		  '7_62x54' => 'shell',
		  'CBU-103' => 'bomb',
		  'GBU-10' => 'bomb',
		  'GBU-31' => 'bomb',
		  'CBU-52B' => 'bomb',
		  'FAB-100' => 'bomb',
		  'S-8TsM' => 'rocket',
		  'KAB-500KR' => 'bomb',
		  'S-24A' => 'AGM',
		  'HYDRA-70 MK5' => 'rocket',
		  'RBK-500U PTAB-1M' => 'bomb',
		  'M256_120_HE' => 'shell',
		  '9M33 Osa (SA-8 Gecko)' => 'SAM',
		  'HOT3' => 'AGM',
		  'Matra S530D' => 'AAM',
		  'R-27R (AA-10A)' => 'AAM',
		  'Matra Magic II' => 'AAM',		  
		  'S-13OF' => 'rocket',
		  'S-25OFM' => 'rocket',
		  'Mk-82AIR' => 'bomb',
		  '9M330' => 'SAM',
		  'R-3R' => 'AAM',
		 );
		
		$weaponNameChange = array(
			'R-73 (AA-11)' => 'R-73',
			'R-27T (AA-10B)' => 'R-27T',
			'R-27R (AA-10A)' => 'R-27R',
		);
		 
		 foreach($weaponArray as $weapon => $category) {
			//echo "updating ".$weapon." with category ".$category."<br>".PHP_EOL;
			$update = $this->_db
				->prepare('UPDATE ko_scores SET weaponCategory = ? WHERE weapon = ?');
			$update->bind_param('ss', $category, $weapon);
			$update->execute();
	
			// Throw error if something goes wrong with statement.
			if ($update->errno !== 0 && !is_null($update->errno)) {
				die('Error occurred: ' . $update->errno . ', ' . $update->error);
			}
	
			$update->close();
		 }
		
		foreach($weaponNameChange as $weapon => $newName) {
			//echo "updating ".$weapon." with category ".$category."<br>".PHP_EOL;
			$update = $this->_db
				->prepare('UPDATE ko_scores SET weapon = ? WHERE weapon = ?');
			$update->bind_param('ss', $newName, $weapon);
			$update->execute();
	
			// Throw error if something goes wrong with statement.
			if ($update->errno !== 0 && !is_null($update->errno)) {
				die('Error occurred: ' . $update->errno . ', ' . $update->error);
			}
	
			$update->close();
		 }
		 
		 
		
		/*$teamkillers = array();
		// loop through all scores
		$query = "SELECT `id` FROM `ko_scores` WHERE `achievment`='kill' AND `side`=`victimSide`;";		
		if($db = $this->_db->query($query)) {
			while ($row = $db->fetch_assoc()) {
				$teamkillers[] = $row['id'];
			}
			$db->free();
		}
		//echo count($teamkillers);
		
		foreach($teamkillers as $id) {
			//echo "upating id: ".$id."<br>";
			$update = $this->_db
				->prepare('UPDATE `ko_scores` SET `achievment` = "teamkill" WHERE `id` = ?');
			$update->bind_param('i', $id);
			$update->execute();
	
			// Throw error if something goes wrong with statement.
			if ($update->errno !== 0 && !is_null($update->errno)) {
				die('Error occurred: ' . $update->errno . ', ' . $update->error);
			}
	
			$update->close();
		 }*/
		
		
		 
		return $weapons;
	}
	
	public function scoresTest()
	{
		$scoreID = 0;
		$lastScoreID = 0;
		//$query = "SELECT `scoreID`, `achievment`, `created_at` FROM `ko_scores` WHERE `serverID` = 4 AND `created_at` > DATE_SUB(now(), INTERVAL 2 DAY) ORDER BY `scoreID` ASC;";
		$query = "SELECT `scoreID`, `achievment`, `created_at` FROM `ko_scores` WHERE `serverID` = 4 ORDER BY `scoreID` ASC;";
		if($db = $this->_db->query($query)) {
			echo "checking ".$db->num_rows." results".PHP_EOL;
			
			while ($row = $db->fetch_assoc()) { 
				if($scoreID == 0) {
					$scoreID = $row['scoreID'];
					echo "starting with $scoreID".PHP_EOL;
				} else {
					$newScoreID = $row['scoreID'];
					$achievment = $row['achievment'];
					$date = $row['created_at'];
					
					if ($scoreID == $newScoreID)
						echo "$date: $scoreID is duplicated!".PHP_EOL;
					
					if ($scoreID+1 < $newScoreID) {
						
						if($scoreID+2 == $newScoreID)
							echo "$date: ".($scoreID+1)." ($achievment) is missing".PHP_EOL;
						else {
							$numMissing = $newScoreID-$scoreID;
							$lastMissing = $newScoreID-1;
							echo "$date: $scoreID-$lastMissing ($numMissing) are missing".PHP_EOL;
						}
					}
					
					$scoreID = $newScoreID;
					
					$lastScoreID = $row['scoreID'];
				}
				
				
					
				
				//echo "scoreID = $scoreID".PHP_EOL;
				
				//$scoreID = $row['scoreID'];
			}
		}
		
		echo "checked till $lastScoreID".PHP_EOL;
	}
	
	
	/**
     * @return string
     * calculate airtime in readable format
     */
	public function secondsToHours($seconds) {
		$hours = floor($seconds / 3600);
		$mins = floor($seconds / 60 % 60);
		return $hours.'h '.$mins.'min';		
	}
	
	/**
     * @return string
     * calculate airtime in readable format
     */
	public function secondsToHoursAndDays($seconds) {
		$dtF = new \DateTime('@0');
		$dtT = new \DateTime("@$seconds");
		return $dtF->diff($dtT)->format('%ad %hh %imin');	
	}

    /**

     * Closes DB connection.
     */
    public function closeDb()
    {
        $this->_db->close();
    }

}