<?php

/**
 * @property array _scoreTypes
 */
class TAW_Source_Mysql_Process extends TAW_Source_Helper {
	private $serverList = array();

    public function __construct()
    {
        if(class_exists('TAW_Source_Mysql_Mysqli')) {
            $this->_resource = new TAW_Source_Mysql_Mysqli;
            $this->_db = $this->_resource->connect();
        }
        else {
            include('../Helper.php');
            $this->_resource = new TAW_Source_Mysql_Mysqli;
            $this->_db = $this->_resource->connect();
        }
        $this->_scoreTypes = array('crashed', 'shot', 'hit', 'kill', 'landing', 'takeoff', 'ejected', 'troops_loaded',
                                   'collided', 'cargo_unpacked', 'died', 'troops_dropped');
     }
	
	public function log($txt)
	{
		echo "[".date('Y-m-d H:i:s')."] - Process2.php: " .$txt.PHP_EOL;
	}

    /**
     * Creates database tables for TAW player base.
     */
    public function install()
    {	
		
    }
	
	public function setServerStatus($serverID, $status) {
		$this->log("setServerStatus(".$serverID.", '".$status."')");
		$update = $this->_db
			->prepare( 'UPDATE ko_missionstatus SET serverStatus = "'.$status.'", lastServerUpdate = ? WHERE serverID = ?;');
		$update->bind_param('ss', $row['lastServerUpdate'], $serverID);
		$update->execute();
	}
	
	public function getServerID($serverName)
	{
		//$this->log("getServerID('".$serverName."')");
		
		if (isset($this->serverList[$serverName]))
			return $this->serverList[$serverName];
		
		$query = "SELECT serverID FROM ko_missionstatus WHERE serverName='".$serverName."';";
		if ($db = $this->_db->query($query)) {
			// Database entry found
			if ($row = $db->fetch_assoc()) {
				// check if savegame was updated
				$this->serverList[$serverName] = $row['serverID'];
				return $row['serverID'];
			}
		}
		
		return false;
	}
	
	
	/**
     * @param $lua
     * @return bool
     * insert single-score entrys
     */
	// 
	public function processScore($scoreContainer, $serverID)
	{
		$this->log("processing Score! serverID = ".$serverID);
		
		if ($serverID == false) {
			$this->log("!!! WARNING !!! - serverID is false! Cannot insert score, returning");
			return;
		}
			
		
		$date = date('Y-m-d H:i:s');
		$counter = 0;
		$checker = Array();
		
		//var_dump($scoreContainer);
		//$this->log("scoreContainer count = ".count($scoreContainer));
		
		foreach($scoreContainer as $ucid => $score) {
			//var_dump($score);
			$this->log("Event: ".$score->achievment.", UCID: ".$ucid);
			
			// check if the scoreID is already scored! (hotfix)
			$query = "SELECT * from ko_scores WHERE scoreID=".$score->scoreID.";";
			$result = $this->_db->query($query);
			if($result) {
				if ($row = $result->fetch_assoc()) {
					echo "SKIPPING!		score ".$score->scoreID." is already in the system!!<br/>\n";
					echo "score finished<br/><br/>".PHP_EOL;
					$result->close();
					continue;
				}
				$result->close();
			}
			
			// debug filehandling
			/*$this->log("appending scoreID to debug file...");
			$my_file = 'debug.txt';
			$file_handle = fopen($my_file, 'a') or die('Cannot open file:  '.$my_file); //open file for writing
			//fwrite($file_handle, "scoreID: ".$score->scoreID." received, count(container) =".count($scoreContainer)."\n");
			fwrite($file_handle, $score->scoreID."\n");
			fclose($file_handle);*/
			
			$counter++;

			if(!isset($checker[$score->achievment]))
				$checker[$score->achievment] = 1;
			else
				$checker[$score->achievment]++;

			if(isset($score->ID)) { $score->sortieID = $score->ID; }
			if(!isset($score->sortieID)) { $score->sortieID = "-1"; }

			if(!isset($score->unitName)) { $score->unitName = "na"; }
			if(!isset($score->unitType)) { $score->unitType = "na"; }
			if(!isset($score->unitCategory)) { $score->unitCategory = "na"; }
			if(!isset($score->timestamp)) { $score->timestamp = 0; }
			if(isset($score->timer)) { $score->timestamp = $score->timer; }	// lets save the timer instead of timestamp, should be more useful
			if(!isset($score->side)) { $score->side = "na"; }

			// KILL/HIT/SHOT
			if(!isset($score->weapon)) { $score->weapon = "na"; }
			if(!isset($score->weaponCategory)) { $score->weaponCategory = "na"; }
			if(!isset($score->weaponGuidance)) { $score->weaponGuidance = "na"; }
			if(!isset($score->weaponMissileCategory)) { $score->weaponMissileCategory = "na"; }

			if(!isset($score->targetName)) { $score->targetName = "na"; }
			if(!isset($score->targetUnitName)) { $score->targetUnitName = "na"; }
			if(!isset($score->targetType)) { $score->targetType = "na"; }
			if(!isset($score->targetCategory)) { $score->targetCategory = "na"; }
			if(!isset($score->targetSide)) { $score->targetSide = "na"; }

			// SORTIE/LAND/TAKEOFF
			if(!isset($score->place)) { $score->place = "na"; }
			if(!isset($score->endReason)) { $score->endReason = "na"; }
			if(!isset($score->airTime)) { $score->airTime = 0; }

			// CARGO UNPACKED IN ZONE / DROPPED IN HOZONE
			if(!isset($score->zone)) { $score->zone = "na"; }
			if(!isset($score->droppedUnit)) { 
				$score->droppedUnit = "na"; 
			} elseif (isset($score->droppedUnit->desc)) { 
				$score->droppedUnit = $score->droppedUnit->desc; 
			}
			
			//if($score->achievment == "sortie") {
			//	var_dump($score);
			//}

			//$this->log("inserting ".$score->achievment);
			//print_r($score);

			try {
				$db = $this->_db->prepare('INSERT INTO ko_scores (ucid, serverID, sessionID, sortieID, achievment, unitCategory, unitType, unitName, timestamp, side, victimName, victimSide, victimType, victimCategory, victimUnitName, weapon, weaponGuidance, weaponMslCategory, weaponCategory, airTime, sortieEndReason, place, droppedUnit, zone, scoreID, created_at)
										   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
				
				if (false === $db) {
					var_dump($score);
					die('prepare() failed while saving score: '.htmlspecialchars($this->_db->error));
				}
				$db->bind_param('siddssssdssssssssssdssssis', $ucid, $serverID, $score->sessionID, $score->sortieID, $score->achievment, $score->unitCategory,
															$score->unitType, $score->unitName,	$score->timestamp, $score->side, $score->targetName, 
															$score->targetSide, $score->targetType, $score->targetCategory, $score->targetUnitName, 
															$score->weapon, $score->weaponGuidance, $score->weaponMissileCategory, $score->weaponCategory, 
															$score->airTime, $score->endReason, $score->place, $score->droppedUnit, $score->zone, $score->scoreID, $date);

			}
			catch (mysqli_sql_exception $e) {
				$this->log($e->getMessage());
			}

			$rx = $db->execute();
			if (false === $rx) {
				var_dump($score);
				die ('execute() failed while saving score: '.htmlspecialchars($this->_db->error));
			}
			$db->fetch();
			$db->close();

			//$this->log("- score finished");

			// handle connections
			if($score->achievment == "connected" || $score->achievment == "disconnected") {
				//$this->log("connection detected, updating PlayerData");

				$query = "SELECT * FROM `ko_players` WHERE ucid='".$ucid."';";
				$result = $this->_db->query($query);
				if($result) {
					if ($row = $result->fetch_assoc()) {
						//print_r($score);
						$this->log("numConnects = ".$row['numConnects']);
						$this->log("onlinetime = ".$row['onlinetime']);

						if($score->achievment == "connected") {
							$numConnects = $row['numConnects']+1;
							$this->log("numConnects = ".$numConnects);
							$update = $this->_db->prepare('UPDATE `ko_players` SET `numConnects` = ?, `updated_at` = ? WHERE ucid = ?');
							$update->bind_param('iss', $numConnects, $date, $ucid );
							$update->execute();

						} elseif($score->achievment == "disconnected") {
							if(!isset($score->airTime)) { $score->airTime = "0"; }
							$this->log("onlineTime in Score = ".$score->airTime);
							$onlineTime = $row['onlinetime'] + $score->airTime;
							$update = $this->_db->prepare('UPDATE `ko_players` SET `onlinetime` = ?, `updated_at` = ? WHERE ucid = ?');
							$update->bind_param('dss', $onlineTime, $date, $ucid );
							$update->execute();	
						}

						$result->close();
					} else {
						$this->outText("Player ".$score->killerName." is new! Inserting");

						$status = "OK";
						$onlineTime = 0;
						$ping = 0;
						$side = 0;
						$numConnects = 1;
						$name = $score->killerName;

						try {
							$db = $this->_db->prepare('INSERT INTO ko_players (ucid, player_name, ping, status, side, onlinetime, numConnects, updated_at, created_at)
														   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
							$db->bind_param('ssisidiss', $ucid, $name, $ping, $status, $side, $onlineTime, $numConnects, $date, $date);
						}
						catch (mysqli_sql_exception $e) {
							$this->log($e->getMessage());
						}		
						$db->execute();
							$db->fetch();
							$db->close();
					}
				} else {
					$this->log("Error in query '".$query."'");
				}


				//$this->log("connection handling");
			}
		}
		
		$this->log("inserted ".$counter." scores!");
		//print_r($checker);
	}

    
    /**
     * @param $lua
     * Processes map data insertion.
     */
    public function processMap($missionData, $serverID) 
	{
		$this->log("Processing MissionStatus, serverName = ".$properties->serverName);
		//var_dump($missionData);
		$date = date('Y-m-d H:i:s');
		
		
		//$this->log("checking properties");
		$properties = $missionData->properties;
		$updateObjectives = false;
		//print_r($properties);
		
		if(!isset($properties->serverName)) { $properties->serverName = "TAW EU 3"; }
		
		$query = "SELECT * FROM ko_missionstatus WHERE serverName='".$properties->serverName."';";
		if ($db = $this->_db->query($query)) {
			
			// prepare data
			$blueEjectedPilots = 0;
			$redEjectedPilots = 0;
			
			foreach ($properties->ejectedPilots as $ejectedPilot) {
				if($ejectedPilot->side == 1)
					$redEjectedPilots++;
				else
					$blueEjectedPilots++;	
			}
			
			/*$this->log("data for serverstatus:");
			$this->log("redEjectedPilots: ".$redEjectedPilots);
			$this->log("blueEjectedPilots: ".$blueEjectedPilots);
			$this->log("timer: ".$properties->timer);
			$this->log("startTimer: ".$properties->startTimer);
			$this->log("campaignSecs: ".$properties->campaignSecs);
			$this->log("lifeLimit: ".$properties->lifeLimit);
			$this->log("missionRuntime: ".$properties->missionRuntime);
			$this->log("date: ".$date);*/
			$this->log("serverName: ".$properties->serverName);
			$this->log("restartTime: ".$properties->restartTime);
			
			// Database entry found
			if ($row = $db->fetch_assoc()) {
				//$this->log("Mission Status entry found in Database! - checking if the savegame was updated");
				
				// check if savegame was updated
				$timeSinceSavegameUpdate = $properties->timer - $row['serverTime'];
				$timeSinceLastInjection = strtotime($date) - strtotime($row['lastServerUpdate']);
				//$this->log("time since savegame update: ".$timeSinceSavegameUpdate);
				//$this->log("time since last injection: ".$timeSinceLastInjection);
				//$this->log("date = ".$date);
				//$this->log("lastServerUpdate = ".$row['lastServerUpdate']);
				
				// check if server is offline!
				if($timeSinceLastInjection > 90 and $timeSinceSavegameUpdate == 0) {
					$this->log("server seems to be offline, no update on savegame, and last injection was ".$timeSinceLastInjection." seconds ago ...");
					// seems its offline, update missionstatus
					$update = $this->_db
						->prepare( 'UPDATE ko_missionstatus SET serverStatus = "offline", lastServerUpdate = ? WHERE serverName = ?;');
					$update->bind_param('ss', $row['lastServerUpdate'], $properties->serverName);
					$update->execute();
				}
				
				if ($timeSinceSavegameUpdate != 0) {
					//$this->log("savegame was updated since last check.");
					$this->log("server seems online");
					$updateObjectives = true;
					// all fine, update the database
					
					$update = $this->_db
						->prepare( 'UPDATE ko_missionstatus 
									SET lifeResetTimer = ?, redEjectedPilots = ?, blueEjectedPilots = ?, serverTime = ?, 
										serverStartTime = ?, campaignSecs = ?, lifeLimit = ?, missionRuntime = ?, lastServerUpdate = ?, serverStatus = "online"
										WHERE serverName = ?;');
					$update->bind_param('iiiddiidss', 
										$properties->restartTime, $redEjectedPilots, $blueEjectedPilots, $properties->timer, 
										$properties->startTimer, $properties->campaignSecs, $properties->lifeLimit, $properties->missionRuntime, $date, $properties->serverName);
					$update->execute();
				}
			} 
			
			// No Database yet
			else {
				$this->log("Mission Status entry not yet in Database! - inserting and updating objectives");
				$updateObjectives = true;
				$db = $this->_db->prepare('INSERT INTO ko_missionstatus (
														lifeResetTimer, redEjectedPilots, blueEjectedPilots, serverTime, serverStartTime, campaignSecs,
														lifeLimit, missionRuntime, serverName, serverStatus)
										   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "loading")');
				$db->bind_param('iiiddiids', 
								$properties->restartTime, $redEjectedPilots, $blueEjectedPilots, $properties->timer, $properties->startTimer, 
								$properties->campaignSecs, $properties->lifeLimit, $properties->missionRuntime, $properties->serverName);
				$db->execute();
				
				$serverID = $this->getServerID($properties->serverName);
			}
			//$this->log("query ok");
		}
		
		
		
		//print_r($missionData);
		if($updateObjectives && $serverID > 0) {
			$query = "DELETE FROM `ko_slotids` WHERE `serverID` = ".$serverID.";";
			$this->_db->query($query);	// delete the contents of slotids first, they are goign to be overwritten
		
			foreach ($missionData as $categoryName => $categoryData) {
				//$this->log("running through ".$categoryName);
				
				// Mission Properties
				
				if ($categoryName != "properties") {
				// Sort through Objectives	
					foreach ($categoryData as $objectiveName => $objectiveData) {
						//$this->log("- running through ".$objectiveName);

						//print_r($objectiveData);

						// insert slotIDs

						//$this->log("- - inserting slotIDs");
						foreach ($objectiveData->slotIDs as $slotID => $slotData)  {
							//$this->log("- - inserting slotID ".$slotID." name: ".$slotName);

							$db = $this->_db->prepare('INSERT INTO ko_slotids (serverID, slotID, slotName, slotType)
												   VALUES (?, ?, ?, ?)');
							$db->bind_param('idss',	$serverID,
													$slotID, 
													$slotData->name,
													$slotData->type);
							$db->execute();
						}

						//$this->log("- - checking units");
						$numUnits = 0;
						foreach ($objectiveData->groups as $groupName => $groupData) {
							if(gettype($groupData) == "object") {
								foreach ($groupData->units as $i => $unit) {
									$numUnits++;
								}
							} else {
								$this->log("-----\nFATAL ERROR: groupData is not an object. Possibly Playername fucking up the scores again ...\n-----");	
								break;
							}
						}						
						//$this->log(" - - numUnits: ".$numUnits);

						$insert = true;
						$query = "SELECT * FROM ko_objectives WHERE name = '" . $objectiveName . "' AND serverID = ".$serverID.";";
						if ($db = $this->_db->query($query)) {
							while ($row = $db->fetch_assoc()) {
								//$this->log("- - updating objective '".$objectiveName);
								// Update objective details if it exists and is on the server.

								//$this->log("- - - underAttack = ".$objectiveData->underAttack);
								//$this->log("- - - boolval(underAttack) = ".boolval($objectiveData->underAttack));
								//$this->log("- - -isset(underAttack) = ".isset($objectiveData->underAttack));


								$update = $this->_db
									->prepare('UPDATE ko_objectives SET
														   posX = ?, posY = ?, status = ?, coalition = ?, underAttack = ?, priority = ?, updated_at = ?, category = ?, numUnits = ?
														   WHERE name = ? AND serverID = ?;
								');
								$update->bind_param('ddssisssdsi', $objectiveData->posX, $objectiveData->posY, $objectiveData->status, $objectiveData->coa,
									$objectiveData->underAttack, $objectiveData->priority, $date, $categoryName, $numUnits, $objectiveName, $serverID);
								$update->execute();

								// Throw error if something goes wrong with statement.
								if ($update->errno !== 0 && !is_null($update->errno)) {
									die('Error occurred: ' . $update->errno . ', ' . $update->error);
								}

								$update->close();
								$insert = false;
							} 
							$db->close();
						}
						// Insert new objective if it doesn't exist yet.
						if ($insert) {
							//$this->log("- - inserting objective '".$objectiveName);
							
							$underAttack = boolval($objectiveData->underAttack);

							$db = $this->_db->prepare('INSERT INTO ko_objectives (serverID, name, posX, posY, status, coalition, underAttack, priority, updated_at, numUnits)
												   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
							$db->bind_param('isddssissd', 
								$serverID,
								$objectiveName, 
								$objectiveData->posX, 
								$objectiveData->posY, 
								$objectiveData->status, 
								$objectiveData->coa, 
								$underAttack, 
								$objectiveData->priority,
								$date,
								$numUnits);
							$db->execute();

							if ($db->errno !== 0 && !is_null($db->errno)) {
								die('Error occurred: ' . $db->errno . ', ' . $db->error);
							}

							$db->close();
						}
					}				
				}			
			}
		} else {
			$this->log("Savegame has not been updated, not updating objectives!");
		}
		//$this->closeDb();
    }

    /**
     * @param $lua
     * Inserts or updates player data (update if player is online).
     */
    public function processPlayerList($playerList, $serverID)
    {
		$this->log("processing PlayerList, serverID = ".$serverID);
		
        $date = date('Y-m-d H:i:s');
		//var_dump($playerList);
		
		//-------------------------
		// insert online players
		$query = "DELETE FROM `ko_onlineplayers` WHERE `serverID` = ".$serverID.";";	// delete all players
		$this->_db->query($query);
		
		foreach ($playerList as $ucid => $player) {
			if($ucid == "slotTable") {
				//$this->log("- inserting slotList");
				$query = "DELETE FROM `ko_slotlist` WHERE `serverID` = ".$serverID.";";	// list is so short, we'll overwrite it
				$this->_db->query($query);
				
				$db = $this->_db->prepare('INSERT INTO ko_slotlist (serverID, clientID, category, coalition)
											VALUES (?, ?, ?, ?)');
									   
				foreach ($player as $coalition => $categories) {
					$coa = $coalition + 1;
					foreach ($categories as $category => $slotTable) {
						foreach ($slotTable as $i => $clientID) {
							$db->bind_param('iiss', 
								$serverID,
								$clientID,
								$category,
								$coa);
							$db->execute();
							

							if ($db->errno !== 0 && !is_null($db->errno)) {
								die('Error occurred: ' . $db->errno . ', ' . $db->error);
							}
						}
					}
				}
				
				$db->close();
			} 
			else 
			{
				//$this->log("- inserting online Player: ".$player->name.", side: ".$player->side.", slot: ".$player->slot);
				//print_r ($player);
				if(strpos($player->slot, "forward_observer") !== false) {
					$player->slot = "-1";
				}
				$db = $this->_db->prepare('INSERT INTO ko_onlineplayers (serverID, ucid, name, ping, slot, side, clientID, created_at)
									   VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
				$db->bind_param('issiiiis', 
					$serverID,
					$ucid, 
					$player->name, 
					$player->ping, 
					$player->slot, 
					$player->side, 
					$player->id, 
					$date);
				$db->execute();

				if ($db->errno !== 0 && !is_null($db->errno)) {
					die('Error occurred: ' . $db->errno . ', ' . $db->error);
				}

				$db->close();
			}
		}
		//$this->log("- finished!");
    }
	
	public function processRadio($radioData, $serverID)
    {
		$this->log("processing RadioList, serverID = ".$serverID);
		
        $date = date('Y-m-d H:i:s');
		//var_dump($radioData);
		
		$query = "DELETE FROM `ko_radios` WHERE `serverID` = ".$serverID.";";
		$this->_db->query($query);	// delete the contents of slotids first, they are goign to be overwritten
		
		//--------------------------
		// go through radios
		foreach ($radioData as $idx => $player) {
			$selectedRadio = $player->selected;
			
			//var_dump($player);
			
			foreach ($player->radios as $jdx => $radio) {
				$this->log("- adding Radio: '".$radio->frequency."', selected = ".$radio->selected);

				$query2 = "SELECT `id` AS `pid` FROM `ko_players` WHERE `ucid`='".$player->ucid."';";
				if($db = $this->_db->query($query2)) {
					while ($row = $db->fetch_assoc()) {
						$pid = $row['pid'];
					}
					$db->free();
				}
				
				$db2 = $this->_db->prepare('INSERT INTO `ko_radios` (rid, pid, frequency, modulation, radioname, serverID, selected)
											VALUES (?, ?, ?, ?, ?, ?, ?)');
									   
				
				$db2->bind_param('iiiisii', 
								$radio->id,
								$pid,
								$radio->frequency,
								$radio->modulation,
								$radio->name,
								$serverID,
								$radio->selected);
				$db2->execute();

				if ($db2->errno !== 0 && !is_null($db->errno)) {
					die('Error occurred: ' . $db->errno . ', ' . $db->error); 
				}
				
				$db2->close();
			}
		}
		
		//$this->log("- finished!");
    }
	
	


	/**
     * Closes DB connection.
     */
    public function closeDb()
    {
        $this->_db->close();
    }
	
	public function outText($string)
	{
		echo $string.'<br/>'.PHP_EOL;	
	}
}