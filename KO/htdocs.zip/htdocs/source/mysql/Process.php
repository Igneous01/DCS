<?php

/**
 * @property array _scoreTypes
 */
class TAW_Source_Mysql_Process extends TAW_Source_Helper {

    public function __construct()
    {
        if(class_exists('TAW_Source_Mysql_Mysqli')) {
            $this->_resource = new TAW_Source_Mysql_Mysqli;
            $this->_db = $this->_resource->connect();
        }
        else {
            include('../Helper.php');
            $this->_resource = new TAW_Source_Mysql_Mysqli;
            $this->_db = $this->_resource->connect();
        }
        $this->_scoreTypes = array('crashed', 'shot', 'hit', 'kill', 'landing', 'takeoff', 'ejected', 'troops_loaded',
                                   'collided', 'cargo_unpacked', 'died', 'troops_dropped');
     }

    /**
     * Creates database tables for TAW player base.
     */
    public function install()
    {	
		//$isShell = (stristr(getcwd(), 'shell'));
        //$base = (getcwd() == "C:\Users\taw_deadbeef") ? "C:\xampp\htdocs\taw" : '';
        /*$lock = file_get_contents('C:\xampp\htdocs\ko\var\locks\lock_install');
        if (trim($lock) === 'false') {
			echo "Installing tables into Database";
            try {
                $this->_db
                    ->query("CREATE TABLE ko_players (
                     id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                     ucid VARCHAR(128) NOT NULL,
                     player_name VARCHAR(128) NOT NULL,
                     ping int(10) NOT NULL,
                     status VARCHAR(50),
                     side VARCHAR(2),
                     is_online tinyint(1),
                     ip_address varchar(60),
                     created_at TIMESTAMP,
                     updated_at TIMESTAMP,
                     UNIQUE (ucid)
                )");
                $this->_db
                    ->query("CREATE TABLE taw_ko_playerscores (
                                  id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                  ucid VARCHAR(128) NOT NULL,
                                  kills int(50),
                                  shot int(50),
                                  hit int(50),
                                  takeoff int(50),
                                  ejected int(50),
                                  landing int(50),
                                  crashed int(50),
                                  died int(50),
                                  troops_dropped int(50),
                                  troops_loaded int(50),
                                  collided int(50),
                                  cargo_unpacked int(50),
                                  UNIQUE (ucid)
                                )");
            }
            catch (Exception $e) {
                die('Unable to install database tables.');
            }

            // Install initial lua data.
            $this->_lua = new TAW_Source_Lua();
            $luaData = $this->_lua->getData();
            $this->processPlayerDB($luaData);
            $this->processScoreTable($luaData);
            $this->processMap($luaData);

            // lock the install file so it doesn't run again.
            file_put_contents('C:\xampp\htdocs\taw\var\locks\lock_install', 'true');
            
            echo 'Installation Finished';
            return true;
        }
        else {
            return true;
        }*/
    }
	
	
	/**
     * @param $lua
     * @return bool
     * insert single-score entrys
     */
	// 
	public function processScores($lua)
	{
		echo "\n\n<br/>----------------------------<br/>processing Scores!<br/>\n";
		
		$date = date('Y-m-d H:i:s');
		$counter = 0;
		$checker = Array();
		//print_r($lua['Scores']['scoreFiles']);
		foreach($lua['Scores']['scoreFiles'] as $scoreFile) {
			echo "going through ".$scoreFile."<br/>".PHP_EOL;
			
			$fp = file_get_contents($lua['Scores']['baseDir'].$scoreFile);
			$parse = new TAW_Source_Parser($fp);
			$scoreData = current($parse->toArray());
			rename($lua['Scores']['baseDir'].$scoreFile, $lua['Scores']['backupDir'].$scoreFile);
			
			foreach($scoreData as $ucid => $score) {
				echo "<br>Event: ".$score['achievment'].", UCID: ".$ucid."<br/>\n";
				
				print_r($score);
				echo "<br><br>- - scoreID = ".$score['scoreID']."<br>".PHP_EOL;
				// check if the scoreID is already scored! (hotfix)
				$query = "SELECT * from ko_scores WHERE scoreID=".$score['scoreID'].";";
				echo $query."<br/>".PHP_EOL;
				$result = $this->_db->query($query);
				if($result) {
					if ($row = $result->fetch_assoc()) {
						echo "SKIPPING!		score ".$score['scoreID']." is already in the system!!<br/>\n";
						echo "score finished<br/><br/>".PHP_EOL;
						$result->close();
						continue;
					}
					$result->close();
				}
				
				$counter++;
	
				if(!isset($checker[$score["achievment"]]))
					$checker[$score["achievment"]] = 1;
				else
					$checker[$score["achievment"]]++;
				
				if(isset($score['ID'])) { $score['sortieID'] = $score['ID']; }
				if(!isset($score['sortieID'])) { $score['sortieID'] = "-1"; }
				
				if(!isset($score['unitName'])) { $score['unitName'] = "na"; }
				if(!isset($score['unitType'])) { $score['unitType'] = "na"; }
				if(!isset($score['unitCategory'])) { $score['unitCategory'] = "na"; }
				if(!isset($score['timestamp'])) { $score['timestamp'] = 0; }
				if(isset($score['timer'])) { $score['timestamp'] = $score['timer']; }	// lets save the timer instead of timestamp, should be more useful
				if(!isset($score['side'])) { $score['side'] = "na"; }
	
				// KILL/HIT/SHOT
				if(!isset($score['weapon'])) { $score['weapon'] = "na"; }
				if(!isset($score['weaponCategory'])) { $score['weaponCategory'] = "na"; }
				if(!isset($score['weaponGuidance'])) { $score['weaponGuidance'] = "na"; }
				if(!isset($score['weaponMissileCategory'])) { $score['weaponMissileCategory'] = "na"; }
				
				if(!isset($score['targetName'])) { $score['targetName'] = "na"; }
				if(!isset($score['targetUnitName'])) { $score['targetUnitName'] = "na"; }
				if(!isset($score['targetType'])) { $score['targetType'] = "na"; }
				if(!isset($score['targetCategory'])) { $score['targetCategory'] = "na"; }
				if(!isset($score['targetSide'])) { $score['targetSide'] = "na"; }
				
				// SORTIE/LAND/TAKEOFF
				if(!isset($score['place'])) { $score['place'] = "na"; }
				if(!isset($score['endReason'])) { $score['endReason'] = "na"; }
				if(!isset($score['airTime'])) { $score['airTime'] = 0; }
				
				// CARGO UNPACKED IN ZONE / DROPPED IN HOZONE
				if(!isset($score['droppedUnit'])) { $score['droppedUnit'] = "na"; }
				if(!isset($score['zone'])) { $score['zone'] = "na"; }
				
				
				echo "inserting ".$score["achievment"]."<br />\n";
				//print_r($score);
				
				try {
					$db = $this->_db->prepare('INSERT INTO ko_scores (ucid, scoreID, sessionID, sortieID, achievment, unitCategory, unitType, unitName, timestamp, side, victimName, victimSide, victimType, victimCategory, victimUnitName, weapon, weaponGuidance, weaponMslCategory, weaponCategory, airTime, sortieEndReason, place, droppedUnit, zone)
											   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
					$db->bind_param('sdddssssdssssssssssdssss', $ucid, $score['scoreID'], $score['sessionID'], $score['sortieID'], $score['achievment'], $score['unitCategory'], $score['unitType'], $score['unitName'],
						$score['timestamp'], $score['side'], $score['targetName'], $score['targetSide'], $score['targetType'], $score['targetCategory'], $score['targetUnitName'], $score['weapon'], $score['weaponGuidance'], $score['weaponMissileCategory'], $score['weaponCategory'], $score['airTime'], $score['endReason'], $score['place'], $score['droppedUnit'], $score['zone']);
						
				}
				catch (mysqli_sql_exception $e) {
					echo $e->getMessage();
				}
					
				$db->execute();
					$db->fetch();
					$db->close();
				
				echo "score finished<br/><br/>".PHP_EOL;
				
				// handle connections
				if($score['achievment'] == "connected" || $score['achievment'] == "disconnected") {
					echo "connection detected, accessing PlayerData<br/>".PHP_EOL;	
					
					$query = "SELECT * FROM `ko_players` WHERE ucid='".$ucid."';";
					$result = $this->_db->query($query);
					if($result) {
						if ($row = $result->fetch_assoc()) {
							print_r($score);
							echo "numConnects = ".$row['numConnects']."<br/>".PHP_EOL;
							echo "onlinetime = ".$row['onlinetime']."<br/>".PHP_EOL;
									
							if($score['achievment'] == "connected") {
								$numConnects = $row['numConnects']+1;
								echo "numConnects = ".$numConnects."<br/>".PHP_EOL;
								$update = $this->_db->prepare('UPDATE `ko_players` SET `numConnects` = ?, `updated_at` = ? WHERE ucid = ?');
								$update->bind_param('iss', $numConnects, $date, $ucid );
								$update->execute();
												
							} elseif($score['achievment'] == "disconnected") {
								if(!isset($score['airTime'])) { $score['airTime'] = "0"; }
								echo "onlineTime in Score = ".$score['airTime'];
								$onlineTime = $row['onlinetime'] + $score['airTime'];
								$update = $this->_db->prepare('UPDATE `ko_players` SET `onlinetime` = ?, `updated_at` = ? WHERE ucid = ?');
								$update->bind_param('dss', $onlineTime, $date, $ucid );
								$update->execute();	
							}
							
							$result->close();
						} else {
							$this->outText("Player ".$score['killerName']." is new! Inserting");
							
							$status = "OK";
							$onlineTime = 0;
							$ping = 0;
							$side = 0;
							$numConnects = 1;
							$name = $score['killerName'];
							
							try {
								$db = $this->_db->prepare('INSERT INTO ko_players (ucid, player_name, ping, status, side, onlinetime, numConnects, updated_at, created_at)
															   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
								$db->bind_param('ssisidiss', $ucid, $name, $ping, $status, $side, $onlineTime, $numConnects, $date, $date);
							}
							catch (mysqli_sql_exception $e) {
								echo $e->getMessage();
							}		
							$db->execute();
								$db->fetch();
								$db->close();
						}
					} else {
						echo "Error in query '".$query."'<br/>".PHP_EOL;
					}
					
					
					echo "<br/>END connection handling<br/><br/>".PHP_EOL;
				}
			}
		}
		echo "inserted ".$counter." scores!";
		print_r($checker);
	}

    /**
     * @param $lua
     * @return bool
     * Processes the score table into something usable, and then inserts/updates database.
     */
    public function processScoreTable($lua)
    {
		echo "\n\n<br/>----------------------------<br/>processing Score Table!<br/>\n";
		
        $scoreData = $lua[2];
        $finalScores = array();
		
		//print_r($scoreData);
        foreach($scoreData as $ucid => $scores) {
			//echo "\n<br/>ucid: ".$ucid;
			
            if($ucid == "") {
                continue;
            }
            foreach($scores as $score) {
                if(isset($finalScores[$ucid][$score['achievment']])) {
                    $finalScores[$ucid][$score['achievment']] += 1;
                }
                else {
                    $finalScores[$ucid][$score['achievment']] = 1;
                }
            }
        }
		echo "\n";
        foreach($finalScores as $ucid => $score) {
			echo "	inserting score for ucid ".$ucid."<br/>\n";
            $ucid = (is_int($ucid)) ? (string)$ucid : $ucid;
            $ucid = preg_replace("/[^a-zA-Z0-9]/", "", $ucid);
            $result = $this->_db->query("SELECT `tkp`.ucid AS ucid_actual, `tkp`.player_name AS player_name,
                                         `tkps`.* FROM ko_players AS `tkp`
                                         LEFT JOIN taw_ko_playerscores AS `tkps` ON `tkp`.ucid = `tkps`.ucid
                                         WHERE `tkp`.ucid = '" . str_replace(' ', '', $ucid) . "';");
            if($result) {
				echo "		we have a result!<br/>\n";
                while ($row = $result->fetch_assoc()) {
                    $scoreType[$row['ucid']] = $row;
                    if(is_null($row['kills'])) {
						echo "		insert<br/>\n";
                        $this->insertPlayerScore($row['ucid_actual'], $finalScores);
                    }
                    else {
						echo "		update<br/>\n";
                        $this->updatePlayerScore($row['ucid'], $finalScores, $row);
                    }
                }
                $result->close();
            }
        }
        return true;
    }

    /**
     * @param $id
     * @param $data
     * @param $row
     * Updates the players score if online.
     */
    private function updatePlayerScore($ucid, $data, $row)
    {
		echo "\n\n<br/>----------------------------<br/>updating Scores!<br/>\n";
        $finalData = array();
        foreach($this->_scoreTypes as $scoreType) {
            if($scoreType == 'kill') {
                if(isset($data[$ucid][$scoreType])) {
                    $finalData[$scoreType] = (int)$data[$ucid]['kill'] + (int)$row['kills'];
                }
                else {
                    $finalData[$scoreType] = (int)$row['kills'];
                }
            }
            else {
                if(isset($data[$ucid][$scoreType])) {
                    $finalData[$scoreType] = (int)$data[$ucid][$scoreType] + (int)$row[$scoreType];
                }
                else {
                    $finalData[$scoreType] = (int)$row[$scoreType];
                }
            }
        }
        $update = $this->_db
            ->prepare('UPDATE taw_ko_playerscores SET kills = ?, shot = ?, hit = ?, takeoff = ?, ejected = ?,
                                                      landing = ?, crashed = ?, died = ?, troops_dropped = ?,
                                                      troops_loaded = ?, collided = ?, cargo_unpacked  = ?
                                                  WHERE ucid = ?
                        ');
        $update->bind_param('iiiiiiiiiiiis', $finalData['kill'], $finalData['shot'], $finalData['hit'],
                                             $finalData['takeoff'], $finalData['ejected'], $finalData['landing'],
                                             $finalData['crashed'], $finalData['died'], $finalData['troops_dropped'],
                                             $finalData['troops_loaded'], $finalData['collided'],
                                             $finalData['cargo_unpacked'], $ucid
        );
        $update->execute();

        // Throw error if something goes wrong with statement.
        if ($update->errno !== 0 && !is_null($update->errno)) {
            die('Error occurred: ' . $update->errno . ', ' . $update->error);
        }

        $update->close();
    }

    /**
     * @param $ucid
     * @param $data
     * Inserts a player score into the database via linking name.
     */
    private function insertPlayerScore($ucid, $data)
    {
		
        $playerScore = $data[$ucid];
        $db = null;

        foreach($this->_scoreTypes as $scoreType) {
            $scores[$scoreType] = (!isset($playerScore[$scoreType])) ? 0 : $playerScore[$scoreType];
        }
		print_r($scores);
        try {
            $db = $this->_db->prepare('INSERT INTO taw_ko_playerscores (ucid, kills, shot, hit, takeoff, ejected,
                                                                        landing, crashed, died, troops_dropped,
                                                                        troops_loaded, collided, cargo_unpacked)
                                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $db->bind_param('siiiiiiiiiiii', $ucid, $scores['kill'], $scores['shot'], $scores['hit'], $scores['takeoff'],
                $scores['ejected'], $scores['landing'], $scores['crashed'], $scores['died'], $scores['troops_dropped'],
                $scores['troops_loaded'], $scores['collided'], $scores['cargo_unpacked']);
				
        }
        catch (mysqli_sql_exception $e) {
            echo $e->getMessage();
        }

        $db->execute();
        $db->fetch();
        $db->close();
    }

    /**
     * @param $lua
     * Processes map data insertion.
     */
    public function processMap($lua) 
	{
		echo "<br/>\n<br/>\n----------------\n<br/>Processing MissionStatus<br/>\n";
        $missionData = $lua['SaveGame'];
		$date = date('Y-m-d H:i:s');
		
		
		echo "-----------------------------------------<br/> CHECKING PROPERTIES!<br/>".PHP_EOL;
		$properties = $missionData['properties'];
		$updateObjectives = false;
		//print_r($properties);
		
		if(!isset($properties['serverName'])) { $properties['serverName'] = "TAW EU 3"; }
		
		$query = "SELECT * FROM ko_missionstatus WHERE serverName='".$properties['serverName']."';";
		if ($db = $this->_db->query($query)) {
			
			// prepare data
			$blueEjectedPilots = 0;
			$redEjectedPilots = 0;
			
			foreach ($properties['ejectedPilots'] as $ejectedPilot) {
				if($ejectedPilot['side'] == 1)
					$redEjectedPilots++;
				else
					$blueEjectedPilots++;	
			}
			
			echo "data for serverstatus:<br/>".PHP_EOL;
			echo "restartTime: ".$properties['restartTime']."<br/>".PHP_EOL;
			echo "redEjectedPilots: ".$redEjectedPilots."<br/>".PHP_EOL;
			echo "blueEjectedPilots: ".$blueEjectedPilots."<br/>".PHP_EOL;
			echo "timer: ".$properties['timer']."<br/>".PHP_EOL;
			echo "startTimer: ".$properties['startTimer']."<br/>".PHP_EOL;
			echo "campaignSecs: ".$properties['campaignSecs']."<br/>".PHP_EOL;
			echo "lifeLimit: ".$properties['lifeLimit']."<br/>".PHP_EOL;
			echo "missionRuntime: ".$properties['missionRuntime']."<br/>".PHP_EOL;
			echo "date: ".$date."<br/>".PHP_EOL;
			echo "serverName: ".$properties['serverName']."<br/>".PHP_EOL;
			
			// Database entry found
			if ($row = $db->fetch_assoc()) {
				echo "Mission Status entry found in Database! - checking if the savegame was updated<br>".PHP_EOL;
				
				// check if savegame was updated
				$timeSinceSavegameUpdate = $properties['timer'] - $row['serverTime'];
				$timeSinceLastInjection = strtotime($date) - strtotime($row['lastServerUpdate']);
				echo "time since savegame update: ".$timeSinceSavegameUpdate."<br/>".PHP_EOL;
				echo "time since last injection: ".$timeSinceLastInjection."<br/>".PHP_EOL;
				echo "date = ".$date."<br/>".PHP_EOL;
				echo "lastServerUpdate = ".$row['lastServerUpdate']."<br/>".PHP_EOL;
				
				// check if server is offline!
				if($timeSinceLastInjection > 90 and $timeSinceSavegameUpdate == 0) {
					echo "server seems to be offline, no update on savegame, and last injection was ".$timeSinceLastInjection." seconds ago ...<br/>".PHP_EOL;
					// seems its offline, update missionstatus
					$update = $this->_db
						->prepare( 'UPDATE ko_missionstatus SET serverStatus = "offline", lastServerUpdate = ? WHERE serverName = ?;');
					$update->bind_param('ss', $row['lastServerUpdate'], $properties['serverName']);
					$update->execute();
				}
				
				if ($timeSinceSavegameUpdate != 0) {
					echo "savegame was updated since last check.<br/>".PHP_EOL;
					$updateObjectives = true;
					// all fine, update the database
					
					$update = $this->_db
						->prepare( 'UPDATE ko_missionstatus 
									SET lifeResetTimer = ?, redEjectedPilots = ?, blueEjectedPilots = ?, serverTime = ?, 
										serverStartTime = ?, campaignSecs = ?, lifeLimit = ?, missionRuntime = ?, lastServerUpdate = ?, serverStatus = "online"
										WHERE serverName = ?;');
					$update->bind_param('iiiddiidss', 
										$properties['restartTime'], $redEjectedPilots, $blueEjectedPilots, $properties['timer'], 
										$properties['startTimer'], $properties['campaignSecs'], $properties['lifeLimit'], $properties['missionRuntime'], $date, $properties['serverName']);
					$update->execute();
				}
			} 
			
			// No Database yet
			else {
				echo "Mission Status entry not yet in Database! - inserting and updating objectives<br/>".PHP_EOL;
				$updateObjectives = true;
				$db = $this->_db->prepare('INSERT INTO ko_missionstatus (
														lifeResetTimer, redEjectedPilots, blueEjectedPilots, serverTime, serverStartTime, campaignSecs,
														lifeLimit, missionRuntime, serverName, serverStatus)
										   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "loading")');
				$db->bind_param('iiiddiids', 
								$properties['restartTime'], $redEjectedPilots, $blueEjectedPilots, $properties['timer'], $properties['startTimer'], 
								$properties['campaignSecs'], $properties['lifeLimit'], $properties['missionRuntime'], $properties['serverName']);
				$db->execute();
			}
			echo "query ok<br/>".PHP_EOL;
		}
		
		
		
		//print_r($missionData);
		if($updateObjectives) {
			$query = "TRUNCATE TABLE ko_slotids;";
			$this->_db->query($query);	// delete the contents of slotids first, they are goign to be overwritten
		
			foreach ($missionData as $categoryName => $categoryData) {
				echo "running through ".$categoryName."<br/>\n";
				
				// Mission Properties
				
				if ($categoryName != "properties") {
				// Sort through Objectives	
					foreach ($categoryData as $objectiveName => $objectiveData) {
							echo "- running through ".$objectiveName."<br/>\n".PHP_EOL;
							
							//print_r($objectiveData);
							
							// insert slotIDs
							
							echo "- - inserting slotIDs<br/>".PHP_EOL;
							foreach ($objectiveData['slotIDs'] as $slotID => $slotData)  {
								//echo "- - inserting slotID ".$slotID." name: ".$slotName."<br/>".PHP_EOL;
								$slotIDnum = intval($slotID);
								
								$db = $this->_db->prepare('INSERT INTO ko_slotids (slotID, slotName, slotType)
													   VALUES (?, ?, ?)');
								$db->bind_param('dss', 
									$slotIDnum, 
									$slotData['name'],
									$slotData['type']);
								$db->execute();
							}
							
							echo "- - checking units<br/>".PHP_EOL;
							$numUnits = 0;
							foreach ($objectiveData['groups'] as $groupName => $groupData) {
								if(gettype($groupData) == "array") {
									foreach ($groupData['units'] as $i => $unit) {
										$numUnits++;
									}
								} else {
									echo "<br/>\n-----\nFATAL ERROR: groupData is not an Array. Possibly Playername fucking up the scores again ...</br>-----\n".PHP_EOL;	
									break;
								}
							}						
							echo "- - - numUnits: ".$numUnits."<br/>".PHP_EOL;
							
							$insert = true;
							$query = "SELECT * FROM ko_objectives WHERE name = '" . $objectiveName . "';";
							if ($db = $this->_db->query($query)) {
								while ($row = $db->fetch_assoc()) {
									echo "- - updating objective '".$objectiveName."'<br>\n";
									// Update objective details if it exists and is on the server.
									
									echo "- - - underAttack = ".$objectiveData['underAttack']."<br/>".PHP_EOL;
									echo "- - - boolval(underAttack) = ".boolval($objectiveData['underAttack'])."<br/>".PHP_EOL;
									echo "- - -isset(underAttack) = ".isset($objectiveData['underAttack'])."<br/>".PHP_EOL;
									
									
									$update = $this->_db
										->prepare('UPDATE ko_objectives SET
															   posX = ?, posY = ?, status = ?, coalition = ?, underAttack = ?, priority = ?, updated_at = ?, category = ?, numUnits = ?
															   WHERE name = ?;
									');
									$update->bind_param('ddssisssds', $objectiveData['posX'], $objectiveData['posY'], $objectiveData['status'], $objectiveData['coa'],
										$objectiveData['underAttack'], $objectiveData['priority'], $date, $categoryName, $numUnits, $objectiveName);
									$update->execute();
	
									// Throw error if something goes wrong with statement.
									if ($update->errno !== 0 && !is_null($update->errno)) {
										die('Error occurred: ' . $update->errno . ', ' . $update->error);
									}
	
									$update->close();
									$insert = false;
								} 
								$db->close();
							}
							// Insert new objective if it doesn't exist yet.
							if ($insert) {
								echo "- - inserting objective '".$objectiveName."' \n";
								
								$db = $this->_db->prepare('INSERT INTO ko_objectives (name, posX, posY, status, coalition, underAttack, priority, updated_at, numUnits)
													   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
								$db->bind_param('sddssissd', 
									$objectiveName, 
									$objectiveData['posX'], 
									$objectiveData['posY'], 
									$objectiveData['status'], 
									$objectiveData['coa'], 
									boolval($objectiveData['underAttack']), 
									$objectiveData['priority'],
									$date,
									$numUnits);
								$db->execute();
	
								if ($db->errno !== 0 && !is_null($db->errno)) {
									die('Error occurred: ' . $db->errno . ', ' . $db->error);
								}
	
								$db->close();
							}
							echo "\n<br/>".PHP_EOL;
						}				
				}			
			}
		} else {
			echo "Savegame has not been updated, not updating objectives!<br/>".PHP_EOL;
		}
		//$this->closeDb();
    }

    /**
     * @param $lua
     * Inserts or updates player data (update if player is online).
     */
    public function processPlayerDB($lua)
    {
		echo "\n\n<br><br>processing Player DB<br>\n";
        $scoreType = $lua['PlayerData'];
		$playerOnlineData = $lua['OnlinePlayers'];
		
        $date = date('Y-m-d H:i:s');
		//print_r($scoreType);
		
		//-------------------------
		// insert online players
		echo "\n<br/>Processing ".count($playerOnlineData)." Online Players\n<br/>";
		$query = "TRUNCATE TABLE `ko_onlineplayers`;";	// delete all players
		$this->_db->query($query);
		
		foreach ($playerOnlineData as $ucid => $player) {
			if($ucid == "slotTable") {
				echo PHP_EOL."<br/>inserting slotList<br/>".PHP_EOL;
				$query = "TRUNCATE TABLE `ko_slotlist`;";	// list is so short, we'll overwrite it
				$this->_db->query($query);
				
				$db = $this->_db->prepare('INSERT INTO ko_slotlist (clientID, category, coalition)
											VALUES (?, ?, ?)');
									   
				foreach ($player as $coalition => $categories) {
					foreach ($categories as $category => $slotTable) {
						foreach ($slotTable as $i => $clientID) {
							$db->bind_param('iss', 
								$clientID,
								$category,
								$coalition);
							$db->execute();

							if ($db->errno !== 0 && !is_null($db->errno)) {
								die('Error occurred: ' . $db->errno . ', ' . $db->error);
							}
						}
					}
				}
				
				$db->close();
			} 
			else 
			{
				echo "\n\n<br><br>inserting online Player: ".$player['name']."<br>\n";
				print_r ($player);
				if(strpos($player['slot'], "forward_observer") !== false) {
					$player['slot'] = "-1";
				}
				$db = $this->_db->prepare('INSERT INTO ko_onlineplayers (ucid, name, ping, slot, side, clientID, created_at)
									   VALUES (?, ?, ?, ?, ?, ?, ?)');
				$db->bind_param('ssiiiis', 
					$ucid, 
					$player['name'], 
					$player['ping'], 
					$player['slot'], 
					$player['side'], 
					$player['id'], 
					$date);
				$db->execute();

				if ($db->errno !== 0 && !is_null($db->errno)) {
					die('Error occurred: ' . $db->errno . ', ' . $db->error);
				}

				$db->close();
			}
		}
		echo "<br/>finished!\n\n<br><br>".PHP_EOL;
		echo "<br/>Player Database:<br/>".PHP_EOL;
		
		//-------------------------
		// player Database
		// hopefull obsolete
        /*foreach ($scoreType as $ucid => $player) {
        	echo "ucid: ".$ucid."<br/>".PHP_EOL;
			print_r($player);
            // Check to see if unique player id already exists.
			if(!isset($player['onlineTime'])) { $player['onlineTime'] = 0; }
            $insert = true;
            $query = "SELECT * FROM ko_players WHERE ucid = '" . $ucid . "';";
            if ($db = $this->_db->query($query)) {
                while ($row = $db->fetch_assoc()) {
					echo "updating player '".$player['name']."': ";
					echo "online time = ".$player['onlineTime']."<br>\n";
                    // Update player details if he does exist and is on the server. DEBUG == FALSE && FALSE.
					
					if(!isset($player['numConnects'])) { $player['numConnects'] = 0; }
					if(!isset($player['ping'])) { $player['ping'] = 0; }
					if(!isset($player['onlinetime'])) { $player['onlinetime'] = 0; }
					if(!isset($player['numConnects'])) { $player['numConnects'] = 0; }
					
					$player['name'] = str_replace("'", "", $player['name']);
					$update = $this->_db
						->prepare('UPDATE ko_players SET
											   player_name = ?, ping = ?, status = ?, side = ?, onlinetime = ?, numConnects = ?, updated_at = ?
											   WHERE ucid = ?;
					');
					$update->bind_param('sissdiss', $player['name'], $player['ping'], $player['status'],
						$player['side'], intval($player['onlineTime']), intval($player['numConnects']), $date, $ucid);
					$update->execute();

					// Throw error if something goes wrong with statement.
					if ($update->errno !== 0 && !is_null($update->errno)) {
						die('Error occurred: ' . $update->errno . ', ' . $update->error);
					}

					$update->close();
					$insert = false;
                }
                $db->close();
            }
            // Insert new player if he doesn't exist.
            if ($insert) {
				if(isset($player['name'])) {
					echo "\ninserting player '".$player['name']."' with ucid: ".$ucid."<br>";
					//$player['online'] = (is_null($player['online']) || !$player['online']) ? false : true;
					$player['name'] = str_replace("'", "", $player['name']);
					if(!isset($player['numConnects'])) { $player['numConnects'] = 0; }
					if(!isset($player['ping'])) { $player['ping'] = 0; }
					if(!isset($player['onlinetime'])) { $player['onlinetime'] = 0; }
					
					
					if($player['name'] !== "") {
						$db = $this->_db->prepare('INSERT INTO ko_players (ucid, player_name, ping, status, side,
																			  onlinetime, numConnects, created_at, updated_at)
											   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
						$db->bind_param('ssisidiss', 
							$ucid, 
							$player['name'], 
							0, 
							"OK", 
							0, 
							0.0,
							1,
							$date, 
							$date);
						$db->execute();
	
						if ($db->errno !== 0 && !is_null($db->errno)) {
							die('Error occurred: ' . $db->errno . ', ' . $db->error);
						}
	
						$db->close();
					}
				} else {
					echo "<br/><b>WARNING:	 no Playername for ucid: ".$ucid."</b></br>";
				}
            }
        }*/
    }


	/**
     * Closes DB connection.
     */
    public function closeDb()
    {
        $this->_db->close();
    }
	
	public function outText($string)
	{
		echo $string.'<br/>'.PHP_EOL;	
	}
	
		
	
	/** backup
     * @return array
     * Gets online players from database.
     */
    /*public function getOnlinePlayerData()
    {
        $players = array();
        $query = "SELECT `tkp`.name AS name,
						 `tkp`.ping AS ping,
						 `tkp`.side AS side,
                         `tkps`.* FROM ko_onlineplayers AS `tkp`
                         LEFT JOIN taw_ko_playerscores AS `tkps`
                         ON `tkp`.ucid = `tkps`.ucid;";
        if($db = $this->_db->query($query)) {
            while ($row = $db->fetch_assoc()) {
                $players[] = $row;
            }
            $db->free();
        }
        return $players;
    }*/

    /**
     * @return array
     * Returns scores for all players.
     */
    /*public function getTotalScoreData()
    {
        $playerScores = array();
        $query = "SELECT `tkp`.ucid
                      AS ucid_actual, `tkp`.player_name AS player_name,
                      `tkps`.* FROM ko_players AS `tkp`
                      LEFT JOIN taw_ko_playerscores AS `tkps` ON `tkp`.ucid = `tkps`.ucid;";
        if ($db = $this->_db->query($query)) {
            while ($row = $db->fetch_assoc()) {
                $playerScores[] = $row;
            }
            $db->free();
        }
        return $playerScores;
    }*/
}