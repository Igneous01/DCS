<?php

class TAW_Source_Mysql_Mysqli {

    /**
     * TAW_Source_Mysql_Mysqli constructor.
     */
    public function __construct()
    {
        $this->_config = new TAW_Source_Config();
    }

    /**
     * @return mysqli
     * Connect to MySQL server.
     */
    public function connect()
    {
        $host = $this->_config->mysql_host;
        $username = $this->_config->mysql_username;
        $password = $this->_config->mysql_password;
        $db = $this->_config->mysql_dbname;

        $conn = new mysqli($host, $username, $password, $db);

        if (mysqli_connect_error()) {
            die('Connect Error (' . mysqli_connect_errno() . ') '
                . mysqli_connect_error());
        }

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        return $conn;
    }

}