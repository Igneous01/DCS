<?php
public function getWeaponsUsed()
	{
		echo "getWeaponsUsed()";
		$weapons = array();
		// loop through all scores
		$query = "SELECT weapon, weaponCategory, weaponGuidance, weaponMslCategory FROM ko_scores;";		
		if($db = $this->_db->query($query)) {
			while ($row = $db->fetch_assoc()) {
				if(!isset($weapons[$row['weapon']]))
					$weapons[$row['weapon']] = 1;
				else
					$weapons[$row['weapon']] = $weapons[$row['weapon']] + 1;
			}
			
			$db->free();
		}
		
		$weaponArray = array(
		  'R-27R' => 'missile',
		  'R-73' => 'missile',
		  'R-27T' => 'missile',
		  'MIM-23B' => 'missile',
		  'FIM-92C' => 'missile',
		  'MIM-23B Hawk' => 'missile',
		  'FIM-92C Stinger' => 'missile',
		  'R-27T (AA-10B)' => 'missile',
		  'AIM-7M' => 'missile',
		  '9M33' => 'missile',
		  'MIM-72G' => 'missile',
		  '9M39' => 'missile',
		  'AIM-9P5' => 'missile',
		  'AIM-9M' => 'missile',
		  'Kh-25MPU' => 'missile',
		  'Kh-29L' => 'missile',
		  '3M9M' => 'missile',
		  '9M38M1' => 'missile',
		  'Mk-82 SnakeEye' => 'bomb',
		  'Mk-82' => 'bomb',
		  'Cannon' => 'shell',
		  'AGM-65D' => 'missile',
		  '9M31' => 'missile',
		  '2A7_23_HE' => 'shell',
		  '2A7_23_AP' => 'shell',
		  'GBU-12' => 'bomb',
		  'GBU-38' => 'bomb',
		  'CBU-105' => 'bomb',
		  'AGM-65H' => 'missile',
		  'HYDRA-70 M151' => 'rocket',
		  'MATRA' => 'missile',
		  'Vikhr M' => 'missile',
		  'ROCKEYE' => 'bomb',
		  'S-8KOM' => 'rocket',
		  'Kh-29T' => 'missile',
		  'CBU-97' => 'bomb',
		  'S-8OFP2' => 'rocket',
		  '7_62x51' => 'shell',
		  'M2_12_7_T' => 'shell',
		  'M61_20_HE' => 'shell',
		  'M61_20_AP' => 'shell',
		  'Kh-25ML' => 'missile',
		  'S-25L' => 'missile',
		  '9M333' => 'missile',
		  'M256_120_AP' => 'shell',
		  'M242_25_HE_M792' => 'shell',
		  'M68_105_AP' => 'shell',
		  '2A46M_125_AP' => 'shell',
		  'Utes_12_7x108_T' => 'shell',
		  'BGM-71 TOW' => 'missile',
		  '2A46M_125_HE' => 'shell',
		  'AT-11 Sniper' => 'missile',
		  'HESH_105' => 'shell',
		  'M242_25_AP_M791' => 'shell',
		  '2A42_30_HE' => 'shell',
		  'BetAB-500ShP' => 'bomb',
		  'BetAB-500' => 'bomb',
		  'RBK-500 PTAB-10' => 'bomb',
		  'FAB-500' => 'bomb',
		  'S-5KO' => 'rocket',
		  '7_62x54' => 'shell',
		  'CBU-103' => 'bomb',
		  'GBU-10' => 'bomb',
		  'GBU-31' => 'bomb',
		  'CBU-52B' => 'bomb',
		  'FAB-100' => 'bomb',
		  'S-8TsM' => 'rocket',
		  'KAB-500KR' => 'bomb',
		  'S-24A' => 'missile',
		  'HYDRA-70 MK5' => 'rocket',
		  'RBK-500U PTAB-1M' => 'bomb',
		  'M256_120_HE' => 'shell',
		  '9M33 Osa (SA-8 Gecko)' => 'missile',
		  'R-73 (AA-11)' => 'missile',
		  'S-13OF' => 'rocket',
		  'S-25OFM' => 'rocket',
		  'Mk-82AIR' => 'bomb',
		 );
		 
		 foreach($weaponArray as $weapon => $category) {
			echo "updating ".$weapon." with category ".$category."<br>".PHP_EOL;
			$update = $this->_db
				->prepare('UPDATE ko_scores SET weaponCategory = ? WHERE weapon = ?');
			$update->bind_param('ss', $category, $weapon);
			$update->execute();
	
			// Throw error if something goes wrong with statement.
			if ($update->errno !== 0 && !is_null($update->errno)) {
				die('Error occurred: ' . $update->errno . ', ' . $update->error);
			}
	
			$update->close();
		 }
		return $weapons;
	}
	?>