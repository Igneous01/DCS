<?php

class TAW_Source_Ftp {

    public function __construct()
    {
        $this->_data = '' . DIRECTORY_SEPARATOR;
    }

    /**
     * Downloads required files for rendering of data.
     */
    public function download($location = null)
    {
		
        $config = new TAW_Source_Config();
        $ftp = ftp_connect($config->ftp_host, $config->ftp_port, 120);
        $login = ftp_login($ftp, $config->ftp_username, $config->ftp_password);
		
		
		$location = "C:/xampp/htdocs/taw"; // quickfix
        if(!is_null($location)) {
            $this->_data = $location . $this->_data;
        }
		
		echo 'Filename: "' . $this->_data . 'ko_Savegame.lua"';

        if($ftp !== FALSE && $login !== FALSE)
        {
            try {
                $g1 = ftp_get($ftp, $this->_data . 'ko_Savegame.lua', 'ko_Savegame.lua', FTP_BINARY);
                $g2 = ftp_get($ftp, $this->_data . 'ko_unit_data_dyn.lua', 'ko_unit_data_dyn.lua', FTP_BINARY);
                $g3 = ftp_get($ftp, $this->_data . 'ko_PlayerData.lua', 'ko_PlayerData.lua', FTP_BINARY);
                $g4 = ftp_get($ftp, $this->_data . 'ko_Scores.lua', 'ko_Scores.lua', FTP_BINARY);
                $g5 = ftp_get($ftp, $this->_data . 'ko_PlayersOnline.lua', 'ko_Scores.lua', FTP_BINARY);
                if(!$g1 || !$g2 || !$g3 || !$g4 || !$g5) {
                    Throw new Exception('Unable to download file list.');
                }
            }
            catch (Exception $e) {
                die($e->getMessage());
            }

            ftp_close($ftp);
        }
        else {
            if(!$ftp) {
                die('Unable to connect to FTP server.');
            }
            else {
                die('Username/Password incorrect for FTP server.');
            }
        }
    }

}