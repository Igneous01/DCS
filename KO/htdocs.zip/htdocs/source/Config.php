<?php

class TAW_Source_Config {

    // Only modify this.
    const mysql_username = 'root';
    const mysql_password = 'Dcsna33';
	const mysql_host = '127.0.0.1';
	//const mysql_username = 'kouser';
	//const mysql_password = 'kodb#2020';
	//const mysql_host = '137.74.160.6';
    const mysql_dbname = 'ko';
	const mysql_port = 3306;
    const ftp_host = '83.215.132.181';
    const ftp_username = 'taw_access';
    const ftp_password = 'taw123!';
    const ftp_timeout = 120;
    const ftp_port = 21;
    // End, don't modify below.

    /**
     * TAW_Source_Config constructor.
     * Pass configuration variables through for rest of application.
     */
    public function __construct()
    {
        $this->ftp_password = self::ftp_password;
        $this->ftp_username = self::ftp_username;
        $this->ftp_host = self::ftp_host;
        $this->ftp_port = self::ftp_port;
        $this->ftp_timeout = self::ftp_timeout;
        $this->mysql_host = self::mysql_host;
        $this->mysql_dbname = self::mysql_dbname;
        $this->mysql_username = self::mysql_username;
        $this->mysql_password = self::mysql_password;
        $this->mysql_port = self::mysql_port;
        return $this;
    }

}