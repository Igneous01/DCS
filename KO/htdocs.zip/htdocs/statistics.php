<?php
//include('source/Helper.php');
//$helper = new TAW_Source_Helper();
//$data = $helper->getAllData(4);
//$skip = array('player_id_actual', 'id', 'player_id', 'shot', 'hit', 'collided');
?>
<html>
	<head>
		<link rel="shortcut icon" type="image/ico" href="assets/images/tkosignet.ico" />
		<title>The Kaukasus Offensive - STATISICS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/tablesorter/css/theme.dark.css" rel="stylesheet" type="text/css">
	<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.js"></script> 	
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.widgets.js"></script>

	<script>
		function is_touch_device() {
		  return 'ontouchstart' in window        // works on most browsers 
			  || navigator.maxTouchPoints;       // works on IE10/11 and Surface
		};

		// tablesorter
		$("table").tablesorter({   
			theme: 'dark',
			widgets: ['saveSort', "zebra"]
		});
		
		var mapImageSizes = new Array();
		
		$(document).ready(function() { 
			$("#PlayerListTable").tablesorter({   
				theme: 'dark',
				widgets: ['saveSort', "zebra"]
			}); 
			$("#StatisticTable").tablesorter({   
				theme: 'dark',
				widgets: ['saveSort', "zebra"]
			});
			
			handleResize();
		}); 
		
		
		//setInterval("refreshContent();", 60000);
		
		//var webroot = "http://164.132.233.62/ko";
		var webroot = "";
		function refreshContent() {
			$("#PlayerListWrapper").load(webroot+"/statistics.php #PlayerListTable", function() { 
				$("#PlayerListTable").tablesorter({   
					theme: 'dark',
					widgets: ['saveSort', "zebra"]
				}); 
				$("#PlayerListTable").trigger("update"); 
				//$("#PlayerListTable").trigger("appendCache");
			});
			$("#StatisticWrapper").load(webroot+"/statistics.php #StatisticTable", function() { 
				$("#StatisticTable").tablesorter({   
					theme: 'dark',
					widgets: ['saveSort', "zebra"]
				}); 
				$("#StatisticTable").trigger("update"); 
				//$("#StatisticTable").trigger("appendCache");
			});
		}
	</script>
	
	<body>
		<?php include_once('analyticstracking.php'); ?>
		<header>
			<?php include("navbar.php"); ?>
		</header>
			
		
		
		<?php
		// print_r($data['total_scores']); 
		$scoreFields = array(
			"playerName",
			"side",
			"kill",
			"A2A",
			"A2G",
			"G2A",
			"washit",
			"teamkill",
			"ejected",
			"crashed",
			"died",
			"takeoff",
			"landing",
			"emergencylanding",
			"shot",
			"hit",
			"pilot_rescued",
			"pilot_captured",				
			"neutral_base_occupied",
			"cargo_unpacked_in_zone",
			"crate_deployed",
			"convoy_deployed",
			"sortie",
			"airtime",
			//"onlinetime",
		);
		?>

		<section class="textBlock" id="Statistics">
		<h2>STATISTICS</h2>
		Statistics are currenctly deactivated for performance reasons
		</section>
		<?php //print_r($data); ?>
    </body>
</html>
