<?php

include('..\source\Helper.php');
echo 'Executing TAW - Kaukasus Offensive Cron Job.' . PHP_EOL;
$helper = new TAW_Source_Helper();
echo 'Downloading Updates..' . PHP_EOL;

try {
    $baseDir = str_replace('shell', '', getcwd());
    // Download latest lua files from server.
    //$helper->_ftp->download($baseDir);
    echo 'Done, executing MySQL update.' . PHP_EOL;
    $lua = $helper->_lua;
    $luaData = $lua->getData($baseDir);
    $helper->_mysql_process->processPlayerDB($luaData);
    $helper->_mysql_process->processScoreTable($luaData);
    $helper->_mysql_process->processMap($luaData);
    echo 'Finished database update.' . PHP_EOL;
}
catch (Exception $e) {
    die($e->getMessage());
}

echo 'End.' . PHP_EOL;