<?php
include('source/Helper.php');
$helper = new TAW_Source_Helper();
$data = $helper->getScoreForUnitCategory("HELICOPTER");
$skip = array('player_id_actual', 'id', 'player_id', 'shot', 'hit', 'collided');
?>
<html>
	<head>
		<link rel="shortcut icon" type="image/ico" href="assets/images/tkosignet.ico" />
		<title>The Kaukasus Offensive - STATISICS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/tablesorter/css/theme.dark.css" rel="stylesheet" type="text/css">
	<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.js"></script> 	
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.widgets.js"></script>

	<script>
		function is_touch_device() {
		  return 'ontouchstart' in window        // works on most browsers 
			  || navigator.maxTouchPoints;       // works on IE10/11 and Surface
		};

		// tablesorter
		$("table").tablesorter({   
			theme: 'dark',
			widgets: ['saveSort', "zebra"]
		});
		
		var mapImageSizes = new Array();
		
		$(document).ready(function() { 
			$("#StatisticTable").tablesorter({   
				theme: 'dark',
				widgets: ['saveSort', "zebra"]
			});
			
		}); 
		
		
		setInterval("refreshContent();", 10000);
		
		function refreshContent() {
			$("#StatisticWrapper").load("http://83.215.132.181/ko/helicopterstats.php #StatisticTable", function() { 
				$("#StatisticTable").tablesorter({   
					theme: 'dark',
					widgets: ['saveSort', "zebra"]
				}); 
				$("#StatisticTable").trigger("update"); 
			});
		}
	</script>
	
	<body>
		<header>
			<?php include("navbar.php"); ?>
		</header>
			
		
		<?php// print_r($data['total_scores']); ?>
		<?php
		
			$scoreFields = array(
				0 => "name",
				1 => "kill",
				2 => "A2A",
				3 => "A2G",
				4 => "G2A",
				5 => "died",
				6 => "crashed",
				7 => "takeoff",
				8 => "landing",
				9 => "shot",
				10 => "hit",
				11 => "troops_dropped",
				12 => "neutral_base_occupied",
				13 => "cargo_unpacked_in_zone",
				14 => "crate_deployed",
				15 => "sortie",
				16 => "airtime",
				17 => "onlinetime",
			);
		?>

		<section class="textBlock" id="Statistics">
		<h2>STATISTICS</h2>
			<div id="StatisticWrapper" style="background: url('../images/headerimage.jpg') top no-repeat;">
				<table  id="StatisticTable" class="tablesorter tablesorter-dark">
					<thead  id="StatisticContent">
						<tr>
<?php	 				
						$statWidthTable = array ( 0  => "400px", 1  => "25px", 2  => "25px", 3 => "25px", 4 => "25px", 5 => "25px", 6 => "25px", 7 => "25px", 8 => "25px", 9 => "25px", 10 => "25px"  );
						foreach($scoreFields as $i => $scoreName): 
						
						if 	($scoreName == "name")							$scoreName = "Callsign";
						elseif 	($scoreName == "died") 						$scoreName = "Died";
						elseif 	($scoreName == "crashed") 					$scoreName = "Crashed";
						elseif 	($scoreName == "shot") 						$scoreName = "Shots fired";
						elseif 	($scoreName == "hit")						$scoreName = "Hits";
						elseif 	($scoreName == "kill") 						$scoreName = "Victories";
						elseif 	($scoreName == "takeoff") 					$scoreName = "Takeoff";
						elseif 	($scoreName == "landing") 					$scoreName = "Landed";
						elseif	($scoreName == "cargo_unpacked_in_zone") 	$scoreName = "BASE supplied";
						elseif	($scoreName == "neutral_base_occupied") 	$scoreName = "BASE occupied";
						elseif 	($scoreName == "crate_deployed") 			$scoreName = "SAMs deployed";
						elseif 	($scoreName == "troops_dropped") 			$scoreName = "Soldiers inserted";
						elseif 	($scoreName == "sam_deployed") 				$scoreName = "SAM deployed";
							
						$width = "25px";
						if (count($statWidthTable) > $i)
							$width = $statWidthTable[$i];
						else
							$width = "25px"; ?>
							<th <?php echo "width=".$width; if($i!=0) echo " align=center"; ?>><?php echo $scoreName; ?></th>
<?php					endforeach; ?>
						</tr>
					</thead>
				<tbody id="StatisticContent">
<?php 				foreach($data as $player): ?>
					<tr id="StatisticRows">
<?php 					foreach($scoreFields as $j => $scoreName): ?>
						<td <?php 
							if($j!=0) echo " align=center";
							if(isset($player[$scoreName]))
								echo ">".$player[$scoreName];
							else
								echo ">0";?></td>
<?php 					endforeach; ?>
					</tr>
<?php				endforeach; ?>
				</tbody>
				</table>
			</div>
		</section>
		<?php print_r($data); ?>
    </body>
</html>
