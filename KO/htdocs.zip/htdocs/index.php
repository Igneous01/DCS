<?php
setcookie("serverSelected");

include('source/Helper.php');

$helper = new TAW_Source_Helper();
//$serverName = "DEADBEEFS LAIR";
$serverName = "TAW EU 3";
$serverID = $helper->getServerID($serverName);

// load cookie
if(isset($_COOKIE["serverSelected"])) 
		$serverID = $_COOKIE["serverSelected"];

$data = $helper->getMainData($serverID);
$map = $data['map'];
$missionStatus = $data['missionStatus'];

//echo "serverID = $serverID</br>".PHP_EOL;



?>
<html>
	<head>
		<link rel="shortcut icon" type="image/ico" href="assets/images/tkosignet.ico" />
		<title>The Kaukasus Offensive</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/css/map.css" rel="stylesheet" type="text/css">
	<link href="assets/css/slotlist.css" rel="stylesheet" type="text/css">
	<link href="assets/tablesorter/css/theme.dark.css" rel="stylesheet" type="text/css">
	<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.js"></script> 	
	<script type="text/javascript" src="assets/tablesorter/js/jquery.tablesorter.widgets.js"></script>

	<script>
		// tablesorter
		$("table").tablesorter({   
			theme: 'dark',
			widgets: ['saveSort', "zebra"]
		});
		
		
		setInterval("refreshContent();", 10000);
		
		//var webroot = "https://164.132.233.62/ko";
		var webroot = "";
		function refreshContent() {
			//console.log("index.php: refreshContent()");
			
			$("#map").load(webroot+" #mapWrapper", function() {
				handleResize();
				
				for (i = 0; i < infoBoxSetups.length; i++) {
					var data = infoBoxSetups[i];
					infoBoxSetup(data.symID, data.boxID, true);
				}
				
				if($turnedOn) {
					$($turnedOn).removeClass("hidden");
					//$($turnedOn).css("z-index", "100");
				}
				
				console.log("map was refreshed from index.php");
			});
			$("#ServerInfo").load(webroot+" #ServerStatus", function() {});
			$("#SlotList").load(webroot+" #SlotListWrapper", function() {});
			$("#PlayerList").load(webroot+" #PlayerListWrapper", function() { 
				$("#PlayerListTable").tablesorter({   
					theme: 'dark',
					widgets: ['saveSort', "zebra"]
				}); 
				$("#PlayerListTable").trigger("update"); 
				//$("#PlayerListTable").trigger("appendCache");
			});
			$("#StatisticWrapper").load(webroot+" #StatisticTable", function() { 
				$("#StatisticTable").tablesorter({   
					theme: 'dark',
					widgets: ['saveSort', "zebra"]
				}); 
				$("#StatisticTable").trigger("update"); 
				//$("#StatisticTable").trigger("appendCache");
			});
		}
	</script>
	
	<body>
		<?php include_once('analyticstracking.php') ?>
		<header>
			<?php include("navbar.php"); ?>
		</header>
		<section id="introduction">
			<div id ="intro_inline">
				<div id="intro_tawlogo"><img src="assets/logos/tawsealsourcev300pixels.png" width="200px" /></div>
				<div id="intro_text">
					<div>The Kaukasus Offensive is a small-scale persistent online dynamic campaign for DCS-World (Digital Combat Simulator). This means that whatever you achieve during your stay on the mission is being saved and will be at the same state even after a server-restart.  This micropage has the purpose of providing you with all necessary information to plan your sortie.</div>
					<div>In order to move along in the campaign, Teamplay is key!</div>
					<div>While lonewolves are welcome, we strongly recommend and encourage you to use <a href="https://github.com/ciribob/DCS-SimpleRadioStandalone/releases/latest">Simple-Radio</a> and organize your efforts with the other players. We strongly encourage you to install and run it. It connects automatically. All you need to do is switch your Radio on. The main frequency is: 251.00 AM </div>
					<div>No matter which aircraft you choose to fly, there is a dedicated task for you, and you will need a team with a healthy mix of aircrafts to help you succeed with your task, and vice versa.</div>
				</div>
			</div>
			
		</section>
		<div><?php include("navbar.php"); ?></div>
		<?php include("map.php"); ?>
		<section class="textBlock" id="ServerInfo">
			<div id="ServerStatus">
				<p style="margin-left: 20px;">
					SIMPLE RADIO IS MANDATORY ON THIS SERVER!<br/>
					<a href="https://github.com/ciribob/DCS-SimpleRadioStandalone/releases/latest">click here to download ...</a><br/><br/>
					We have updated the <a href="briefing.php">BRIEFING</a> and introduced a <a href="briefing.php#CodeOfEthics">Code of Ethics</a> to improve fairness and gaming experience for everyone.<br/>
					
				</p>
				<div id="ServerStatusContent">
					<div>
						Server is <b><?php echo $missionStatus['serverStatus'] ?></b>
					</div>
					<div>
						Life reset in <b><?php echo $helper->mysql_statistics->secondsToHours(60*$missionStatus['lifeResetTimer'])?></b><br/>
						Mission Restart: <b><?php echo $helper->mysql_statistics->secondsToHours(14400-($missionStatus['serverTime']-$missionStatus['serverStartTime']))?></b><br/>
						Campaign is on since: <b><?php echo $helper->mysql_statistics->secondsToHoursAndDays($missionStatus['campaignSecs']) ?></b>
					</div>
					<div>
						There are <b><?php echo $data['online']['numPlayers']?></b> Players online
					</div>
				</div>					
				<h2>CURRENTLY ONLINE: <font color="#e20000"><?php echo $data['online']['redPlayers']?></font>/<font color="#1564e1"><?php echo $data['online']['bluePlayers']?></font></h2>
			</div>
		</section>
		<section class="textBlock" id="SlotList">
			<?php include("slotlist.php"); ?>
		</section>
		<section class="textBlock" id="PlayerList">
			<div id="PlayerListWrapper">
				<table id="PlayerListTable" class="tablesorter-dark">
					<thead>
						<tr>
							<th width=350 align="left"><b>Name</b></th>
							<th width=40 align="center">Type</th>
							<th width=10 align="center">Ping</th>
							<th width=10 align="center">Kills</th>
							<th width=10 align="center">Transp.</th>
							<th width=30 align="center">CSAR</th>
							<th width=10 align="center">Crash</th>
							<th width=10 align="center">Dead</th>
							<th width=10 align="center">Eject</th>
							<th width=10 align="center">Takeoff</th>
							<th width=30 align="center">Landing</th>
						</tr>
					</thead>
					<tbody id="PlayerListContent">
<?php 					foreach($data['online']['players'] as $player):?>
						<tr id="PlayerListRows">
							<td><b><a href="pilot.php?pid=<?php echo $player['pid']?>"><font color="<?php echo $coaColors[$player['side']]?>"><?php echo $player['name']?></font></a></b></td>
							<td align="right"><?php echo $player['type'].PHP_EOL; ?></td>
							<td align="center"><?php echo $player['ping'].PHP_EOL; ?>
							</td><td align="center"><?php 
								if(isset($player['kill']))
									echo $player['kill'].PHP_EOL;
								else 
									echo "0".PHP_EOL;
							?></td>
							<td align="center"><?php 
								$num = 0;
								if(isset($player['neutral_base_occupied']))
									$num += $player['neutral_base_occupied'];
								if(isset($player['cargo_unpacked_in_zone']))
									$num += $player['cargo_unpacked_in_zone'];
								if(isset($player['crate_deployed']))
									$num += $player['crate_deployed'];
								if(isset($player['sam_deployed']))
									$num += $player['sam_deployed'];
								if(isset($player['pilot_rescued']))
									$num += $player['pilot_rescued'];
								if(isset($player['pilot_captured']))
									$num += $player['pilot_captured'];
								
								echo $num.PHP_EOL;
							?></td>
							<td align="center"><?php 
								$num = 0;
								if(isset($player['pilot_rescued']))
									$num += $player['pilot_rescued'];
								if(isset($player['pilot_captured']))
									$num += $player['pilot_captured'];
								echo $num.PHP_EOL;
							?></td>
							<td align="center"><?php 
								if(isset($player['crashed']))
									echo $player['crashed'].PHP_EOL;
								else 
									echo "0".PHP_EOL;
							?></td>
							<td align="center"><?php 
								if(isset($player['died']))
									echo $player['died'].PHP_EOL;
								else 
									echo "0".PHP_EOL;
							?></td>
							<td align="center"><?php 
								if(isset($player['ejected']))
									echo $player['ejected'].PHP_EOL;
								else 
									echo "0".PHP_EOL;
							?></td>
							<td align="center"><?php 
								if(isset($player['takeoff']))
									echo $player['takeoff'].PHP_EOL;
								else 
									echo "0".PHP_EOL;
							?></td>
							<td align="center"><?php 
								if(isset($player['landing']))
									echo $player['landing'].PHP_EOL;
								else 
									echo "0".PHP_EOL;?>
							</td>
						</tr>
<?php 					endforeach; ?>
					</tbody>
				</table>
			</div>
			<div style="margin-top: 50px;"><?php include("navbar.php"); ?>
			</div>
		</section>
    </body>
</html>

<?php //print_r($data['online']); ?>
