<?php
	$coaColors = array(
		0 => "#FFFFFF",
		1 => "#e20000",
		2 => "#1564e1",
	);
	$symbolSize = 40;

	$mapImageFile = "assets/images/map/mapvietnam.jpg";

	$mapPositions = array(
		"Sochi-Adler" => array(
			"x" => 283,
			"y" => 407,
			"mgrs" => "<b>37 T EJ 76235 10638</b><br/>43°26.68', 039°56.52'<br/><br>Grid: <b>EJ71</b>",
			"edge" => "br",
			"symbol" => "airport",
		),
		"Gudauta" => array(
			"x" => 698,
			"y" => 657,
			"mgrs" => "<b>37 T FH 27780 74539</b><br/>43°06.76', 040°34.23'<br/><br>Grid: <b>FH27</b>",
			"edge" => "br",
			"symbol" => "airport",
		),
		"Sukhumi-Babushara" => array(
			"x" => 1062,
			"y" => 850,
			"mgrs" => "<b>38 T LP 89850 18834</b><br/>43°30.85', 043°38.23'<br/><br>Grid: <b>LP81</b>",
			"edge" => "bl",
			"symbol" => "airport",
		),
		
		"FARP Sukhumi" => array(
			"x" => 953,
			"y" => 714,
			"mgrs" => "<b>38 T KN 97987 92325</b><br/>43°15.39', 042°30.67'<br/><br>Altitude: <b>2157 m</b> / <b>7076 ft</b><br/><br>Grid: <b>GH89</b>",
			"edge" => "tr",
			"symbol" => "farp",
		),
		"FARP Gagra" => array(
			"x" => 478,
			"y" => 491,
			"mgrs" => "<b>37 T GH 29557 76358</b><br/>43°06.31', 041°49.26'<br/><br>Altitude: <b>729 m</b> / <b>2391 ft</b><br/><br>Grid: <b>GH27</b>",
			"edge" => "br",
			"symbol" => "farp",
		),
	);
?>