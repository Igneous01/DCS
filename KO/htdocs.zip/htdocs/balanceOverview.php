


			<div id="BalanceOverview">
<?php 			foreach($data['balanced'] as $coalition => $categories): ?>
				<div class="coaHeader"><?php echo "Coalition: ".$coalition.PHP_EOL; ?></div>
				<div class="balanceCoalition">
<?php 				foreach($categories as $catName => $slots): ?>
					<div class="balanceCategory" id="boFighters">
						<div class="catHeader"><?php echo $catName.PHP_EOL; ?></div>
<?php 					foreach($slots as $i => $slotData): ?>					
						<div class="balancedSlot">
<?php						if($slotData == "empty"): ?>
							<div class="balancedSlotName">
								empty
							</div>
							<div class="balancedSlotType">
								
							</div>
<?php						else: ?>
								<div class="balancedSlotName">
									<?php echo $slotData['name'].PHP_EOL; ?>
								</div>
								<div class="balancedSlotType">
									<?php echo $slotData['type'].PHP_EOL; ?>
								</div>
<?php						endif; ?>
						</div>
<?php					endforeach; ?>
					</div>
<?php				endforeach; ?>
				</div>
<?php			endforeach; ?>
			</div>

<?php	
	//print_r($data['balanced']);	
	
	
?>